# ontoserver_scripts/get_valueset.py

import requests
import json
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

def get_value_set(value_set_id: str, output_file: str = None):
    """
    Fetches a ValueSet resource from Ontoserver and optionally saves it to a file.
    """
    url = f"{ONTOSERVER_BASE_URL}/ValueSet/{value_set_id}"
    headers = get_auth_headers() # Get headers with the Bearer token

    print(f"Attempting to GET ValueSet: {value_set_id} from {url}")

    try:
        # Use a generous timeout for large resources
        response = requests.get(url, headers=headers, timeout=600) # 10 minutes timeout
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        value_set_data = response.json()
        print(f"Successfully retrieved ValueSet: {value_set_data.get('id', 'N/A')}")

        if output_file:
            with open(output_file, "w") as f:
                json.dump(value_set_data, f, indent=2)
            print(f"ValueSet saved to {output_file}")
        else:
            # For very large resources, printing to console might be overwhelming
            # print(json.dumps(value_set_data, indent=2))
            print("ValueSet data retrieved (not printed to console due to potential size).")

        return value_set_data

    except requests.exceptions.Timeout:
        print(f"Error: GET request for ValueSet {value_set_id} timed out after 10 minutes.")
        print("This often indicates the resource is very large or the server is slow to respond.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching ValueSet {value_set_id}: {e}")
        if response is not None:
            print(f"Response status: {response.status_code}")
            print(f"Response body: {response.text}")
        return None

if __name__ == "__main__":
    # --- IMPORTANT: Replace with your actual ValueSet ID ---
    VALUE_SET_TO_GET = "dc2284ed-b678-4c16-b653-fc694fe105e1" # <--- CHANGE THIS LINE

    # --- Optional: Specify an output file ---
    OUTPUT_FILENAME = f"{VALUE_SET_TO_GET}.json"

    print(f"Trying to retrieve ValueSet with ID: {VALUE_SET_TO_GET}")
    retrieved_data = get_value_set(VALUE_SET_TO_GET, OUTPUT_FILENAME)

    if retrieved_data:
        print("ValueSet retrieval process completed.")
    else:
        print("Failed to retrieve ValueSet.")