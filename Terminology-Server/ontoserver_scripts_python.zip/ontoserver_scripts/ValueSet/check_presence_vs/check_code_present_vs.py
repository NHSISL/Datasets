import pandas as pd
import json
import os

# Load the spreadsheet
spreadsheet_file = 'value_set_definitions_sensitive_conditions.xlsx'
df = pd.read_excel(spreadsheet_file, engine='openpyxl')

# Remove 'sctID--' prefix from the concept code
df['cleaned_code'] = df['copy_safe_concept_code'].str.replace('sctID--', '', regex=False)

# Prepare a column to store the result
df['code_found'] = False

# Load all value sets into a dictionary
value_sets = {}
for file_name in df['full_file_name'].unique():
    if os.path.exists(file_name):
        with open(file_name, 'r', encoding='utf-8') as f:
            value_sets[file_name] = json.load(f)
    else:
        print(f"Warning: {file_name} not found.")

# Check each code against the corresponding value set
for index, row in df.iterrows():
    code = row['cleaned_code']
    value_set_file = row['full_file_name']
    value_set = value_sets.get(value_set_file, {})

    found = False
    if 'compose' in value_set and 'include' in value_set['compose']:
        for include in value_set['compose']['include']:
            if 'concept' in include:
                if any(concept.get('code') == code for concept in include['concept']):
                    found = True
                    break
    df.at[index, 'code_found'] = found

# Save the result to a new CSV file
output_file = 'value_set_code_check_results.csv'
df.to_csv(output_file, index=False)
print(f"✅ Done! Results saved to {output_file}")
