# ontoserver_scripts/put_valueset.py

import requests
import json
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

def put_value_set(value_set_id: str, input_file: str):
    """
    Updates a ValueSet resource on Ontoserver using data from a local JSON file.
    """
    try:
        with open(input_file, "r") as f:
            value_set_data = json.load(f)
        print(f"Loaded ValueSet data from {input_file}")
    except FileNotFoundError:
        print(f"Error: Input file '{input_file}' not found.")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not parse JSON from '{input_file}'. Check its format.")
        return None

    # Crucial: Ensure the ID in the loaded JSON matches the ID you're putting to.
    # The FHIR PUT operation requires the ID in the URL to match the ID in the resource body.
    if value_set_data.get("id") != value_set_id:
        print(f"Warning: ID in file ({value_set_data.get('id')}) does not match ID provided for URL ({value_set_id}).")
        print("For PUT operations, the ID in the resource body MUST match the ID in the URL.")
        print(f"Updating resource ID in memory to match URL: {value_set_id}")
        value_set_data["id"] = value_set_id

    # Add or update the 'meta.lastUpdated' and 'meta.versionId' (technical version)
    # Ontoserver will likely overwrite this anyway, but if you want to explicitly signal a new version,
    # you might remove or increment meta.versionId. For large resources, it's safer to let the server manage.
    if "meta" not in value_set_data:
        value_set_data["meta"] = {}

    # Similar to CodeSystem, you could also increment ValueSet.version for content versioning
    # For example:
    # current_version = value_set_data.get("version", "1.0.0")
    # major, minor, patch = map(int, current_version.split('.'))
    # value_set_data["version"] = f"{major}.{minor+1}.0" # Example: increment minor version

    url = f"{ONTOSERVER_BASE_URL}/ValueSet/{value_set_id}"
    headers = get_auth_headers() # Get headers with the Bearer token

    print(f"Attempting to PUT ValueSet: {value_set_id} to {url}")

    try:
        # Use a very generous timeout for large resources
        # Adjust this timeout based on your server's performance for large payloads
        response = requests.put(url, headers=headers, json=value_set_data, timeout=900) # 15 minutes timeout
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        updated_value_set_data = response.json()
        print(f"Successfully PUT ValueSet: {updated_value_set_data.get('id', 'N/A')}. Status: {response.status_code}")

        # You might want to save the response for verification
        # with open(f"updated_{value_set_id}_response.json", "w") as f:
        #     json.dump(updated_value_set_data, f, indent=2)
        # print(f"Response saved to updated_{value_set_id}_response.json")

        return updated_value_set_data

    except requests.exceptions.Timeout:
        print(f"Error: PUT request for ValueSet {value_set_id} timed out after 15 minutes.")
        print("This is common for very large resources. Check Ontoserver logs for status.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error putting ValueSet {value_set_id}: {e}")
        if response is not None:
            print(f"Response status: {response.status_code}")
            print(f"Response body: {response.text}")
        return None

if __name__ == "__main__":
    # --- IMPORTANT: Replace with the actual ValueSet ID you are updating ---
    VALUE_SET_TO_PUT = "your-actual-value-set-id"

    # --- IMPORTANT: Specify the path to your MODIFIED ValueSet JSON file ---
    # This file should be the one you previously retrieved and then edited.
    INPUT_FILENAME = f"{VALUE_SET_TO_PUT}.json" # Assuming it's in the same directory for now

    print(f"Trying to update ValueSet with ID: {VALUE_SET_TO_PUT} using file: {INPUT_FILENAME}")
    updated_data = put_value_set(VALUE_SET_TO_PUT, INPUT_FILENAME)

    if updated_data:
        print("ValueSet update process completed.")
    else:
        print("Failed to update ValueSet.")