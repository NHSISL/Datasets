import requests
import json
import re
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

def get_value_set_by_id(value_set_id: str):
    """
    Fetches a ValueSet resource from Ontoserver using its ID.
    Returns the full ValueSet JSON if successful.
    """
    url = f"{ONTOSERVER_BASE_URL}/ValueSet/{value_set_id}"
    headers = get_auth_headers()

    print(f"Fetching ValueSet with ID: {value_set_id} from {url}")
    try:
        response = requests.get(url, headers=headers, timeout=600)
        response.raise_for_status()
        value_set_data = response.json()
        print(f"Successfully retrieved ValueSet with ID: {value_set_data.get('id', 'N/A')}")
        return value_set_data
    except requests.exceptions.RequestException as e:
        print(f"Error fetching ValueSet {value_set_id}: {e}")
        return None

def expand_value_set(value_set_url: str):
    """
    Expands a ValueSet using its canonical URL via the $expand operation.
    Returns the expanded ValueSet JSON if successful.
    """
    url = f"{ONTOSERVER_BASE_URL}/ValueSet/$expand"
    headers = get_auth_headers()
    headers["Content-Type"] = "application/json"

    body = {
        "resourceType": "Parameters",
        "parameter": [{"name": "url", "valueUri": value_set_url}]
    }

    print(f"Expanding ValueSet with URL: {value_set_url}")
    try:
        response = requests.post(url, headers=headers, json=body, timeout=600)
        response.raise_for_status()
        expansion_data = response.json()
        print("Successfully expanded ValueSet.")
        return expansion_data
    except requests.exceptions.HTTPError as http_err:
        if response.status_code == 422:
            print("Expansion too large or complex.")
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"HTTP error: {http_err}")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None

def sanitize_filename(name: str) -> str:
    """
    Sanitizes a string to be safe for use as a filename.
    Replaces characters that are not allowed in filenames.
    """
    return re.sub(r'[\\/*?:\"<>|]', "_", name)

if __name__ == "__main__":
    # --- Replace with your actual ValueSet ID ---
    VALUE_SET_ID = "8dfcc1ea-d651-4952-bba6-71276d8a8683"

    # Step 1: Get the ValueSet resource
    value_set = get_value_set_by_id(VALUE_SET_ID)

    # Step 2: Expand the ValueSet using its canonical URL
    if value_set and "url" in value_set:
        expanded_data = expand_value_set(value_set["url"])

        # Step 3: Save the expanded result using the 'name' field
        if expanded_data:
            resource_name = value_set.get("name", VALUE_SET_ID)  # Fallback to ID if name missing
            safe_filename = sanitize_filename(resource_name) + ".json"
            with open(safe_filename, "w") as f:
                json.dump(expanded_data, f, indent=2)
            print(f"Expanded ValueSet saved to {safe_filename}")
        else:
            print("Failed to expand ValueSet.")
    else:
        print("Failed to retrieve ValueSet or missing canonical URL.")
