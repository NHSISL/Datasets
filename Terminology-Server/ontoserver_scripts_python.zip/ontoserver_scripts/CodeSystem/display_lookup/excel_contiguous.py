import pandas as pd

def find_sequence_in_column(
    xlsx_path: str,
    sheet_name=0,
    column="F",
    sequence=None,
    start_row=2,
    end_row=None,
):
    """
    Find all starting row numbers in Excel where `sequence` appears contiguously in `column`.
    Row numbers returned are Excel-like (1-based).
    """
    if sequence is None:
        raise ValueError("Provide a list of codes as `sequence`.")

    # Read only the needed column
    usecols = [column]
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name, dtype=str, usecols=usecols)
    col = df.columns[0]

    # Bound the search region
    sr = max(1, start_row) - 1  # zero-based index
    er = end_row if end_row is not None else len(df)
    vals = (
        df[col]
        .iloc[sr:er]
        .fillna("")
        .map(lambda x: x.strip())
        .tolist()
    )

    seq = [str(x).strip() for x in sequence]
    n = len(seq)
    if n == 0:
        return []

    hits = []
    for i in range(0, len(vals) - n + 1):
        if vals[i:i+n] == seq:
            hits.append(sr + i + 1)  # convert back to 1-based Excel rows

    return hits

# Example usage:
xlsx = "snomed to opcs4 mapping.xlsx"
seq = ["L71.1","X40.3","X43.1","Y53.4","Z89.9","Z94.2"]
rows = find_sequence_in_column(xlsx, sheet_name=0, column="F", sequence=seq, start_row=1)
print("Matches at start rows:", rows)
