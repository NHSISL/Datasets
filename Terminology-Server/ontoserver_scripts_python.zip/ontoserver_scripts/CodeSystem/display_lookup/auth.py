#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_mappings_by_id.py

Reads codes from a CSV/Excel and checks, via FHIR R4 instance-level $translate on Ontoserver,
whether a mapping exists for each code IN THE SPECIFIED ConceptMap (by resource id).

Auth + config are taken from your existing files:
  from auth import get_auth_headers
  from config import ONTOSERVER_BASE_URL

Output:
-------
A CSV (or Excel if requested) with input columns +:
  - result (True/False)
  - match_count
  - target_codes (semicolon-separated)
  - target_systems
  - target_displays
  - equivalences
  - translate_url (exact URL used)
  - comment (e.g., "No mapping found in ConceptMap {id}")
  - error (if any)

Examples:
---------
# Minimal (CSV in/out), ConceptMap specified by ID, global system for all rows:
python check_mappings_by_id.py \
  --conceptmap-id "b602e421-e6cd-30eb-96d7-d9f2c9420fcd" \
  --input codes.csv \
  --code-col code \
  --system "http://snomed.info/sct" \
  --output results.csv

# With per-row system/targetsystem columns:
python check_mappings_by_id.py \
  --conceptmap-id "b602e421-e6cd-30eb-96d7-d9f2c9420fcd" \
  --input codes.csv \
  --code-col code \
  --system-col system \
  --targetsystem-col targetsystem \
  --output results.csv

# Restrict matches to a specific target code:
python check_mappings_by_id.py \
  --conceptmap-id "b602e421-e6cd-30eb-96d7-d9f2c9420fcd" \
  --input codes.csv \
  --code-col code \
  --system "http://snomed.info/sct" \
  --targetcode READ123 \
  --output results.csv

# Excel input (requires pandas+openpyxl); Excel output if you add --excel-out:
python check_mappings_by_id.py \
  --conceptmap-id "b602e421-e6cd-30eb-96d7-d9f2c9420fcd" \
  --input codes.xlsx --sheet "Sheet1" \
  --code-col code \
  --system "http://snomed.info/sct" \
  --excel-out results.xlsx
"""
# === USER CONFIGURATION ===
INPUT_FILE = "code_list.xlsx"       # Your Excel or CSV file
SHEET_NAME = "Sheet1"              # Only for Excel; set to None for CSV
CODE_COLUMN = "code"               # Column name for source codes
SYSTEM_DEFAULT = "http://snomed.info/sct"  # Default source system
TARGETSYSTEM_DEFAULT = "http://read.info/readv2"  # Default target system
CONCEPTMAP_ID = "50f32e4d-84e8-40e9-a749-b774a937c7d5"  # Your ConceptMap resource ID
OUTPUT_FILE = "results.csv"        # Where to save results
TARGET_CODE = None                 # Optional: restrict to one target code
REVERSE = False                    # Set True if you want reverse translation
TIMEOUT = 30.0                     # Seconds per request

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

import requests

# Reuse your existing auth & config (exactly as in your example)
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL


# -------------------
# Session / HTTP util
# -------------------
def build_session() -> requests.Session:
    sess = requests.Session()
    headers = get_auth_headers() or {}
    headers = {
        **headers,
        "Accept": "application/fhir+json",
        "User-Agent": "cm-id-translate-check/1.0",
    }
    sess.headers.update(headers)
    return sess


def translate_instance(
    session: requests.Session,
    base_url: str,
    conceptmap_id: str,
    *,
    code: str,
    system: str,
    targetsystem: Optional[str],
    targetcode: Optional[str],
    reverse: bool,
    timeout: float,
) -> Dict[str, Any]:
    """
    Instance-level $translate:
      [base]/ConceptMap/{id}/$translate?code=...&system=...&targetsystem=...&target=...&reverse=...
    Returns a dict: {"url": <request URL>, "result": bool, "matches": [match parts], "raw": <Parameters>}
    """
    url = f"{base_url.rstrip('/')}/ConceptMap/{conceptmap_id}/$translate"
    params: Dict[str, Any] = {"code": code, "system": system}
    if targetsystem:
        params["targetsystem"] = targetsystem
    if targetcode:
        params["target"] = targetcode
    if reverse:
        params["reverse"] = "true"

    r = session.get(url, params=params, timeout=timeout)
    url_used = r.url
    try:
        r.raise_for_status()
    except requests.HTTPError:
        try:
            body = r.json()
        except Exception:
            body = {"issue": [{"diagnostics": r.text}]}
        raise RuntimeError(f"$translate GET {url_used} -> {r.status_code}\n{json.dumps(body, indent=2)}")

    raw = r.json()
    result_bool = False
    matches: List[Dict[str, Any]] = []

    if isinstance(raw, dict) and raw.get("resourceType") == "Parameters":
        for p in raw.get("parameter", []):
            if p.get("name") == "result" and "valueBoolean" in p:
                result_bool = bool(p["valueBoolean"])
            elif p.get("name") == "match" and "part" in p:
                match_obj: Dict[str, Any] = {}
                for part in p["part"]:
                    name = part.get("name")
                    if "valueCoding" in part:
                        match_obj[name] = part["valueCoding"]  # e.g., {"system": "...", "code": "...", "display": "..."}
                    elif "valueCode" in part:
                        match_obj[name] = part["valueCode"]     # e.g., equivalence
                    elif "valueString" in part:
                        match_obj[name] = part["valueString"]
                    elif "valueUri" in part:
                        match_obj[name] = part["valueUri"]
                    elif "valueBoolean" in part:
                        match_obj[name] = part["valueBoolean"]
                    elif "valueInteger" in part:
                        match_obj[name] = part["valueInteger"]
                matches.append(match_obj)

    return {"url": url_used, "result": result_bool, "matches": matches, "raw": raw}


def summarize_matches(matches: List[Dict[str, Any]]) -> Tuple[str, str, str, str, int]:
    """
    Summarize 'match' parts into semicolon-joined strings:
      - target_codes
      - target_systems
      - target_displays
      - equivalences
      - match_count
    """
    t_codes: List[str] = []
    t_systems: List[str] = []
    t_displays: List[str] = []
    eqs: List[str] = []

    for m in matches:
        coding = m.get("concept")  # 'concept' part is a Coding
        if isinstance(coding, dict):
            if coding.get("code"):
                t_codes.append(str(coding["code"]))
            if coding.get("system"):
                t_systems.append(str(coding["system"]))
            if coding.get("display"):
                t_displays.append(str(coding["display"]))
        if isinstance(m.get("equivalence"), str):
            eqs.append(m["equivalence"])

    # Deduplicate while preserving order
    def dedup(seq: List[str]) -> List[str]:
        seen = set()
        out: List[str] = []
        for s in seq:
            if s not in seen:
                out.append(s)
                seen.add(s)
        return out

    return (
        ";".join(dedup(t_codes)),
        ";".join(dedup(t_systems)),
        ";".join(dedup(t_displays)),
        ";".join(dedup(eqs)),
        len(matches),
    )


# ----------------
# File IO helpers
# ----------------
def read_table(path: str, sheet: Optional[str]) -> List[Dict[str, Any]]:
    """
    Returns a list of row dicts. Supports CSV and Excel (.xlsx/.xls).
    Excel requires pandas + openpyxl. CSV uses built-in csv module.
    """
    _, ext = os.path.splitext(path.lower())
    if ext in (".xlsx", ".xls"):
        try:
            import pandas as pd  # type: ignore
        except Exception as e:
            raise RuntimeError("Reading Excel requires 'pandas' (and 'openpyxl'). Please install them.") from e
        df = pd.read_excel(path, sheet_name=(sheet if sheet else 0), dtype=str)
        df = df.fillna("")
        return df.to_dict(orient="records")
    else:
        with open(path, "r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            rows: List[Dict[str, Any]] = []
            for row in reader:
                rows.append({k: (v if v is not None else "") for k, v in row.items()})
            return rows


def write_csv(path: str, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        with open(path, "w", newline="", encoding="utf-8") as f:
            f.write("")
        return
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def write_excel(path: str, rows: List[Dict[str, Any]]) -> None:
    try:
        import pandas as pd  # type: ignore
    except Exception as e:
        raise RuntimeError("Writing Excel requires 'pandas'. Please install it or use CSV output.") from e
    df = pd.DataFrame(rows)
    df.to_excel(path, index=False)


# ----
# CLI
# ----
def main(argv: List[str]) -> int:
    p = argparse.ArgumentParser(
        description="Check whether codes have mappings in a specific ConceptMap (by id) using FHIR R4 instance-level $translate."
    )
    p.add_argument("--conceptmap-id", required=True, help="ConceptMap resource id (e.g., b602e421-...-d9f2c9420fcd)")
    p.add_argument("--input", required=True, help="Path to input CSV or Excel file")
    p.add_argument("--sheet", help="Excel sheet name (or index). Ignored for CSV.")
    p.add_argument("--output", help="Output CSV path (default: <input>.__translate_results.csv)")
    p.add_argument("--excel-out", help="Output Excel path (.xlsx). If provided, Excel will be written as well/instead.")

    # Columns in input file
    p.add_argument("--code-col", required=True, help="Column name that holds the source code")
    p.add_argument("--system-col", help="Column name that holds the source system (optional if --system is provided)")
    p.add_argument("--targetsystem-col", help="Column name for target system (optional if --targetsystem is provided)")
    p.add_argument("--targetcode-col", help="Column name for a specific target code (optional if --targetcode provided)")

    # Defaults that apply to all rows if not present in the file
    p.add_argument("--system", help="Default source system for all rows (e.g., http://snomed.info/sct)")
    p.add_argument("--targetsystem", help="Default target system for all rows (optional)")
    p.add_argument("--targetcode", help="Default specific target code to check (optional)")

    # Options
    p.add_argument("--reverse", action="store_true", help="Translate in reverse (target→source) if applicable")
    p.add_argument("--timeout", type=float, default=30.0, help="Per-request timeout in seconds")

    args = p.parse_args(argv)

    base_url = ONTOSERVER_BASE_URL.rstrip("/")
    sess = build_session()

    # Read data
    rows = read_table(args.input, args.sheet)

    out_rows: List[Dict[str, Any]] = []
    for i, row in enumerate(rows, start=1):
        code = str(row.get(args.code_col, "") or "").strip()

        # Per-row or default systems
        system = None
        if args.system_col:
            system = str(row.get(args.system_col, "") or "").strip()
        system = system or (args.system or "")
        targetsystem = None
        if args.targetsystem_col:
            targetsystem = str(row.get(args.targetsystem_col, "") or "").strip()
        targetsystem = targetsystem or (args.targetsystem or "")
        targetcode = None
        if args.targetcode_col:
            targetcode = str(row.get(args.targetcode_col, "") or "").strip()
        targetcode = targetcode or (args.targetcode or "")

        result_row = dict(row)
        result_row.update({
            "translate_url": "",
            "result": "",
            "match_count": "",
            "target_codes": "",
            "target_systems": "",
            "target_displays": "",
            "equivalences": "",
            "comment": "",
            "error": "",
        })

        # Validate required data
        if not code:
            result_row["error"] = "Missing code"
            out_rows.append(result_row)
            continue
        if not system:
            result_row["error"] = "Missing system (supply --system or provide a system column)"
            out_rows.append(result_row)
            continue

        try:
            res = translate_instance(
                sess,
                base_url,
                args.conceptmap_id,
                code=code,
                system=system,
                targetsystem=(targetsystem or None),
                targetcode=(targetcode or None),
                reverse=bool(args.reverse),
                timeout=args.timeout,
            )
            t_codes, t_systems, t_displays, eqs, mcount = summarize_matches(res["matches"])
            result_row.update({
                "translate_url": res["url"],
                "result": bool(res["result"]),
                "match_count": mcount,
                "target_codes": t_codes,
                "target_systems": t_systems,
                "target_displays": t_displays,
                "equivalences": eqs,
                "comment": ("" if res["result"] else f"No mapping found in ConceptMap {args.conceptmap_id}"),
            })
        except Exception as e:
            result_row["error"] = str(e)

        out_rows.append(result_row)

        if i % 50 == 0:
            print(f"Processed {i} rows...")

    # Write outputs
    output_csv = args.output or (args.input + ".__translate_results.csv")
    if not args.excel_out:
        write_csv(output_csv, out_rows)
        print(f"Wrote CSV results to {output_csv}")
    else:
        # If excel-out provided, write Excel; also write CSV if user also provided --output
        write_excel(args.excel_out, out_rows)
        print(f"Wrote Excel results to {args.excel_out}")
        if args.output:
            write_csv(output_csv, out_rows)
            print(f"Wrote CSV results to {output_csv}")

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))