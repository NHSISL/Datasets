# -*- coding: utf-8 -*-
"""
A Python script to read codes from an Excel file, query a FHIR
terminology server using the $lookup operation, and save the
results to a JSON file.

This script requires the 'requests' and 'pandas' libraries to be installed.
You can install them using pip:
pip install requests pandas
"""

import requests
import pandas as pd
import json
import os

# ==============================================================================
# IMPORT AUTHENTICATION AND CONFIGURATION
# ==============================================================================
# This is where your provided imports are integrated.
# This approach keeps sensitive data and configuration separate from the main script.
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

# ==============================================================================
# CONFIGURATION - PLEASE UPDATE THESE VALUES
# ==============================================================================

# The path to your Excel file
EXCEL_FILE_PATH = "Codeid.xlsx"

# The name of the column in your Excel file that contains the codes
CODE_COLUMN_NAME = "code"

# The FHIR CodeSystem URL you are querying.
# This is required for the $lookup operation.
#
# IMPORTANT: This needs to match the CodeSystem your codes belong to.
# Based on your Postman response, the correct URL for your example is below.
# Uncomment the correct URL and comment out the other one.

# CODE_SYSTEM_URL = "http://snomed.info/sct" # Default SNOMED CT URL
CODE_SYSTEM_URL = "http://LDS.nhs/EMIS/CodeID/cs" # The correct URL based on your feedback

# The output JSON file name
OUTPUT_FILE_NAME = "code_descriptions.json"

# ==============================================================================
# SCRIPT FUNCTIONS
# ==============================================================================

def lookup_code(code: str, system_url: str, auth_headers: dict) -> dict:
    """
    Performs a FHIR $lookup operation on the Ontoserver for a given code.

    The $lookup operation is a FHIR standard that allows a client to
    retrieve information about a code from a CodeSystem. It's a key
    functionality of terminology servers. We use a GET request for this
    query, passing the CodeSystem URL and the specific code as parameters.

    Args:
        code (str): The code (e.g., a SNOMED CT concept ID) to look up.
        system_url (str): The URL of the CodeSystem (e.g., 'http://snomed.info/sct').
        auth_headers (dict): The dictionary containing authentication headers,
                             passed from the main function.

    Returns:
        dict: A dictionary containing the looked-up display and other
              information, or details about the failure.
    """
    # Construct the $lookup endpoint URL using the imported base URL.
    # The FHIR standard dictates that this operation is on the CodeSystem resource.
    lookup_url = f"{ONTOSERVER_BASE_URL}/CodeSystem/$lookup"
    
    # We use a dictionary to define the query parameters. This is a clean way
    # to format the URL query string (e.g., ?system=...&code=...).
    params = {
        'system': system_url,
        'code': code
    }

    print(f"Attempting to look up code: {code}")
    
    try:
        # The core of the API call. `requests.get()` sends a GET request to the
        # specified URL with the provided parameters and authorization headers.
        response = requests.get(lookup_url, params=params, headers=auth_headers)
        
        # `raise_for_status()` is a crucial part of error handling. It will
        # raise an HTTPError if the response status code is 4xx (Client Error)
        # or 5xx (Server Error), which helps us catch issues immediately.
        response.raise_for_status()

        # Parse the JSON response from the server.
        data = response.json()
        
        # The 'display' field is nested within the 'parameter' array.
        # We need to loop through the parameters to find it.
        display_value = "No display found" # Default value
        if 'parameter' in data:
            for param in data['parameter']:
                # The parameter with the name 'display' holds the value we want.
                if param.get('name') == 'display':
                    # The actual display string is in the 'valueString' key.
                    display_value = param.get('valueString', display_value)
                    break # Stop searching once we've found it

        if display_value != "No display found":
            print(f"  -> Found display: '{display_value}'")
            return {
                "code": code,
                "display": display_value,
                "status": "success"
            }
        else:
            print(f"  -> No display found for code '{code}'.")
            return {
                "code": code,
                "display": "No display found",
                "status": "unmatched"
            }

    except requests.exceptions.RequestException as e:
        # This is a broad exception handler for any issues with the request,
        # such as connection errors, timeouts, or the HTTPError raised by
        # `raise_for_status()`.
        print(f"  -> An error occurred while querying the server for code '{code}': {e}")
        # Add the full URL to the error message for better debugging.
        full_url = requests.Request('GET', lookup_url, params=params).prepare().url
        print(f"  -> Full URL attempted: {full_url}")
        return {
            "code": code,
            "display": f"Error: {e}",
            "status": "error"
        }

def main():
    """
    Main function to orchestrate the entire code lookup process.
    This function handles file I/O, error checking, and the main loop.
    """
    # Call the imported function to get the authentication headers.
    auth_headers = get_auth_headers()
    
    # First, check if the specified Excel file exists to prevent a crash.
    if not os.path.exists(EXCEL_FILE_PATH):
        print(f"Error: The file '{EXCEL_FILE_PATH}' was not found.")
        return

    try:
        # Use pandas to read the Excel file into a DataFrame.
        df = pd.read_excel(EXCEL_FILE_PATH)
    except Exception as e:
        # Catch any errors that occur during the file read process.
        print(f"Error reading the Excel file: {e}")
        return

    # Check if the specified column name exists in the DataFrame.
    if CODE_COLUMN_NAME not in df.columns:
        print(f"Error: Column '{CODE_COLUMN_NAME}' not found in the Excel file.")
        print(f"Available columns are: {df.columns.tolist()}")
        return

    # Extract the codes from the specified column.
    # We convert them to strings and get only the unique codes to avoid
    # duplicate API calls for the same code.
    codes_to_process = df[CODE_COLUMN_NAME].astype(str).unique()
    
    results = []
    print("\n--- Starting code lookup process ---\n")
    
    # Iterate through each unique code and perform the lookup.
    # We pass the auth_headers to the lookup_code function.
    for code in codes_to_process:
        result = lookup_code(code, CODE_SYSTEM_URL, auth_headers)
        results.append(result)

    print("\n--- Process complete ---")

    # Save the final results to a JSON file.
    # `json.dump()` writes the dictionary to a file, and `indent=4`
    # makes the output human-readable with nice formatting.
    with open(OUTPUT_FILE_NAME, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=4)
    
    print(f"Results saved to '{OUTPUT_FILE_NAME}'")

if __name__ == "__main__":
    # This standard Python construct ensures that the `main()` function is
    # called only when the script is executed directly, not when it's imported
    # as a module into another script.
    main()
