#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Resumable fixer for source displays in FHIR ConceptMap JSON using SNOMED CT via Ontoserver.

Key features:
- Only updates *source* displays (ConceptMap.group.element.display).
- Skips targets/products entirely.
- Writes periodic checkpoints: partial amended JSON + on-disk code-display cache.
- Safe to interrupt; you can resume later without losing progress.
- Prints a clear summary.

Requires:
  - requests
  - auth.py   -> get_auth_headers() -> dict (includes Bearer token)
  - config.py -> ONTOSERVER_BASE_URL (e.g., "https://<ontoserver>/fhir")
"""

import json
import copy
import os
import time
import uuid
from typing import Any, Dict, List, Tuple, Union

import requests
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

# ---- MAIN CONFIG (edit these two for each run) ----
input_file = "conceptmap.json"
output_file = "conceptmap_clean.json"
# ---------------------------------------------------

# ---- ADVANCED OPTIONS (usually fine to leave as-is) ----
display_language = "en-GB"
not_found_text = "[SNOMED code NOT FOUND in Ontoserver]"
snomed_system = "http://snomed.info/sct"

# Where to keep partial and cache (auto-derived if left as None)
partial_output_file = None  # e.g., "myfile.partial.json"
cache_file = None           # e.g., "myfile.snomed_cache.json"

# Checkpoint after every N lookups
CHECKPOINT_EVERY = 250

# Retry/backoff for HTTP requests
MAX_RETRIES = 3
INITIAL_BACKOFF_SECONDS = 1.5

# Optional polite delay between successful requests (helps avoid 429s on busy servers)
SLEEP_BETWEEN_REQUESTS = 0.0

# Resume from partial if it exists?
RESUME_FROM_PARTIAL = True
# --------------------------------------------------------

# ----------------- Utilities -----------------
def _atomic_write_json(path: str, obj: Any, indent: int = 2) -> None:
    tmp = f"{path}.tmp.{uuid.uuid4().hex}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)

def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _save_cache(cache_path: str, cache: Dict[str, Dict[str, Any]]) -> None:
    _atomic_write_json(cache_path, cache, indent=2)

def _load_cache(cache_path: str) -> Dict[str, Dict[str, Any]]:
    if not os.path.exists(cache_path):
        return {}
    try:
        return _load_json(cache_path)
    except Exception:
        # Corrupt cache? Start fresh.
        return {}

def is_snomed_uri(uri: str) -> bool:
    if not uri or not isinstance(uri, str):
        return False
    u = uri.strip().lower()
    return ("snomed" in u) or u.startswith("http://snomed.info/sct") or u.startswith("https://snomed.info/sct")
# ---------------------------------------------

# ----------- Ontoserver Lookup ---------------
_session = requests.Session()

def lookup_snomed_display(code: str) -> Tuple[bool, Union[str, None]]:
    """
    Look up SNOMED CT display for a given code using Ontoserver FHIR $lookup.
    Returns (found, display or None)
    """
    url = f"{ONTOSERVER_BASE_URL.rstrip('/')}/CodeSystem/$lookup"
    params = {
        "system": snomed_system,
        "code": str(code),
        "displayLanguage": display_language,
        "property": "designation",  # request designations as fallback
    }
    headers = dict(get_auth_headers() or {})
    headers.setdefault("Accept", "application/fhir+json")
    headers.setdefault("Accept-Language", display_language)

    backoff = INITIAL_BACKOFF_SECONDS
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = _session.get(url, params=params, headers=headers, timeout=30)
        except requests.RequestException:
            if attempt >= MAX_RETRIES:
                return (False, None)
            time.sleep(backoff)
            backoff *= 1.5
            continue

        # Success
        if resp.status_code == 200:
            try:
                data = resp.json()
            except Exception:
                return (False, None)

            # Preferred 'display' parameter
            for p in data.get("parameter", []):
                if p.get("name") == "display" and "valueString" in p:
                    if SLEEP_BETWEEN_REQUESTS:
                        time.sleep(SLEEP_BETWEEN_REQUESTS)
                    return (True, p["valueString"])

            # Fallback: suitable designation
            for p in data.get("parameter", []):
                if p.get("name") == "designation":
                    lang = None
                    value = None
                    for part in p.get("part", []):
                        if part.get("name") == "language":
                            lang = part.get("valueCode")
                        elif part.get("name") == "value":
                            value = part.get("valueString")
                    if value and (not lang or display_language.lower() in str(lang).lower()):
                        if SLEEP_BETWEEN_REQUESTS:
                            time.sleep(SLEEP_BETWEEN_REQUESTS)
                        return (True, value)

            if SLEEP_BETWEEN_REQUESTS:
                time.sleep(SLEEP_BETWEEN_REQUESTS)
            # Found but no usable display
            return (True, None)

        # Not found / invalid code: 400/404
        if resp.status_code in (400, 404):
            return (False, None)

        # Retry transient
        if resp.status_code in (429, 500, 502, 503, 504) and attempt < MAX_RETRIES:
            time.sleep(backoff)
            backoff *= 1.5
            continue

        # Unhandled -> treat as not found
        return (False, None)

    return (False, None)
# ---------------------------------------------

# --------- Processing & Checkpointing --------
def process_conceptmap(
    cm: Dict[str, Any],
    cache: Dict[str, Dict[str, Any]],
    counters: Dict[str, int],
    checkpoint: Dict[str, Any],
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Update *source* displays in ConceptMap (group.element.display) using SNOMED $lookup.
    Uses a persistent cache and periodic checkpoints.
    Returns: (amended_cm, change_log)
    """
    amended = copy.deepcopy(cm)
    change_log: List[Dict[str, Any]] = []

    groups = amended.get("group", [])
    if not isinstance(groups, list):
        return amended, change_log

    for group in groups:
        counters["groups_total"] += 1
        source_uri = group.get("source") or group.get("sourceUri") or group.get("sourceCanonical")

        # Only process SNOMED source groups
        if not is_snomed_uri(source_uri or ""):
            counters["skipped_non_snomed_group"] += 1
            continue

        elements = group.get("element", [])
        if not isinstance(elements, list):
            continue

        for el in elements:
            counters["elements_total"] += 1
            code = el.get("code")
            if not code:
                counters["skipped_no_code"] += 1
                continue

            # Compose cache key (system|lang|code)
            key = f"{snomed_system}|{display_language}|{code}"

            # 1) If we already know the correct display / not-found from cache -> apply fast
            if key in cache:
                entry = cache[key]
                if entry.get("found"):
                    preferred_display = entry.get("display")
                    current_display = el.get("display")
                    if preferred_display and preferred_display != current_display:
                        el["display"] = preferred_display
                        counters["codes_updated"] += 1
                        change_log.append(
                            {
                                "group_source": source_uri,
                                "code": code,
                                "from": current_display,
                                "to": preferred_display,
                                "source": "cache",
                            }
                        )
                    else:
                        counters["codes_unchanged"] += 1
                else:
                    # not found previously
                    nf_display = f"{not_found_text} {code}"
                    current_display = el.get("display")
                    if current_display != nf_display:
                        el["display"] = nf_display
                        counters["codes_not_found"] += 1
                        change_log.append(
                            {
                                "group_source": source_uri,
                                "code": code,
                                "from": current_display,
                                "to": nf_display,
                                "note": "SNOMED code not found (cached)",
                                "source": "cache",
                            }
                        )
                    else:
                        counters["codes_unchanged"] += 1
                continue  # next element

            # 2) New code -> perform lookup
            counters["lookups_attempted"] += 1
            current_display = el.get("display")
            found, preferred_display = lookup_snomed_display(str(code))

            if found:
                cache[key] = {
                    "found": True,
                    "display": preferred_display,
                    "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                }
                if preferred_display and preferred_display != current_display:
                    el["display"] = preferred_display
                    counters["codes_updated"] += 1
                    change_log.append(
                        {
                            "group_source": source_uri,
                            "code": code,
                            "from": current_display,
                            "to": preferred_display,
                        }
                    )
                else:
                    counters["codes_unchanged"] += 1
            else:
                cache[key] = {
                    "found": False,
                    "display": None,
                    "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                }
                nf_display = f"{not_found_text} {code}"
                el["display"] = nf_display
                counters["codes_not_found"] += 1
                change_log.append(
                    {
                        "group_source": source_uri,
                        "code": code,
                        "from": current_display,
                        "to": nf_display,
                        "note": "SNOMED code not found",
                    }
                )

            # 3) Checkpoint periodically (only after at least 1 lookup)
            if counters["lookups_attempted"] > 0 and (counters["lookups_attempted"] % CHECKPOINT_EVERY == 0):
                checkpoint["lookups_done_hint"] = counters["lookups_attempted"]  # <-- add this
                _do_checkpoint(amended, cache, checkpoint)


    return amended, change_log


def process_document(
    data: Union[Dict[str, Any], List[Any]],
    cache: Dict[str, Dict[str, Any]],
    checkpoint: Dict[str, Any],
) -> Tuple[Union[Dict[str, Any], List[Any]], Dict[str, int], List[Dict[str, Any]]]:
    """
    Handles:
      - Single ConceptMap
      - Bundle of ConceptMaps
    Falls back to returning input unchanged for other structures.
    """
    counters = {
        "conceptmaps_total": 0,
        "groups_total": 0,
        "elements_total": 0,
        "lookups_attempted": 0,
        "codes_updated": 0,
        "codes_not_found": 0,
        "codes_unchanged": 0,
        "skipped_non_snomed_group": 0,
        "skipped_no_code": 0,
    }
    changes: List[Dict[str, Any]] = []

    # Single ConceptMap
    if isinstance(data, dict) and data.get("resourceType") == "ConceptMap":
        amended, log = process_conceptmap(data, cache, counters, checkpoint)
        counters["conceptmaps_total"] += 1
        changes.extend(log)
        return amended, counters, changes

    # Bundle of ConceptMaps
    if isinstance(data, dict) and data.get("resourceType") == "Bundle":
        amended_bundle = copy.deepcopy(data)
        for entry in amended_bundle.get("entry", []):
            res = entry.get("resource")
            if isinstance(res, dict) and res.get("resourceType") == "ConceptMap":
                amended_res, log = process_conceptmap(res, cache, counters, checkpoint)
                entry["resource"] = amended_res
                counters["conceptmaps_total"] += 1
                changes.extend(log)
        return amended_bundle, counters, changes

    # Unsupported shape: pass through unchanged
    return copy.deepcopy(data), counters, changes


def _do_checkpoint(amended_obj: Any, cache: Dict[str, Dict[str, Any]], checkpoint: Dict[str, Any]) -> None:
    """
    Writes partial amended JSON and cache atomically, so you can resume later.
    """
    # Write partial amended JSON
    _atomic_write_json(checkpoint["partial_output_path"], amended_obj, indent=2)
    # Write cache
    _save_cache(checkpoint["cache_path"], cache)
    # Optional: you could also dump a small progress marker
    checkpoint["last_checkpoint_ts"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    print(f"💾 Checkpoint saved at {checkpoint['last_checkpoint_ts']} "
          f"(lookups: {checkpoint.get('lookups_done_hint', 'n/a')})")


def print_summary(input_path: str, output_path: str, counters: Dict[str, int]) -> None:
    print("\n=== Summary ===")
    print(f"Input:  {input_path}")
    print(f"Output: {output_path}")
    order = [
        "conceptmaps_total",
        "groups_total",
        "elements_total",
        "lookups_attempted",
        "codes_updated",
        "codes_not_found",
        "codes_unchanged",
        "skipped_non_snomed_group",
        "skipped_no_code",
    ]
    for k in order:
        if k in counters:
            print(f"{k}: {counters[k]}")
# ---------------------------------------------

def main():
    # Derive partial/cache paths if not provided
    p_output = partial_output_file or f"{output_file}.partial.json"
    c_file = cache_file or f"{os.path.splitext(input_file)[0]}.snomed_cache.json"

    # Decide which input to load: partial (resume) or original input
    source_path = input_file
    if RESUME_FROM_PARTIAL and os.path.exists(p_output):
        print(f"⏯️  Resuming from partial: {p_output}")
        source_path = p_output

    # Load JSON
    try:
        data = _load_json(source_path)
    except Exception as e:
        print(f"ERROR: Failed to read JSON '{source_path}': {e}")
        return

    # Load cache (durable between runs)
    cache = _load_cache(c_file)
    print(f"🔎 Cache entries loaded: {len(cache)}")

    # Prepare checkpoint context
    checkpoint = {
        "partial_output_path": p_output,
        "cache_path": c_file,
        "last_checkpoint_ts": None,
        "lookups_done_hint": 0,
    }

    # Process
    start = time.time()
    amended, counters, _changes = process_document(data, cache, checkpoint)

    # Final write (atomic)
    _atomic_write_json(output_file, amended, indent=2)
    # Also refresh cache on disk
    _save_cache(c_file, cache)

    # Clean up partial if it exists and we reached the end successfully
    if os.path.exists(p_output):
        try:
            os.remove(p_output)
        except Exception:
            pass

    # Summary
    elapsed = time.time() - start
    print_summary(input_file, output_file, counters)
    print(f"⏱️  Elapsed: {elapsed:.1f}s")
    print("✅ Done.")

if __name__ == "__main__":
    main()
