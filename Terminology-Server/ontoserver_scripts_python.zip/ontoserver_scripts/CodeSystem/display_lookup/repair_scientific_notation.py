#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Repair SNOMED source codes in ConceptMap JSON that were corrupted to scientific notation / rounded,
by matching the element's target/product codes to an Excel (or CSV) mapping, and replacing element.code.

Enhancement included here:
- When a fingerprint (built from element.target[*].code and optionally product[*].value)
  matches MULTIPLE SNOMED IDs in the mapping, we now prune any candidate IDs that already
  exist elsewhere in the input JSON as clean (non-suspect) element.code values. The rationale:
  if a candidate ID already appears correctly elsewhere, it is unlikely to be the missing code
  for the current corrupted element. If pruning leaves a single candidate, we auto-repair.

Typical workflow:
  1) Run this script to repair source codes using the Excel/CSV mapping.
  2) Run your Ontoserver display-fixer to repopulate the source displays via $lookup.

Inputs:
  - Input JSON: FHIR R4 ConceptMap JSON (single ConceptMap, Bundle of ConceptMaps, or list)
  - Mapping: Excel (.xlsx/.xlsm) or CSV with columns:
        - referencedComponentId  (the SNOMED source concept)
        - mapTarget             (the target code, e.g., OPCS-4 / ICD-10)
    Optional columns (for diagnostics):
        - mapGroup, mapPriority, mapAdvice

Outputs:
  - New JSON with corrected element.code (source only)
  - CSV report of unresolved/ambiguous items (same schema as before)

Dependencies:
  - pandas (and openpyxl if reading .xlsx)

Author: (You)
"""

import json
import os
from typing import Any, Dict, List, Set, Tuple, Union

import pandas as pd

# ---- MAIN CONFIG: EDIT THESE 3 PATHS ----
input_json   = "b602e421-e6cd-30eb-96d7-d9f2c9420fcd.json"
mapping_file = "snomed to opcs4 mapping.xlsx"   # can be .xlsx or .csv
output_json  = "b602e421-e6cd-30eb-96d7-d9f2c9420fcd_codes_repaired.json"
# -----------------------------------------

# ---- ADVANCED OPTIONS (tweak if needed) ----
sheet_name = 0  # sheet index or name for Excel; ignored if CSV

# Column names in the mapping file:
COL_ID       = "referencedComponentId"
COL_TARGET   = "mapTarget"
# Optional columns if you want to diagnose later:
COL_GROUP    = "mapGroup"
COL_PRIORITY = "mapPriority"
COL_ADVICE   = "mapAdvice"

# Only attempt a fix when the source code looks suspicious:
# Suspicious if:
#   - element.code is not pure digits OR contains '.' OR contains 'e'/'E'
#   - OR element.display contains the "[SNOMED code NOT FOUND" prefix
ONLY_FIX_SUSPECT_CODES = True

# Whether to include 'product.value' codes (e.g., additional OPCS) into the fingerprint:
INCLUDE_PRODUCT_VALUES = True

# If multiple ConceptMap groups exist, still match purely by the target set:
MATCH_STRATEGY = "EXACT_SET"   # currently only exact-set match is implemented

# Write a small CSV report of unresolved/ambiguous elements:
REPORT_PATH = output_json + ".unresolved.csv"
# --------------------------------------------


def _read_mapping(path: str) -> pd.DataFrame:
    """
    Read the mapping file (Excel/CSV) and return a normalized DataFrame.
    Ensures key columns are strings and trims whitespace.
    Filters out rows that do not have a mapTarget.
    """
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm", ".xls"):
        df = pd.read_excel(path, sheet_name=sheet_name, dtype=str, keep_default_na=False)
    elif ext in (".csv", ".txt"):
        df = pd.read_csv(path, dtype=str, keep_default_na=False)
    else:
        raise ValueError(f"Unsupported mapping file extension: {ext}. Use .xlsx or .csv")

    # Normalize critical fields as strings and strip
    for col in [COL_ID, COL_TARGET, COL_GROUP, COL_PRIORITY, COL_ADVICE]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()

    # Keep only rows that have a mapTarget code (non-empty)
    df = df[df[COL_TARGET].str.len() > 0]
    return df


def _build_fingerprint_index(df: pd.DataFrame) -> Tuple[Dict[str, Set[str]], Dict[str, List[Dict[str, str]]]]:
    """
    Build two indices:
      - fp_to_ids: fingerprint -> set of referencedComponentId(s)
      - id_to_targets_meta: referencedComponentId -> list of rows/meta (for debugging)

    Fingerprint: sorted '|' join of UNIQUE mapTarget codes for a referencedComponentId.
    Using a set ensures we don't double-count duplicated target rows in the mapping.
    """
    id_to_targets: Dict[str, Set[str]] = {}
    id_to_targets_meta: Dict[str, List[Dict[str, str]]] = {}

    for _, row in df.iterrows():
        rid = row[COL_ID]
        tgt = row[COL_TARGET]
        if not rid or not tgt:
            continue
        id_to_targets.setdefault(rid, set()).add(tgt)
        id_to_targets_meta.setdefault(rid, []).append(
            {
                "mapTarget": tgt,
                "mapGroup": row.get(COL_GROUP, ""),
                "mapPriority": row.get(COL_PRIORITY, ""),
                "mapAdvice": row.get(COL_ADVICE, ""),
            }
        )

    def make_fp(targets: Set[str]) -> str:
        # Stable, deterministic fingerprint string
        return "|".join(sorted(t for t in targets if t))

    fp_to_ids: Dict[str, Set[str]] = {}
    for rid, tset in id_to_targets.items():
        fp = make_fp(tset)
        fp_to_ids.setdefault(fp, set()).add(rid)

    return fp_to_ids, id_to_targets_meta


def _load_json(path: str) -> Any:
    """Load and parse JSON from disk."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _atomic_write_json(path: str, obj: Any, indent: int = 2) -> None:
    """
    Atomically write JSON to disk to avoid partial writes:
      - write to path.tmp
      - flush and fsync
      - os.replace to final path
    """
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _is_suspect_code(code: Any, display: Any) -> bool:
    """
    Heuristic to decide whether a source code looks 'corrupted' / suspect:
      - non-digit OR contains '.' OR contains 'e'/'E' OR empty
      - OR display contains the NOT FOUND prefix
    """
    s = str(code) if code is not None else ""
    # suspicious if non-digit OR contains '.' OR 'e'/'E' OR empty
    if not s.isdigit() or "." in s or "e" in s.lower():
        return True
    # Additionally, suspicious if display contains the NOT FOUND prefix
    if isinstance(display, str) and "[SNOMED code NOT FOUND" in display:
        return True
    return False


def _collect_targets_from_element(el: Dict[str, Any]) -> Set[str]:
    """
    Build the fingerprint set from element.target[*].code plus (optionally)
    any product[*].value under each target.
    """
    codes: Set[str] = set()
    for t in el.get("target", []) or []:
        if isinstance(t, dict):
            c = t.get("code")
            if isinstance(c, str) and c.strip():
                codes.add(c.strip())
            if INCLUDE_PRODUCT_VALUES:
                for pr in t.get("product", []) or []:
                    if isinstance(pr, dict):
                        v = pr.get("value")
                        if isinstance(v, str) and v.strip():
                            codes.add(v.strip())
    return codes


def _make_fp_from_codes(codes: Set[str]) -> str:
    """Create a sorted '|' joined fingerprint string from a set of codes."""
    return "|".join(sorted(codes))


def _collect_existing_source_codes(doc: Union[Dict[str, Any], List[Any]]) -> Set[str]:
    """
    NEW HELPER:
    Collect all existing (non-suspect) element.code values found anywhere in the input JSON
    (single ConceptMap, Bundle, or list). These are codes already present as proper strings,
    i.e., not in scientific notation and not flagged as NOT FOUND.
    """
    existing: Set[str] = set()

    def scan_conceptmap(cm: Dict[str, Any]) -> None:
        groups = cm.get("group", [])
        if not isinstance(groups, list):
            return
        for g in groups:
            elements = g.get("element", [])
            if not isinstance(elements, list):
                continue
            for el in elements:
                code = el.get("code")
                display = el.get("display")
                if code is None:
                    continue
                # Use the same "suspect" test as the repair logic; only collect clean codes.
                if not _is_suspect_code(code, display):
                    existing.add(str(code).strip())

    if isinstance(doc, dict):
        if doc.get("resourceType") == "ConceptMap":
            scan_conceptmap(doc)
        elif doc.get("resourceType") == "Bundle":
            for entry in doc.get("entry", []):
                res = entry.get("resource")
                if isinstance(res, dict) and res.get("resourceType") == "ConceptMap":
                    scan_conceptmap(res)
    elif isinstance(doc, list):
        for item in doc:
            if isinstance(item, dict) and item.get("resourceType") == "ConceptMap":
                scan_conceptmap(item)

    return existing


def _process_conceptmap(
    cm: Dict[str, Any],
    fp_to_ids: Dict[str, Set[str]],
    existing_codes: Set[str],
) -> Tuple[Dict[str, Any], Dict[str, int], List[Dict[str, str]]]:
    """
    Process a single ConceptMap:
      - Walk groups/elements
      - For suspect element.code values, build a fingerprint from targets (and products)
      - Match fingerprint to candidate SNOMED IDs via the mapping index
      - If multiple candidates:
           * prune candidates that already exist elsewhere in JSON as clean codes
           * if that yields one candidate, auto-repair
      - Log unresolved/ambiguous to the report
    """
    # Deep copy via JSON for robustness and to avoid in-place edits on the original
    amended = json.loads(json.dumps(cm))

    # Counters for this ConceptMap
    counters = {
        "groups_total": 0,
        "elements_total": 0,
        "suspects_seen": 0,
        "repaired": 0,
        "ambiguous": 0,
        "no_match": 0,
        "skipped_clean_code": 0,
    }

    # Rows to append to the unresolved CSV report
    unresolved_rows: List[Dict[str, str]] = []

    groups = amended.get("group", [])
    if not isinstance(groups, list):
        return amended, counters, unresolved_rows

    for group in groups:
        counters["groups_total"] += 1
        elements = group.get("element", [])
        if not isinstance(elements, list):
            continue

        for el in elements:
            counters["elements_total"] += 1
            code = el.get("code")
            display = el.get("display")

            # Only fix suspects if configured
            if ONLY_FIX_SUSPECT_CODES and not _is_suspect_code(code, display):
                counters["skipped_clean_code"] += 1
                continue

            counters["suspects_seen"] += 1

            # Build fingerprint from targets (and products)
            tgt_codes = _collect_targets_from_element(el)
            if not tgt_codes:
                counters["no_match"] += 1
                unresolved_rows.append({
                    "reason": "no_target_codes",
                    "current_code": str(code),
                    "current_display": str(display),
                    "fingerprint": "",
                })
                continue

            fp = _make_fp_from_codes(tgt_codes)
            # Candidates from the mapping index
            ids = [str(x).strip() for x in fp_to_ids.get(fp, [])]

            # NEW: prune out any candidates that already exist elsewhere as clean codes
            if len(ids) > 1:
                ids = [rid for rid in ids if rid not in existing_codes]

            if len(ids) == 1:
                corrected = ids[0]
                el["code"] = corrected  # <-- replace source code only
                counters["repaired"] += 1
            elif len(ids) == 0:
                counters["no_match"] += 1
                unresolved_rows.append({
                    "reason": "no_fp_match",
                    "current_code": str(code),
                    "current_display": str(display),
                    "fingerprint": fp,
                })
            else:
                counters["ambiguous"] += 1
                unresolved_rows.append({
                    "reason": "ambiguous_fp_match",
                    "current_code": str(code),
                    "current_display": str(display),
                    "fingerprint": fp,
                    "candidate_ids": ",".join(sorted(ids)),
                })

    return amended, counters, unresolved_rows


def _process_document(
    doc: Union[Dict[str, Any], List[Any]],
    fp_to_ids: Dict[str, Set[str]],
    existing_codes: Set[str],
) -> Tuple[Union[Dict[str, Any], List[Any]], Dict[str, int], List[Dict[str, str]]]:
    """
    Process the input document, which may be:
      - a single ConceptMap
      - a Bundle of ConceptMaps
      - a list containing ConceptMaps (and possibly other items)

    Aggregates counters and unresolved rows across all ConceptMaps encountered.
    """
    # Aggregate counters across all ConceptMaps in the document
    agg = {
        "conceptmaps_total": 0,
        "groups_total": 0,
        "elements_total": 0,
        "suspects_seen": 0,
        "repaired": 0,
        "ambiguous": 0,
        "no_match": 0,
        "skipped_clean_code": 0,
    }
    unresolved_all: List[Dict[str, str]] = []

    def accumulate(c: Dict[str, int]):
        for k, v in c.items():
            agg[k] = agg.get(k, 0) + v

    # Single ConceptMap
    if isinstance(doc, dict) and doc.get("resourceType") == "ConceptMap":
        amended, counters, unresolved = _process_conceptmap(doc, fp_to_ids, existing_codes)
        agg["conceptmaps_total"] += 1
        accumulate(counters)
        unresolved_all.extend(unresolved)
        return amended, agg, unresolved_all

    # Bundle
    if isinstance(doc, dict) and doc.get("resourceType") == "Bundle":
        amended_bundle = json.loads(json.dumps(doc))  # deep copy of the whole bundle
        for entry in amended_bundle.get("entry", []):
            res = entry.get("resource")
            if isinstance(res, dict) and res.get("resourceType") == "ConceptMap":
                amended_res, counters, unresolved = _process_conceptmap(res, fp_to_ids, existing_codes)
                entry["resource"] = amended_res
                agg["conceptmaps_total"] += 1
                accumulate(counters)
                unresolved_all.extend(unresolved)
        return amended_bundle, agg, unresolved_all

    # List of ConceptMaps
    if isinstance(doc, list):
        out_list = []
        for item in doc:
            if isinstance(item, dict) and item.get("resourceType") == "ConceptMap":
                amended_item, counters, unresolved = _process_conceptmap(item, fp_to_ids, existing_codes)
                out_list.append(amended_item)
                agg["conceptmaps_total"] += 1
                accumulate(counters)
                unresolved_all.extend(unresolved)
            else:
                out_list.append(item)
        return out_list, agg, unresolved_all

    # Unknown structure -> pass through unchanged
    return json.loads(json.dumps(doc)), agg, unresolved_all


def main():
    # 1) Load mapping and build fingerprint index
    try:
        df = _read_mapping(mapping_file)
    except Exception as e:
        print(f"ERROR: Could not read mapping file '{mapping_file}': {e}")
        return

    fp_to_ids, _id_meta = _build_fingerprint_index(df)
    collisions = sum(1 for ids in fp_to_ids.values() if len(ids) > 1)
    print(
        f"🔎 Mapping loaded: {len(df):,} rows. Unique fingerprints: {len(fp_to_ids):,} "
        f"(collisions: {collisions})"
    )

    # 2) Load JSON
    try:
        doc = _load_json(input_json)
    except Exception as e:
        print(f"ERROR: Could not read JSON '{input_json}': {e}")
        return

    # NEW: collect all existing (non-suspect) source codes in the input JSON
    existing_codes = _collect_existing_source_codes(doc)
    # (Optional) Uncomment to inspect what's being pruned against:
    # print(f"Existing clean codes detected: {len(existing_codes):,}")

    # 3) Process
    amended, counters, unresolved = _process_document(doc, fp_to_ids, existing_codes)

    # 4) Write output JSON
    try:
        _atomic_write_json(output_json, amended, indent=2)
    except Exception as e:
        print(f"ERROR: Failed to write output JSON '{output_json}': {e}")
        return

    # 5) Write unresolved CSV (for triage)
    if unresolved:
        try:
            pd.DataFrame(unresolved).to_csv(REPORT_PATH, index=False)
            print(f"🧾 Unresolved/ambiguous report: {REPORT_PATH} ({len(unresolved)} rows)")
        except Exception as e:
            print(f"WARNING: Could not write report '{REPORT_PATH}': {e}")

    # 6) Summary
    print("\n=== Summary ===")
    print(f"Input:   {input_json}")
    print(f"Output:  {output_json}")
    order = [
        "conceptmaps_total",
        "groups_total",
        "elements_total",
        "suspects_seen",
        "repaired",
        "ambiguous",
        "no_match",
        "skipped_clean_code",
    ]
    for k in order:
        print(f"{k}: {counters.get(k, 0)}")

    print("✅ Done. Now run your display-fixer to repopulate displays.")


if __name__ == "__main__":
    main()
