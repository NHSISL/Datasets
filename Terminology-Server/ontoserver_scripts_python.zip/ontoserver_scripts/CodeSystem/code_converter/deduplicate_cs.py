#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Flatten + deduplicate *codes* in a single FHIR R4 CodeSystem JSON file.

What this script does:
- Reads ONE CodeSystem JSON from the same folder as this script (set INPUT_FILENAME).
- Traverses ALL concepts (including nested), in order of appearance.
- Keeps the FIRST occurrence of each code (case-sensitive by default).
- Produces a FLAT list of concepts where each entry has ONLY:
    { "code": "...", "display": "..." }
  -> No nested "concept" properties are written.
- Updates CodeSystem "count" to the number of unique codes kept.
- Writes the cleaned file NEXT TO the original as:
    <input_stem>_cleaned<input_suffix>
  e.g., 'codesystem.json' -> 'codesystem_cleaned.json'
- Also writes a CSV duplicate report and a run summary into ./out/

No command-line arguments — set INPUT_FILENAME below.
"""

from pathlib import Path
import json
import csv
from copy import deepcopy

# ===================== SETTINGS (EDIT ME) ======================
# The CodeSystem file to process (same folder as this script)
INPUT_FILENAME = "4e1faf3b-a474-49f6-a560-700592299a32_updated.json"

# Case handling:
CASE_SENSITIVE = True                      # Your preference is True
RESPECT_RESOURCE_CASE_SENSITIVE = False    # If True, use resource.caseSensitive when present

# Reports folder (relative to this script)
OUTPUT_DIR_NAME = "out"

# Always write a cleaned copy (even if nothing changed)?
ALWAYS_WRITE_CLEANED_COPY = True

# Include 'definition' in output concepts? (You asked for code+display only.)
INCLUDE_DEFINITION = False
# ===============================================================


# ---------------------- Helper utilities -----------------------

def script_dir() -> Path:
    """Directory that contains this script."""
    return Path(__file__).resolve().parent

def ensure_out_dir(base_out: Path) -> None:
    """Ensure the output directory for reports exists."""
    base_out.mkdir(parents=True, exist_ok=True)

def safe_list(x):
    """Return x if it's a list; otherwise return an empty list (tolerant)."""
    return x if isinstance(x, list) else []

def norm_factory(case_sensitive: bool):
    """
    Return a normalization function for dedup comparisons.
    - Case-sensitive: identity for strings; '' for None.
    - Case-insensitive: lowercased string for comparisons.
    """
    if case_sensitive:
        return lambda s: s if s is not None else ""
    return lambda s: (s.lower() if isinstance(s, str) else (str(s).lower() if s is not None else ""))

def count_all_concepts(concepts) -> int:
    """
    Count *all* concept entries in the CodeSystem, including nested ones.
    This is the 'before' count; the cleaned 'count' is number of unique codes kept.
    """
    total = 0
    for c in safe_list(concepts):
        total += 1
        total += count_all_concepts(c.get("concept"))
    return total

def iter_concepts(concepts, path_prefix=""):
    """
    Yield (path, concept_dict) for every concept in traversal order,
    including children, with a readable path like: 'concept[3].concept[2]'.
    """
    for idx, c in enumerate(safe_list(concepts)):
        path = f"{path_prefix}concept[{idx}]"
        yield path, c
        # Recurse into nested children (if any exist)
        yield from iter_concepts(c.get("concept"), path + ".")


# -------------------- Flatten + dedup core ---------------------

def flatten_and_dedup(concepts, norm):
    """
    Traverse all concepts (including nested), deduplicate by normalized code,
    and build a *flat* list of minimal concept entries:
       { "code": "...", "display": "..." }      (+optional "definition")
    Only the *first* occurrence of each code is kept.

    Returns:
      flat_list           : list of minimal concepts (unique codes, first-seen order)
      occ_map             : dict for reporting: key -> {code_literal, first_path, paths[], count}
      missing_code_count  : number of concept nodes missing a usable 'code'
    """
    seen = set()         # normalized codes that we've kept
    occ_map = {}         # occurrences across the tree, for reporting
    flat_list = []       # final flat list of minimal entries
    missing_code_count = 0

    for path, concept in iter_concepts(concepts, path_prefix=""):
        code = concept.get("code")

        # Skip nodes without a usable code (tolerant, but they won't appear in output)
        if code is None or (isinstance(code, str) and code.strip() == ""):
            missing_code_count += 1
            continue

        # Build occurrence tracking (for duplicates report)
        key = norm(str(code))
        if key not in occ_map:
            occ_map[key] = {
                "code_literal": code,
                "first_path": path,
                "paths": [path],
                "count": 1,
            }
        else:
            occ_map[key]["paths"].append(path)
            occ_map[key]["count"] += 1

        # Keep only the first occurrence of each code
        if key in seen:
            continue

        # Minimal output entry: only 'code' + 'display' (and optional 'definition')
        entry = {"code": code}
        display = concept.get("display")
        if isinstance(display, str) and display.strip() != "":
            entry["display"] = display

        if INCLUDE_DEFINITION:
            definition = concept.get("definition")
            if isinstance(definition, str) and definition.strip() != "":
                entry["definition"] = definition

        flat_list.append(entry)
        seen.add(key)

    return flat_list, occ_map, missing_code_count


def process_codesystem(cs_obj, default_case_sensitive=True, respect_resource_flag=False):
    """
    Flatten + deduplicate the CodeSystem's concepts and update 'count'.

    Returns:
      out_cs     : Cleaned CodeSystem dict (flat concepts: only code+display[+definition])
      changed    : True if dedup or flattening changed effective content
      dup_rows   : Rows for CSV report (one per duplicate code)
      stats      : Dict of before/after/missing/dup counts and settings
    """
    # Sanity: only process CodeSystem resources
    if cs_obj.get("resourceType") != "CodeSystem":
        return cs_obj, False, [], {
            "concepts_before": 0,
            "concepts_after": 0,
            "missing_code_nodes": 0,
            "duplicates_removed": 0,
            "duplicate_groups": 0,
            "case_sensitive": default_case_sensitive,
        }

    # Determine effective case behavior
    effective_case_sensitive = default_case_sensitive
    if respect_resource_flag:
        cs_val = cs_obj.get("caseSensitive")
        if isinstance(cs_val, bool):
            effective_case_sensitive = cs_val

    norm = norm_factory(effective_case_sensitive)

    # 'Before' = total nodes (including nested)
    before_total_nodes = count_all_concepts(cs_obj.get("concept"))

    # Flatten + dedup → flat minimal list
    flat_list, occ_map, missing_code_count = flatten_and_dedup(cs_obj.get("concept"), norm)

    # 'After' = number of unique codes kept
    after_unique = len(flat_list)

    # Duplicate stats
    duplicate_groups = sum(1 for info in occ_map.values() if info["count"] > 1)
    duplicates_removed = sum(info["count"] - 1 for info in occ_map.values() if info["count"] > 1)

    # Build report rows
    dup_rows = []
    for info in occ_map.values():
        if info["count"] > 1:
            dup_rows.append({
                "code": info["code_literal"],
                "occurrence_count": info["count"],
                "first_path": info["first_path"],
                "duplicate_paths": "; ".join(info["paths"][1:]),
            })

    # Build cleaned resource: keep all metadata, replace concepts with flat minimal list
    out_cs = deepcopy(cs_obj)
    out_cs["concept"] = flat_list
    out_cs["count"] = after_unique  # Set to number of unique codes retained

    # Heuristic 'changed' flag: changed if dup removed, or missing-code nodes existed,
    # or hierarchy existed (before_total_nodes != after_unique)
    changed = (duplicates_removed > 0) or (missing_code_count > 0) or (before_total_nodes != after_unique)

    stats = {
        "concepts_before": before_total_nodes,
        "concepts_after": after_unique,
        "missing_code_nodes": missing_code_count,
        "duplicates_removed": duplicates_removed,
        "duplicate_groups": duplicate_groups,
        "case_sensitive": effective_case_sensitive,
    }
    return out_cs, changed, dup_rows, stats


# --------------------------- Main ------------------------------

def main():
    """Read the file, flatten+dedup, and write outputs."""
    base_dir = script_dir()
    in_path = base_dir / INPUT_FILENAME

    # Prepare output directory for CSV + summary
    out_dir = base_dir / OUTPUT_DIR_NAME
    ensure_out_dir(out_dir)

    # Guard: file exists?
    if not in_path.exists():
        print(f"❌ File not found: {in_path.name}")
        # Show files to help pick the right name
        for name in sorted(p.name for p in base_dir.glob("*.*")):
            print(f" - {name}")
        return

    # Load JSON
    try:
        with in_path.open("r", encoding="utf-8") as fh:
            cs = json.load(fh)
    except Exception as ex:
        print(f"⚠️ Could not parse {in_path.name}: {ex}")
        return

    # Process
    out_cs, changed, dup_rows, stats = process_codesystem(
        cs,
        default_case_sensitive=CASE_SENSITIVE,
        respect_resource_flag=RESPECT_RESOURCE_CASE_SENSITIVE,
    )

    # CSV report (append mode)
    dup_csv = out_dir / "duplicate_codes_in_codesystems.csv"
    file_exists = dup_csv.exists()
    with dup_csv.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        if not file_exists:
            writer.writerow([
                "file",
                "code",
                "occurrence_count",
                "first_path",
                "duplicate_paths",
                "case_sensitive_used",
            ])
        for dr in sorted(dup_rows, key=lambda r: (-int(r["occurrence_count"]), str(r["code"]))):
            writer.writerow([
                in_path.name,
                dr["code"],
                dr["occurrence_count"],
                dr["first_path"],
                dr["duplicate_paths"],
                stats["case_sensitive"],
            ])

    # Cleaned output path: <stem>_cleaned<suffix> (next to original)
    cleaned_path = in_path.with_name(f"{in_path.stem}_cleaned{in_path.suffix}")

    # Write cleaned copy (always or only when changed)
    if ALWAYS_WRITE_CLEANED_COPY or changed:
        try:
            with cleaned_path.open("w", encoding="utf-8") as fh:
                json.dump(out_cs, fh, ensure_ascii=False, indent=2)
        except Exception as ex:
            print(f"❌ Failed to write cleaned file '{cleaned_path.name}': {ex}")

    # Summary (overwrite per run)
    summary_txt = out_dir / "summary.txt"
    with summary_txt.open("w", encoding="utf-8") as fh:
        fh.write(f"File processed: {in_path.name}\n")
        fh.write(f"Case-sensitive used: {stats['case_sensitive']}\n")
        fh.write(f"Total concept nodes before (incl. nested): {stats['concepts_before']}\n")
        fh.write(f"Unique codes after (flat list): {stats['concepts_after']}\n")
        fh.write(f"Missing-code nodes ignored: {stats['missing_code_nodes']}\n")
        fh.write(f"Duplicate groups: {stats['duplicate_groups']}\n")
        fh.write(f"Duplicates removed: {stats['duplicates_removed']}\n")
        fh.write(f"CSV report: {dup_csv.name}\n")
        fh.write(f"Cleaned file: {cleaned_path.name}\n")

    # Console output
    print(f"✅ Done. Processed: {in_path.name}")
    print(f"🧹 Cleaned copy written next to original: {cleaned_path.name}")
    print(f"🗂️ CSV report: {dup_csv}")
    print(f"ℹ️ Summary: {summary_txt}")


if __name__ == "__main__":
    main()