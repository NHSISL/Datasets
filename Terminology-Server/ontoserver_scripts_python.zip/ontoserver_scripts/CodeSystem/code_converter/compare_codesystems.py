import json
import os

# ---------------- CONFIGURATION ----------------
CODE_SYSTEM_A_FILE = "numericunit2.json"       # Your custom CodeSystem
CODE_SYSTEM_B_FILE = "c1e6ef04-dcd8-4a19-a479-8c6ab2f7e080.json"       # Ontoserver CodeSystem
OUTPUT_FILE = "c1e6ef04-dcd8-4a19-a479-8c6ab2f7e080_updated.json"      # New merged CodeSystem
LOG_FILE = "added_codes.log"                   # Log of added codes
# ------------------------------------------------

def increment_version(version_str):
    """Increment version like 2.5 → 2.6 … 2.9 → 3.0 → 3.1"""
    major, minor = map(int, version_str.split('.'))
    minor += 1
    if minor >= 10:
        major += 1
        minor = 0
    return f"{major}.{minor}"

def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_json(data, file_path):
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def log_added_codes(log_path, added_codes):
    with open(log_path, 'w', encoding='utf-8') as log:
        if added_codes:
            log.write("Added Codes:\n")
            for code, display in added_codes:
                log.write(f"{code} | {display}\n")
        else:
            log.write("No new codes were added.\n")

def merge_codesystems(cs_a, cs_b):
    existing_codes = {concept['code'] for concept in cs_b.get('concept', [])}
    added_codes = []

    for concept in cs_a.get('concept', []):
        code = concept['code']
        if code not in existing_codes:
            cs_b['concept'].append(concept)
            existing_codes.add(code)
            added_codes.append((code, concept.get('display', '')))

    # Update metadata
    cs_b['version'] = increment_version(cs_b.get('version', '1.0'))
    cs_b['count'] = len(cs_b['concept'])

    return cs_b, added_codes

def main():
    cs_a = load_json(CODE_SYSTEM_A_FILE)
    cs_b = load_json(CODE_SYSTEM_B_FILE)

    updated_cs_b, added_codes = merge_codesystems(cs_a, cs_b)

    save_json(updated_cs_b, OUTPUT_FILE)
    log_added_codes(LOG_FILE, added_codes)

    print(f"✅ Merge complete.")
    print(f"✅ Added {len(added_codes)} new codes.")
    print(f"✅ New version: {updated_cs_b['version']}")
    print(f"✅ Total concepts: {updated_cs_b['count']}")
    print(f"✅ Output written to: {OUTPUT_FILE}")
    print(f"✅ Log written to: {LOG_FILE}")

if __name__ == "__main__":
    main()