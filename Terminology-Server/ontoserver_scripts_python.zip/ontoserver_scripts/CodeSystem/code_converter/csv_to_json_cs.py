import csv
import json

INPUT_FILE = "codesystem.csv"
OUTPUT_FILE = "codesystem.json"

concepts = []

with open(INPUT_FILE, "r", encoding="utf-8-sig") as f:
    # Read the first line and clean header names
    first_line = f.readline()
    headers = [h.strip() for h in first_line.split(",")]
    reader = csv.DictReader(f, fieldnames=headers)
    for row in reader:
        # Skip header row in data
        if row[headers[0]].strip().lower() == "sourcecode":
            continue
        code = row.get("source code", "").strip()
        display = row.get("source display", "").strip()
        if code:
            concept = {"code": code}
            if display:
                concept["display"] = display
            concepts.append(concept)

codesystem = {
    "resourceType": "CodeSystem",
    "id": "example-codesystem-id",
    "status": "active",
    "content": "complete",
    "concept": concepts,
    "count": len(concepts)
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(codesystem, f, indent=2)

print(f"Done! Wrote CodeSystem JSON with {len(concepts)} concepts to {OUTPUT_FILE}")