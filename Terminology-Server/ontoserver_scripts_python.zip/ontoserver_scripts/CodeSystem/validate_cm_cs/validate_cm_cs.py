#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FHIR R4 validator/updater for ConceptMap -> CodeSystem (source-side only).

Behaviors:
- Loads ConceptMap and CodeSystem from hard-coded paths (no CLI).
- Filters ConceptMap groups to those whose `source` equals CodeSystem.url.
- Ensures every ConceptMap source element.code exists in CodeSystem; adds if missing.
- Adds display for new concepts when provided; does NOT change existing displays on mismatch (Option A).
- Writes a NEW CodeSystem JSON with `name` suffixed "_updated" and updated `count`.
- Does NOT modify the original input files.
- Emits a JSON validation report summarizing actions.

Author: (c) 2025
"""

import json
import copy
from typing import Dict, List, Tuple, Any, Optional

# =======================
# CONFIG (embedded only)
# =======================
CONCEPT_MAP_PATH = "e6b93acf-61ed-4fb3-a7a1-89b00c49c7a3.json"              # Hard-coded input; change here if needed
CODE_SYSTEM_PATH = "c1e6ef04-dcd8-4a19-a479-8c6ab2f7e080.json"              # Hard-coded input; change here if needed
OUTPUT_CODESYSTEM_PATH = "c1e6ef04-dcd8-4a19-a479-8c6ab2f7e080_updated.json"  # New file; originals untouched
REPORT_PATH = "validation_report.json"            # Report file path

# Display update policy (Option A fixed):
#   "flag"            -> do NOT change existing displays; just report mismatches
DISPLAY_POLICY = "flag"

# If None, the script uses CodeSystem.caseSensitive (default True if absent).
# Set to True/False to override explicitly.
FORCE_CASE_SENSITIVE: Optional[bool] = None

# Filter ConceptMap groups to those where group.source == CodeSystem.url
FILTER_GROUPS_BY_SOURCE_URL = True

# =======================
# Helpers
# =======================
def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(obj: Dict[str, Any], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def flatten_codesystem_concepts(concepts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Flatten potentially nested CodeSystem.concept trees into a simple list of dicts {code, display, ref}
    'ref' is the original concept dict to allow in-place updates if needed later.
    """
    flat: List[Dict[str, Any]] = []
    stack = list(concepts or [])
    while stack:
        node = stack.pop(0)
        if not isinstance(node, dict):
            continue
        code = node.get("code")
        display = node.get("display")
        if code is not None:
            flat.append({"code": code, "display": display, "ref": node})
        # Recurse into children
        if "concept" in node and isinstance(node["concept"], list):
            stack = node["concept"] + stack
    return flat

def build_index(flat_concepts: List[Dict[str, Any]], case_sensitive: bool) -> Dict[str, Dict[str, Any]]:
    """
    Returns dict: normalized_code -> {code, display, ref}
    """
    index: Dict[str, Dict[str, Any]] = {}
    for item in flat_concepts:
        code = item.get("code")
        if code is None:
            continue
        key = code if case_sensitive else str(code).lower()
        if key not in index:
            index[key] = item
    return index

def normalize_code(code: str, case_sensitive: bool) -> str:
    return code if case_sensitive else str(code).lower()

def ensure_codesystem_name_suffix(cs: Dict[str, Any], suffix: str = "_updated") -> None:
    name = cs.get("name")
    if not isinstance(name, str) or not name:
        # If no name exists, fall back to id or default "CodeSystem"
        new_name = (cs.get("id") or "CodeSystem") + suffix
        cs["name"] = new_name
        return
    if not name.endswith(suffix):
        cs["name"] = f"{name}{suffix}"

def dedupe_top_level_concepts(cs: Dict[str, Any], case_sensitive: bool) -> None:
    """
    Ensures top-level cs['concept'] has no duplicate codes by normalized key.
    Keeps first occurrence.
    """
    concepts = cs.get("concept") or []
    seen = set()
    deduped = []
    for c in concepts:
        code = c.get("code")
        if code is None:
            deduped.append(c)
            continue
        key = normalize_code(str(code), case_sensitive)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(c)
    cs["concept"] = deduped

# =======================
# Core logic
# =======================
def extract_source_elements(concept_map: Dict[str, Any], source_url: Optional[str]) -> List[Dict[str, Any]]:
    """
    Extract ConceptMap.group.element[] objects from groups matching source_url (when applicable).
    Returns list of {'code': ..., 'display': ...} for elements that contain 'code'.
    """
    groups = concept_map.get("group") or []
    elements: List[Dict[str, Any]] = []

    for g in groups:
        g_source = g.get("source")
        if FILTER_GROUPS_BY_SOURCE_URL and source_url is not None and g_source != source_url:
            continue
        for el in g.get("element", []) or []:
            if not isinstance(el, dict):
                continue
            if "code" not in el:
                continue  # skip elements without code
            code = el.get("code")
            display = el.get("display")
            if code is None:
                continue
            if isinstance(code, str) and code.strip() == "":
                continue
            elements.append({"code": code, "display": display})
    return elements

def update_codesystem_with_conceptmap(
    cs: Dict[str, Any],
    cm: Dict[str, Any],
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Returns (updated_cs, report)
    - updated_cs: new CodeSystem dict with added concepts and updated count/name.
    - report: stats including additions and display mismatches.
    """
    case_sensitive = FORCE_CASE_SENSITIVE
    if case_sensitive is None:
        case_sensitive = bool(cs.get("caseSensitive", True))

    updated_cs = copy.deepcopy(cs)

    # Extract source elements from ConceptMap groups that match the CodeSystem.url
    source_url = cs.get("url") if FILTER_GROUPS_BY_SOURCE_URL else None
    elements = extract_source_elements(cm, source_url=source_url)

    # Index existing concepts by normalized code
    top_level_concepts = updated_cs.get("concept")
    if not isinstance(top_level_concepts, list):
        top_level_concepts = []
        updated_cs["concept"] = top_level_concepts

    flat = flatten_codesystem_concepts(top_level_concepts)
    index = build_index(flat, case_sensitive=case_sensitive)

    added: List[Dict[str, Any]] = []
    present: List[str] = []
    display_mismatches: List[Dict[str, Any]] = []
    missing_display_for_added: List[str] = []

    for el in elements:
        code = el.get("code")
        display = el.get("display")
        key = normalize_code(str(code), case_sensitive)

        if key not in index:
            # Add missing concept (top-level, to avoid guessing hierarchy)
            new_concept = {"code": code}
            if display is not None and str(display).strip() != "":
                new_concept["display"] = display
            else:
                # Leave display absent if not given; do not assume code==display
                missing_display_for_added.append(code)
            top_level_concepts.append(new_concept)
            # Update index so duplicates in CM don't cause multiple inserts
            index[key] = {"code": code, "display": new_concept.get("display"), "ref": new_concept}
            added.append({"code": code, "display": new_concept.get("display")})
        else:
            # Exists; record and check display mismatch (report-only)
            present.append(code)
            existing = index[key]
            existing_display = existing.get("display")
            cm_display = display
            if cm_display is not None and str(cm_display).strip() != "":
                if existing_display != cm_display:
                    display_mismatches.append({
                        "code": code,
                        "codesystem_display": existing_display,
                        "conceptmap_display": cm_display,
                        "action": DISPLAY_POLICY  # "flag"
                    })
            # No update to display per Option A

    # Deduplicate top-level concepts defensively
    updated_cs["concept"] = top_level_concepts
    dedupe_top_level_concepts(updated_cs, case_sensitive=case_sensitive)

    # Append "_updated" to name
    before_name = cs.get("name")
    ensure_codesystem_name_suffix(updated_cs, suffix="_updated")
    after_name = updated_cs.get("name")

    # Recompute count as number of flattened concepts
    new_flat = flatten_codesystem_concepts(updated_cs.get("concept") or [])
    before_count = cs.get("count")
    after_count = len(new_flat)
    updated_cs["count"] = after_count

    report = {
        "filter_groups_by_source_url": FILTER_GROUPS_BY_SOURCE_URL,
        "codesystem_url": cs.get("url"),
        "conceptmap_groups_examined": len(cm.get("group") or []),
        "elements_extracted": len(elements),
        "case_sensitive_matching": case_sensitive,
        "display_policy": DISPLAY_POLICY,  # "flag"
        "code_system_name_before": before_name,
        "code_system_name_after": after_name,
        "code_system_count_before": before_count,
        "code_system_count_after": after_count,
        "added": added,
        "present_count": len(present),
        "display_mismatches": display_mismatches,
        "missing_display_for_added_codes": missing_display_for_added,
        "output_codesystem_path": OUTPUT_CODESYSTEM_PATH
    }

    return updated_cs, report

def main():
    cs = load_json(CODE_SYSTEM_PATH)
    cm = load_json(CONCEPT_MAP_PATH)

    updated_cs, report = update_codesystem_with_conceptmap(cs, cm)

    # Write outputs (new files only)
    save_json(updated_cs, OUTPUT_CODESYSTEM_PATH)
    save_json(report, REPORT_PATH)

    # Human-readable summary
    print("=== CodeSystem Update Summary ===")
    print(f"Source CodeSystem: {CODE_SYSTEM_PATH}")
    print(f"ConceptMap:        {CONCEPT_MAP_PATH}")
    print(f"Output CodeSystem: {OUTPUT_CODESYSTEM_PATH}")
    print(f"Name:  {report['code_system_name_before']} -> {report['code_system_name_after']}")
    print(f"Count: {report['code_system_count_before']} -> {report['code_system_count_after']}")
    print(f"Added concepts: {len(report['added'])}")
    print(f"Display mismatches: {len(report['display_mismatches'])} (policy: {report['display_policy']})")
    if report["missing_display_for_added_codes"]:
        print(f"Added without display (left blank): {len(report['missing_display_for_added_codes'])}")
    if FILTER_GROUPS_BY_SOURCE_URL:
        print(f"Groups filtered to source URL: {report['codesystem_url']}")
    print(f"Report written to: {REPORT_PATH}")

if __name__ == "__main__":
    main()
