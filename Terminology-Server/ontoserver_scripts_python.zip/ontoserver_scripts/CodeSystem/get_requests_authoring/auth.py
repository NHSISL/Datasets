# ontoserver_scripts/auth.py

import requests
import json
import time
from datetime import datetime, timedelta

# Removed OAUTH2_SCOPE from import
from config import OAUTH2_TOKEN_URL, OAUTH2_CLIENT_ID, OAUTH2_CLIENT_SECRET

# Global variable to store the current access token and its expiration
_access_token = None
_token_expires_at = None

def _get_new_token():
    """
    Obtains a new access token using the OAuth2 Client Credentials grant.
    """
    print("Obtaining new OAuth2 token...")
    token_data = {
        "grant_type": "client_credentials",
        "client_id": OAUTH2_CLIENT_ID,
        "client_secret": OAUTH2_CLIENT_SECRET,
        # Removed "scope": OAUTH2_SCOPE, as it's not required
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded" # Required for form data
    }

    try:
        response = requests.post(OAUTH2_TOKEN_URL, data=token_data, headers=headers, timeout=30)
        response.raise_for_status() # Raise an exception for HTTP errors (4xx or 5xx)
        token_info = response.json()

        global _access_token, _token_expires_at
        _access_token = token_info.get("access_token")
        expires_in = token_info.get("expires_in", 3600) # Default to 1 hour if not provided

        # Set expiration time a bit before actual expiry to allow for network latency
        _token_expires_at = datetime.now() + timedelta(seconds=expires_in - 60) # Renew 60 seconds early

        print("Token obtained successfully.")
        return _access_token

    except requests.exceptions.RequestException as e:
        print(f"Error obtaining token: {e}")
        if response is not None:
            print(f"Response status: {response.status_code}")
            print(f"Response body: {response.text}")
        _access_token = None # Clear token on failure
        _token_expires_at = None
        raise # Re-raise the exception to indicate failure to the caller

def get_access_token():
    """
    Retrieves a valid access token. Renews it if it's expired or about to expire.
    """
    global _access_token, _token_expires_at

    if _access_token and _token_expires_at and datetime.now() < _token_expires_at:
        # Token is still valid
        return _access_token
    else:
        # Token is expired or not present, get a new one
        return _get_new_token()

def get_auth_headers():
    """
    Returns a dictionary of headers with the Authorization bearer token.
    """
    token = get_access_token()
    if token:
        return {
            "Authorization": f"Bearer {token}",
            "Accept": "application/fhir+json",
            "Content-Type": "application/fhir+json"
        }
    else:
        raise Exception("Could not obtain a valid access token.")

if __name__ == "__main__":
    # Example usage:
    try:
        token = get_access_token()
        print(f"Current Access Token: {token[:20]}... (truncated)") # Print a part of the token
    except Exception as e:
        print(f"Failed to get token: {e}")