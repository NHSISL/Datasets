# ontoserver_scripts/put_codesystem.py

import requests
import json
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

def put_code_system(code_system_id: str, input_file: str):
    """
    Updates a CodeSystem resource on Ontoserver using data from a local JSON file.
    """
    try:
        with open(input_file, "r") as f:
            code_system_data = json.load(f)
        print(f"Loaded CodeSystem data from {input_file}")
    except FileNotFoundError:
        print(f"Error: Input file '{input_file}' not found.")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not parse JSON from '{input_file}'. Check its format.")
        return None

    # Crucial: Ensure the ID in the loaded JSON matches the ID you're putting to.
    # The FHIR PUT operation requires the ID in the URL to match the ID in the resource body.
    if code_system_data.get("id") != code_system_id:
        print(f"Warning: ID in file ({code_system_data.get('id')}) does not match ID provided for URL ({code_system_id}).")
        print("For PUT operations, the ID in the resource body MUST match the ID in the URL.")
        print(f"Updating resource ID in memory to match URL: {code_system_id}")
        code_system_data["id"] = code_system_id

    # Add or update the 'meta.lastUpdated' and 'meta.versionId' (technical version)
    # This is typically managed by the server on update, but can sometimes be good to ensure a new versionId.
    # Ontoserver will likely overwrite this anyway, but if you want to explicitly signal a new version,
    # you might remove or increment meta.versionId. For large resources, it's safer to let the server manage.
    # For now, we'll just ensure 'meta' exists if it doesn't.
    if "meta" not in code_system_data:
        code_system_data["meta"] = {}
    
    # You could also optionally increment a 'version' field if your CodeSystem uses semantic versioning
    # for its *content* version (CodeSystem.version), distinct from FHIR's technical versioning (meta.versionId).
    # This is highly dependent on your terminology governance.
    # For example:
    # current_version = code_system_data.get("version", "1.0.0")
    # major, minor, patch = map(int, current_version.split('.'))
    # code_system_data["version"] = f"{major}.{minor+1}.0" # Example: increment minor version

    url = f"{ONTOSERVER_BASE_URL}/CodeSystem/{code_system_id}"
    headers = get_auth_headers() # Get headers with the Bearer token

    print(f"Attempting to PUT CodeSystem: {code_system_id} to {url}")

    try:
        # Use a very generous timeout for large resources
        # Adjust this timeout based on your server's performance for large payloads
        response = requests.put(url, headers=headers, json=code_system_data, timeout=900) # 15 minutes timeout
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        updated_code_system_data = response.json()
        print(f"Successfully PUT CodeSystem: {updated_code_system_data.get('id', 'N/A')}. Status: {response.status_code}")

        # You might want to save the response for verification
        # with open(f"updated_{code_system_id}_response.json", "w") as f:
        #     json.dump(updated_code_system_data, f, indent=2)
        # print(f"Response saved to updated_{code_system_id}_response.json")

        return updated_code_system_data

    except requests.exceptions.Timeout:
        print(f"Error: PUT request for CodeSystem {code_system_id} timed out after 15 minutes.")
        print("This is common for very large resources. Check Ontoserver logs for status.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error putting CodeSystem {code_system_id}: {e}")
        if response is not None:
            print(f"Response status: {response.status_code}")
            print(f"Response body: {response.text}")
        return None

if __name__ == "__main__":
    # --- IMPORTANT: Replace with the actual CodeSystem ID you are updating ---
    CODE_SYSTEM_TO_PUT = "c1e6ef04-dcd8-4a19-a479-8c6ab2f7e080"

    # --- IMPORTANT: Specify the path to your MODIFIED CodeSystem JSON file ---
    # This file should be the one you previously retrieved and then edited.
    INPUT_FILENAME = f"{CODE_SYSTEM_TO_PUT}.json" # Assuming it's in the same directory for now

    print(f"Trying to update CodeSystem with ID: {CODE_SYSTEM_TO_PUT} using file: {INPUT_FILENAME}")
    updated_data = put_code_system(CODE_SYSTEM_TO_PUT, INPUT_FILENAME)

    if updated_data:
        print("CodeSystem update process completed.")
    else:
        print("Failed to update CodeSystem.")