# ontoserver_scripts/config.py

# Ontoserver FHIR Base URL
ONTOSERVER_BASE_URL = "https://ontology.onelondon.online/production1/fhir"

# OAuth2 Token Endpoint URL
# This is typically something like "http://your-auth-server-url/auth/realms/your-realm/protocol/openid-connect/token"
# Or check your Ontoserver documentation/admin to find its OAuth2 token endpoint.
OAUTH2_TOKEN_URL = "https://ontology.onelondon.online/authorisation/auth/realms/terminology/protocol/openid-connect/token" # COMMON EXAMPLE, ADJUST AS NEEDED

# Your OAuth2 Client ID and Client Secret
# These are provided when you register your "client application" with your OAuth2 provider.
OAUTH2_CLIENT_ID = ""
OAUTH2_CLIENT_SECRET = ""

# Removed OAUTH2_SCOPE as it's not required for your Ontoserver setup.