import pandas as pd
import json
import os
import unicodedata
from typing import Dict, Tuple, List

# =========================
# Embedded configuration
# =========================
# 👉 EDIT these paths for your environment
INPUT_CSV = "conceptmap.csv"  # e.g., your sample CSV
CODESYSTEM_FILE = "4e1faf3b-a474-49f6-a560-700592299a32.json"  # the CodeSystem JSON to check against

# CSV column containing the code to check
CODE_COLUMN = "Code"   # from your sample CSV

# Output file (defaults to alongside INPUT_CSV with suffix)
OUTPUT_CSV = None  # or set explicit path, e.g., r"C:\path\to\numericUnit_checked.csv"

# Optional: prefixes to strip from codes (leave [] if not needed)
PREFIXES_TO_STRIP = []

# =========================
# Helpers
# =========================
def strip_known_prefixes(text: str, prefixes: List[str]) -> str:
    if text is None:
        return ""
    text = str(text)
    for p in prefixes:
        if text.startswith(p):
            return text[len(p):]
    return text

def normalize_text(text: str) -> str:
    """Unicode-normalize + strip; keep internal spaces/backslashes as-is."""
    if text is None:
        return ""
    return unicodedata.normalize("NFC", str(text)).strip()

def flatten_concepts(concepts: List[dict]):
    """Yield all concepts, including nested concept.concept[*]."""
    if not concepts:
        return
    stack = list(concepts)
    while stack:
        node = stack.pop()
        yield node
        nested = node.get("concept")
        if nested:
            stack.extend(nested)

def load_codesystem(file_path: str):
    """
    Load a CodeSystem JSON and index codes with case sensitivity info.

    Returns (index: dict, issues: list[str])
    index contains:
      - caseSensitive: bool
      - content: str|None
      - declared_count: int|None
      - codes_exact: set[str]
      - codes_lower: set[str]
      - lower_to_original: dict[lower->original]
      - file_used: str
    """
    issues = []
    if not os.path.exists(file_path):
        return {}, [f"CodeSystem file not found: {file_path}"]

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            cs = json.load(f)
    except Exception as e:
        return {}, [f"Error loading JSON: {e}"]

    if cs.get("resourceType") != "CodeSystem":
        issues.append(f"ResourceType is {cs.get('resourceType')}, expected CodeSystem.")

    case_sensitive = bool(cs.get("caseSensitive", True))  # safer default
    content = cs.get("content")
    declared_count = cs.get("count")

    concepts = cs.get("concept") or []
    codes_exact = set()
    codes_lower = set()
    lower_to_original = {}

    actual_count = 0
    for node in flatten_concepts(concepts):
        code = node.get("code")
        if code is None:
            continue
        code_str = normalize_text(code)
        if not code_str:
            continue
        actual_count += 1
        codes_exact.add(code_str)
        low = code_str.lower()
        codes_lower.add(low)
        lower_to_original.setdefault(low, code_str)

    if isinstance(declared_count, int) and declared_count != actual_count:
        issues.append(f"Declared count={declared_count} but enumerated={actual_count}.")

    if not concepts and content == "not-present":
        issues.append("Content 'not-present': codes are not enumerated in this file.")

    index = {
        "caseSensitive": case_sensitive,
        "content": content,
        "declared_count": declared_count,
        "codes_exact": codes_exact,
        "codes_lower": codes_lower,
        "lower_to_original": lower_to_original,
        "file_used": file_path,
    }
    return index, issues

# =========================
# Main
# =========================
def main():
    # Derive a default output path next to the input CSV, if not set
    out_csv = OUTPUT_CSV
    if not out_csv:
        base, ext = os.path.splitext(INPUT_CSV)
        out_csv = base + "_checked.csv"

    # Read CSV as pure strings; avoid NA coercion (so strings like "NA" remain strings)
    df = pd.read_csv(
        INPUT_CSV,
        dtype=str,
        keep_default_na=False,  # do not convert "NA", "NaN", etc. to NaN
        na_filter=False,
        encoding="utf-8-sig",
        engine="python",  # robust for odd characters
    )

    if CODE_COLUMN not in df.columns:
        raise ValueError(f"Missing expected column '{CODE_COLUMN}' in {INPUT_CSV}")

    # Clean and normalize the input codes
    df[CODE_COLUMN] = df[CODE_COLUMN].map(normalize_text)
    df["cleaned_code"] = (
        df[CODE_COLUMN]
        .map(lambda s: strip_known_prefixes(s, PREFIXES_TO_STRIP))
        .map(normalize_text)
    )

    # Load the single CodeSystem once
    cs_index, cs_issues = load_codesystem(CODESYSTEM_FILE)

    # If failed to load CodeSystem, annotate and write out what we can
    if not cs_index:
        df["code_found"] = False
        df["match_mode"] = ""
        df["matched_code_in_codesystem"] = ""
        df["notes"] = "; ".join(cs_issues)
        df["codesystem_file_used"] = CODESYSTEM_FILE
        df.to_csv(out_csv, index=False)
        print(f"❗ Stopped early. Could not load CodeSystem. See 'notes' in {out_csv}")
        return

    # Prepare for matching
    case_sensitive = cs_index["caseSensitive"]
    codes_exact = cs_index["codes_exact"]
    codes_lower = cs_index["codes_lower"]
    lower_to_original = cs_index["lower_to_original"]

    # Evaluate each row
    found_list = []
    mode_list = []
    matched_list = []
    notes_list = []

    for _, row in df.iterrows():
        code = normalize_text(row.get("cleaned_code"))
        note_parts = []

        # carry loader issues (once per row for auditability)
        if cs_issues:
            note_parts.extend(cs_issues)

        found = False
        match_mode = ""
        matched_code = ""

        if not codes_exact and cs_index.get("content") == "not-present":
            note_parts.append("Cannot check membership: content 'not-present' (no concepts enumerated).")
        else:
            if case_sensitive:
                # exact case required
                if code in codes_exact:
                    found = True
                    match_mode = "exact"
                    matched_code = code
                else:
                    # detect case-only mismatch to help debugging
                    if code.lower() in codes_lower:
                        match_mode = "case-mismatch (CodeSystem is caseSensitive)"
                        matched_code = lower_to_original.get(code.lower(), "")
                        note_parts.append("Code present with different case, but caseSensitive=True.")
            else:
                # case-insensitive
                low = code.lower()
                if low in codes_lower:
                    found = True
                    match_mode = "case-insensitive"
                    matched_code = lower_to_original.get(low, code)

        found_list.append(found)
        mode_list.append(match_mode)
        matched_list.append(matched_code)
        notes_list.append("; ".join([p for p in note_parts if p]))

    # Write results
    df["code_found"] = found_list
    df["match_mode"] = mode_list
    df["matched_code_in_codesystem"] = matched_list
    df["notes"] = notes_list
    df["codesystem_file_used"] = cs_index["file_used"]

    df.to_csv(out_csv, index=False)
    print(f"✅ Done! Results saved to {out_csv}")

if __name__ == "__main__":
    main()