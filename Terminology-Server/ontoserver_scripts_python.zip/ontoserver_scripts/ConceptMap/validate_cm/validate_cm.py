import json

def validate_concept_map(file_path):
    errors = []

    # Step 1: Check for valid JSON syntax
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        errors.append(f"JSON syntax error: {e}")
        return errors

    # Step 2: Validate required top-level fields
    required_top_fields = [
        "resourceType", "id", "meta", "url", "version", "name",
        "title", "status", "publisher", "group"
    ]
    for field in required_top_fields:
        if field not in data:
            errors.append(f"Missing top-level field: {field}")

    # Step 3: Validate 'group' structure
    if "group" in data and isinstance(data["group"], list):
        for i, group in enumerate(data["group"]):
            if "source" not in group or "target" not in group or "element" not in group:
                errors.append(f"Group[{i}] missing required fields: 'source', 'target', or 'element'")
            elif isinstance(group["element"], list):
                for j, element in enumerate(group["element"]):
                    if "code" not in element or "target" not in element:
                        errors.append(f"Group[{i}].element[{j}] missing 'code' or 'target'")
                    elif isinstance(element["target"], list):
                        for k, target in enumerate(element["target"]):
                            if "code" not in target or "equivalence" not in target:
                                errors.append(f"Group[{i}].element[{j}].target[{k}] missing 'code' or 'equivalence'")
                    else:
                        errors.append(f"Group[{i}].element[{j}].target is not a list")
            else:
                errors.append(f"Group[{i}].element is not a list")
    else:
        errors.append("'group' is missing or not a list")

    return errors

# Example usage
file_path = "b5519813-31eb-4cad-8c77-b8999420e3c9.json"
validation_errors = validate_concept_map(file_path)

if validation_errors:
    print("Validation Errors Found:")
    for err in validation_errors:
        print(f"- {err}")
else:
    print("ConceptMap JSON is valid.")
