#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Scan FHIR R4 ConceptMap JSON files for codes that appear to be in scientific notation.

What it does
------------
- Recursively scans a folder (default: ./JSON) for *.json and *.ndjson files.
- Loads ConceptMap resources directly, within Bundles, or line-by-line (NDJSON).
- Flags:
  1) Non-string code values (e.g., numbers parsed from JSON such as 1e7).
  2) String code values that match scientific notation, e.g., "1.2E7", "-3e-2".

Outputs
-------
- Prints a concise summary to the console.
- Writes a CSV report: conceptmap_sci_notation_report.csv

Configuration
-------------
- Update INPUT_DIR and FILE_GLOBS if needed.
- Set FLAG_INTEGERS to True if you also want to flag integer codes (not just floats/sci-notation).

Author: M365 Copilot
"""

from __future__ import annotations
import os
import json
import csv
import re
from typing import Any, Dict, Iterable, List, Tuple, Union

# -----------------------------
# Configuration (embedded)
# -----------------------------
INPUT_DIR = os.path.join(os.getcwd(), "JSON")
FILE_GLOBS = (".json", ".ndjson")  # file extensions to scan
OUTPUT_CSV = "conceptmap_sci_notation_report.csv"

# By default we flag floats and strings that look like scientific notation.
# If you also want to flag integer codes (e.g., 123) as potential errors, set this True.
FLAG_INTEGERS = False

# -----------------------------
# Detection logic
# -----------------------------
SCI_STR_RE = re.compile(r"""
    ^\s*                    # optional leading whitespace
    [-+]?                   # optional sign
    (?:\d+(\.\d+)?|\.\d+)   # digits with optional decimal, or .digits
    [eE]                    # 'e' or 'E'
    [-+]?\d+                # exponent
    \s*$                    # optional trailing whitespace
""", re.VERBOSE)

def looks_like_scientific_notation(value: Any) -> Tuple[bool, str]:
    """
    Returns (flag, reason) indicating if 'value' is a code that looks like scientific notation
    or is a non-string numeric (likely parsed from such input).
    """
    # Booleans are subclasses of int in Python; treat them separately
    if isinstance(value, bool):
        return (False, "")

    # If it's a number (float or int), flag floats by default; integers optional.
    if isinstance(value, (int, float)):
        if isinstance(value, float):
            return (True, "non-string numeric (float) — likely from scientific/decimal entry")
        if FLAG_INTEGERS:
            return (True, "non-string numeric (int) — codes should be strings in FHIR")
        return (False, "")

    # If it's a string, check if it matches sci-notation pattern
    if isinstance(value, str) and SCI_STR_RE.match(value):
        return (True, "string looks like scientific notation")
    return (False, "")

# -----------------------------
# FHIR traversal utilities
# -----------------------------
def yield_conceptmaps(resource: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    """
    Yield ConceptMap resources from a top-level resource (ConceptMap or Bundle).
    """
    if not isinstance(resource, dict):
        return
    if resource.get("resourceType") == "ConceptMap":
        yield resource
    elif resource.get("resourceType") == "Bundle":
        for entry in resource.get("entry", []) or []:
            res = entry.get("resource")
            if isinstance(res, dict) and res.get("resourceType") == "ConceptMap":
                yield res

def scan_codes_in_conceptmap(cm: Dict[str, Any], file_hint: str) -> List[Dict[str, Any]]:
    """
    Scan known code-bearing paths in ConceptMap and return list of issues.
    """
    issues: List[Dict[str, Any]] = []

    cm_id = cm.get("id", "")
    cm_url = cm.get("url", "")

    groups = cm.get("group", []) or []
    for g_idx, g in enumerate(groups):
        src_sys = g.get("source", "")
        tgt_sys = g.get("target", "")
        elements = g.get("element", []) or []

        for e_idx, elem in enumerate(elements):
            # Source code
            src_code = elem.get("code")
            flagged, reason = looks_like_scientific_notation(src_code)
            if flagged:
                issues.append({
                    "file": file_hint,
                    "resource_id": cm_id,
                    "resource_url": cm_url,
                    "group_source": src_sys,
                    "group_target": tgt_sys,
                    "path": f"group[{g_idx}].element[{e_idx}].code",
                    "value": src_code,
                    "value_type": type(src_code).__name__,
                    "issue": reason,
                })

            # Targets
            targets = elem.get("target", []) or []
            for t_idx, tgt in enumerate(targets):
                tgt_code = tgt.get("code")
                flagged, reason = looks_like_scientific_notation(tgt_code)
                if flagged:
                    issues.append({
                        "file": file_hint,
                        "resource_id": cm_id,
                        "resource_url": cm_url,
                        "group_source": src_sys,
                        "group_target": tgt_sys,
                        "path": f"group[{g_idx}].element[{e_idx}].target[{t_idx}].code",
                        "value": tgt_code,
                        "value_type": type(tgt_code).__name__,
                        "issue": reason,
                    })

                # dependsOn[].value
                for d_idx, dep in enumerate(tgt.get("dependsOn", []) or []):
                    dep_val = dep.get("value")
                    flagged, reason = looks_like_scientific_notation(dep_val)
                    if flagged:
                        issues.append({
                            "file": file_hint,
                            "resource_id": cm_id,
                            "resource_url": cm_url,
                            "group_source": src_sys,
                            "group_target": tgt_sys,
                            "path": f"group[{g_idx}].element[{e_idx}].target[{t_idx}].dependsOn[{d_idx}].value",
                            "value": dep_val,
                            "value_type": type(dep_val).__name__,
                            "issue": reason,
                        })

                # product[].value
                for p_idx, prod in enumerate(tgt.get("product", []) or []):
                    prod_val = prod.get("value")
                    flagged, reason = looks_like_scientific_notation(prod_val)
                    if flagged:
                        issues.append({
                            "file": file_hint,
                            "resource_id": cm_id,
                            "resource_url": cm_url,
                            "group_source": src_sys,
                            "group_target": tgt_sys,
                            "path": f"group[{g_idx}].element[{e_idx}].target[{t_idx}].product[{p_idx}].value",
                            "value": prod_val,
                            "value_type": type(prod_val).__name__,
                            "issue": reason,
                        })
    return issues

# -----------------------------
# File loading helpers
# -----------------------------
def load_json_file(path: str) -> List[Dict[str, Any]]:
    """
    Loads a file that may be:
    - a single JSON object (ConceptMap or Bundle)
    - an array of resources
    - NDJSON (one JSON object per line)
    Returns a list of top-level resource dicts.
    """
    resources: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            txt = f.read().strip()

        # NDJSON heuristic: multiple lines that each look like JSON objects
        if "\n" in txt and not (txt.startswith("[") or txt.startswith("{")):
            for i, line in enumerate(txt.splitlines()):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        resources.append(obj)
                except json.JSONDecodeError:
                    # Not valid JSON line; skip
                    pass
            if resources:
                return resources

        # Regular JSON
        obj = json.loads(txt) if txt else None
        if isinstance(obj, dict):
            resources.append(obj)
        elif isinstance(obj, list):
            # Some files may contain an array of resources
            for item in obj:
                if isinstance(item, dict):
                    resources.append(item)
    except Exception as ex:
        print(f"[WARN] Failed to parse {path}: {ex}")
    return resources

def find_files(root: str, extensions: Tuple[str, ...]) -> List[str]:
    matches: List[str] = []
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn.lower().endswith(extensions):
                matches.append(os.path.join(dirpath, fn))
    return matches

# -----------------------------
# Main
# -----------------------------
def main():
    if not os.path.isdir(INPUT_DIR):
        print(f"[ERROR] Input directory does not exist: {INPUT_DIR}")
        return

    files = find_files(INPUT_DIR, FILE_GLOBS)
    if not files:
        print(f"[INFO] No files with extensions {FILE_GLOBS} found under {INPUT_DIR}")
        return

    all_issues: List[Dict[str, Any]] = []
    for path in files:
        top_resources = load_json_file(path)
        if not top_resources:
            continue

        for res in top_resources:
            for cm in yield_conceptmaps(res):
                issues = scan_codes_in_conceptmap(cm, os.path.relpath(path, INPUT_DIR))
                all_issues.extend(issues)

    # Write CSV
    if all_issues:
        fieldnames = [
            "file", "resource_id", "resource_url", "group_source", "group_target",
            "path", "value", "value_type", "issue"
        ]
        with open(OUTPUT_CSV, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in all_issues:
                # Ensure string representation for CSV
                row = dict(row)
                if not isinstance(row.get("value"), str):
                    row["value"] = json.dumps(row["value"], ensure_ascii=False)
                writer.writerow(row)

        print(f"[DONE] Found {len(all_issues)} potential issues.")
        print(f"       Report written to: {OUTPUT_CSV}")
    else:
        print("[DONE] No potential scientific-notation code issues found.")

if __name__ == "__main__":
    main()