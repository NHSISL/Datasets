
import pandas as pd
import os

# === CONFIGURATION ===
main_file = "CodeID.tsv"  # Change this to your TSV file name
lookup_file = "EMIS CodeIDs and Terms(EMIS CodeIDs and Terms).csv"  # Change this if needed

# === STEP 1: Load files ===
main_df = pd.read_csv(main_file, sep="\t", dtype=str)
lookup_df = pd.read_csv(lookup_file, sep=",", dtype=str)

# === STEP 2: Create lookup dictionary ===
lookup_dict = dict(zip(lookup_df["CodeId"], lookup_df["Term"]))

# === STEP 3: Update display and track matches ===
matched_rows = []
unmatched_rows = []

for _, row in main_df.iterrows():
    updated_row = row.copy()  # Make a copy so we can modify safely
    if row["Display"] == "Unknown":
        code = row["Code"]
        term = lookup_dict.get(code)
        if term:
            updated_row["Display"] = term
            matched_rows.append(updated_row)
        else:
            unmatched_rows.append(updated_row)
    else:
        matched_rows.append(updated_row)

# === STEP 4: Write outputs ===
base, ext = os.path.splitext(main_file)

# Full updated file
updated_df = pd.DataFrame(matched_rows + unmatched_rows)  # All rows combined
updated_file = f"{base}_updated{ext}"
updated_df.to_csv(updated_file, sep="\t", index=False)

# Matched file
matched_df = pd.DataFrame(matched_rows)
matched_file = f"{base}_matched{ext}"
matched_df.to_csv(matched_file, sep="\t", index=False)

# Unmatched file
unmatched_df = pd.DataFrame(unmatched_rows)
unmatched_file = f"{base}_unmatched{ext}"
unmatched_df.to_csv(unmatched_file, sep="\t", index=False)

print(f"Updated file: {updated_file}")
print(f"Matched file: {matched_file}")
print(f"Unmatched file: {unmatched_file}")
