#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TSV → FHIR ConceptMap (JSON)

- Reads a TSV where lines beginning with '#' contain metadata (key/value),
  and data rows contain mappings.
- Builds a FHIR ConceptMap resource and writes it to JSON.

Key features:
- Header aliasing for flexible column names (e.g., src_code, targetdisplay, etc.)
- Defensive guard against Excel-induced scientific notation mangling.
  **Option 1 fix** implemented: we now only flag likely scientific notation forms
  (decimal mantissa like '7.0E+04' or a signed exponent like '1E+10').
  Codes like '7E122' are no longer flagged.

Author: adapted for NHS NEL ICB terminology workflows
"""

import csv
import json
import io
import re
from typing import Dict, Any, List

# ==== Set your file names here ====
INPUT_FILE = "untitled_map.tsv"      # Your input TSV file name
OUTPUT_FILE = "conceptmap.json"      # Your output JSON file name

# =============================================================================
# Strict guard against Excel-damaged numbers (scientific notation, etc.)
# -----------------------------------------------------------------------------
# OPTION 1 (Chosen): Be conservative—only detect common Excel forms:
#   • Mantissa with a decimal point + exponent, e.g. 7.0E+04, .5e6, 2.e3
#   • Integer mantissa with an explicitly signed exponent, e.g. 1E+10, 3e-5
#
# This allows legitimate alphanumeric codes like "7E122" to pass.
# Note: Plain "1E10" (no decimal, no +/-) will NOT be flagged under Option 1.
# =============================================================================
STRICT_CODE_GUARD = True

SCI_NOTATION_DECIMAL_RE = re.compile(r'^[+-]?(?:\d+\.\d*|\.\d+)[eE][+-]?\d+$')
SCI_NOTATION_SIGNED_EXP_RE = re.compile(r'^[+-]?\d+[eE][+-]\d+$')

def is_scientific_notation(s: str) -> bool:
    """
    Detects 'likely' scientific notation in strings, targeting common Excel outputs.
    Returns True ONLY for:
      - Decimal mantissa + exponent (e.g., '7.0E+04', '.5e6', '2.e3')
      - Integer mantissa + signed exponent (e.g., '1E+10', '3e-5')
    Rejects anything containing alphabetic chars other than e/E (e.g., '7EA22').
    """
    v = (s or "").strip()
    # If any letters other than e/E are present, it's not scientific notation
    if re.search(r'[A-DF-Za-df-z]', v):
        return False
    # Typical Excel-like forms we want to catch:
    if SCI_NOTATION_DECIMAL_RE.match(v):
        return True
    if SCI_NOTATION_SIGNED_EXP_RE.match(v):
        return True
    return False

def guard_code_field(name: str, value: str) -> None:
    """
    Detect Excel-induced corruption of numeric identifiers; refuse to emit wrong codes.
    Under Option 1, this is conservative and avoids false positives like '7E122'.
    """
    if not value:
        return
    v = value.strip()
    if STRICT_CODE_GUARD and is_scientific_notation(v):
        raise ValueError(
            f"Field '{name}' looks corrupted (scientific notation found: {v}). "
            "This typically happens if the TSV/CSV was opened & saved in Excel. "
            "Please regenerate/export the file without opening in Excel, or import as Text."
        )

# ==== Helper: strip quotes if present ====
def strip_outer_quotes(s: str) -> str:
    """
    Removes a single pair of leading/trailing quotes if present.
    Safeguards metadata values that may be quoted.
    """
    if s is None:
        return ""
    s = s.strip()
    if len(s) >= 2 and ((s[0] == '"' and s[-1] == '"') or (s[0] == "'" and s[-1] == "'")):
        return s[1:-1]
    return s

def main():
    # ==== Read file once; split metadata lines vs data lines ====
    metadata: Dict[str, Any] = {}  # from lines starting with '#'
    data_lines: List[str] = []

    with open(INPUT_FILE, "r", encoding="utf-8-sig", newline="") as f:
        for raw in f:
            # Normalise newline and trim trailing '\n'
            line = raw.rstrip("\n")
            if not line:
                # Skip completely blank lines
                continue
            if line.lstrip().startswith("#"):
                # Parse metadata line of the form:  # key \t value
                meta_line = line.lstrip()[1:]  # remove leading '#'
                meta_line = meta_line.lstrip()
                if not meta_line:
                    continue
                if "\t" in meta_line:
                    key, val = meta_line.split("\t", 1)
                    key = key.strip()
                    val = val.strip()
                    # Many values are JSON literals or JSON strings => try json.loads first
                    try:
                        parsed = json.loads(val)
                    except Exception:
                        parsed = strip_outer_quotes(val)
                    metadata[key] = parsed
                # Lines like just '# something' without tab/value are ignored
            else:
                # Keep data rows as-is and rejoin later for csv.DictReader
                data_lines.append(line + "\n")

    if not data_lines:
        raise ValueError("No data rows found (after skipping '#' commented lines).")

    # ==== Build a CSV/TSV reader over the non-comment data ====
    data_stream = io.StringIO("".join(data_lines))

    # Read header row first
    header_reader = csv.reader(data_stream, delimiter="\t")
    try:
        raw_headers = next(header_reader)
    except StopIteration:
        raise ValueError("File has no header row in the non-comment section.")

    # Canonicalise headers (strip whitespace, preserve actual casing for later mapping)
    headers = [h.strip() if h is not None else "" for h in raw_headers]
    # Continue reading remaining rows as dictionaries
    reader = csv.DictReader(data_stream, fieldnames=headers, delimiter="\t")
    rows = list(reader)

    # ==== Prepare the ConceptMap base structure ====
    conceptmap: Dict[str, Any] = {
        "resourceType": "ConceptMap",
        "group": [
            {
                "element": []
            }
        ]
    }

    # ==== Apply metadata where appropriate ====
    # title/name/url (cmUri)
    title = metadata.get("title")
    name = metadata.get("name")
    cm_uri = metadata.get("cmUri")

    if isinstance(title, str) and title:
        conceptmap["title"] = title
    if isinstance(name, str) and name:
        conceptmap["name"] = name
    if isinstance(cm_uri, str) and cm_uri:
        conceptmap["url"] = cm_uri

    # source/target systems to group.source / group.target if present
    # metadata['source'] might look like: {"system":"...", "valueSet":"...", "define":false}
    src_meta = metadata.get("source")
    tgt_meta = metadata.get("target")
    if isinstance(src_meta, dict) and src_meta.get("system"):
        conceptmap["group"][0]["source"] = src_meta["system"]
    if isinstance(tgt_meta, dict) and tgt_meta.get("system"):
        conceptmap["group"][0]["target"] = tgt_meta["system"]

    # If you want to carry valueSets at the top level (Ontoserver is fine with R4-style):
    # conceptmap["sourceUri"] = src_meta.get("valueSet") if isinstance(src_meta, dict) else None
    # conceptmap["targetUri"] = tgt_meta.get("valueSet") if isinstance(tgt_meta, dict) else None

    # ==== Header aliasing to match your file ====
    # Map your columns to the expected ConceptMap fields (case-insensitive).
    HEADER_ALIASES: Dict[str, List[str]] = {
        "sourcecode":     ["sourcecode", "src_cd", "src_code", "srcid", "src", "codeid", "Code", "code"],
        "sourcedisplay":  ["sourcedisplay", "src_label", "src_display", "source_label", "Display", "display"],
        "targetcode":     ["targetcode", "tgt_code", "trg_code", "target_code"],
        "targetdisplay":  ["targetdisplay", "tgt_label", "tgt_display", "target_label"],
        "equivalence":    ["equivalence", "relationship", "rel"],
        "comment":        ["comment", "comments", "note", "notes"],
    }

    # Build a lookup from canonical key -> actual file header
    header_map: Dict[str, str] = {}
    # Lowercased header name -> original header name (for exact case retrieval)
    lower_headers = { (h or "").strip().lower(): (h or "").strip() for h in headers if h is not None }

    for canon, aliases in HEADER_ALIASES.items():
        for a in aliases:
            if a.lower() in lower_headers:
                header_map[canon] = lower_headers[a.lower()]
                break
        # If no alias matched, we will fall back to using the canonical name directly
        # (this covers exact 'sourcecode' presence even if not mapped above)

    # Validate presence of minimum required headers:
    # - 'sourcecode' is mandatory for FHIR ConceptMap.element
    required = ["sourcecode"]
    missing = [k for k in required if (k not in header_map and k not in lower_headers)]
    if missing:
        raise ValueError(
            f"Missing required column(s): {missing}. "
            f"Present headers: {list(lower_headers.values())}"
        )

    def get_val(row: Dict[str, Any], canon_key: str) -> str:
        """
        Retrieve a cell value using canonical key with header alias fallback.
        Returns a trimmed string (empty if missing/None).
        """
        real_key = header_map.get(canon_key, canon_key)  # fallback to same name
        return (row.get(real_key, "") or "").strip()

    # ==== Find all product columns (scan ALL headers) ====
    # We detect the maximum N across any of:
    #   productpropertyN, productvalueN, productdisplayN  (case-insensitive)
    product_index_re = re.compile(r'^(product(?:property|value|display))(\d+)$', re.IGNORECASE)
    product_indices = set()

    for field in lower_headers.values():
        m = product_index_re.match(field.replace(" ", ""))  # ignore spaces within header names
        if m:
            idx = m.group(2)
            if idx.isdigit():
                product_indices.add(int(idx))

    max_products = max(product_indices) if product_indices else 0

    # ==== Build the elements ====
    for row in rows:
        # Skip any accidental embedded header rows (common in concatenated sheets/exports)
        sc_val = get_val(row, "sourcecode")
        if not sc_val:
            # No source code => cannot form an element
            continue
        if sc_val.strip().lower() == "sourcecode":
            # Guard against an extra header line in the middle
            continue

        code = sc_val
        display = get_val(row, "sourcedisplay")
        target_code = get_val(row, "targetcode")
        target_display = get_val(row, "targetdisplay")
        equivalence = get_val(row, "equivalence")
        comment = get_val(row, "comment")

        # Guard against Excel-damaged numeric IDs (e.g., 7.0E+04, 1E+10)
        guard_code_field("sourcecode", code)
        guard_code_field("targetcode", target_code)

        # Only add if source code is present (FHIR requires a code for element)
        if code:
            element: Dict[str, Any] = {
                "code": code,                 # kept as string
                "display": display,
                "target": []
            }

            target: Dict[str, Any] = {
                # Note: FHIR ConceptMap.target.code is technically optional,
                # but included when present
                "code": target_code,
                "display": target_display,
                "equivalence": equivalence
            }
            if comment:
                target["comment"] = comment

            # Gather product entries if any exist among productproperty/value/display columns
            products: List[Dict[str, Any]] = []
            for i in range(1, max_products + 1):
                prop = (row.get(f"productproperty{i}", "") or "").strip()
                val  = (row.get(f"productvalue{i}", "") or "").strip()
                disp = (row.get(f"productdisplay{i}", "") or "").strip()
                if prop or val or disp:
                    product: Dict[str, Any] = {}
                    if prop:
                        product["property"] = prop
                    if val:
                        product["value"] = val
                    if disp:
                        product["display"] = disp
                    products.append(product)

            if products:
                target["product"] = products

            element["target"].append(target)
            conceptmap["group"][0]["element"].append(element)

    # ==== Sanity check: ensure we produced something ====
    if not conceptmap["group"][0]["element"]:
        raise ValueError(
            "No valid mappings found. Check your input file (source codes missing?) "
            "or header mappings."
        )

    # ==== Write the ConceptMap JSON ====
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(conceptmap, f, indent=2, ensure_ascii=False)

    print(
        f"Done! Wrote ConceptMap JSON to {OUTPUT_FILE} | "
        f"elements: {len(conceptmap['group'][0]['element'])}"
    )

if __name__ == "__main__":
    main()