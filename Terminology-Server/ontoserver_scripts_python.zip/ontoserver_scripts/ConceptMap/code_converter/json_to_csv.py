import json   # For reading the ConceptMap JSON file
import csv    # For writing the output CSV file

# ==== Set your file names here ====
# Change these to your actual input and output file names as needed
INPUT_FILE = "conceptmap_cleaned.json"   # The name of your input ConceptMap JSON file
OUTPUT_FILE = "conceptmap.csv"   # The name you want for your output CSV file

# ==== Load the ConceptMap JSON ====
# Open the input file and load its contents as a Python dictionary
with open(INPUT_FILE, "r", encoding="utf-8") as f:
    conceptmap = json.load(f)

rows = []         # This will hold all the rows for the CSV
max_products = 0  # We'll use this to track the maximum number of 'product' entries found

# ==== Extract mappings from the ConceptMap ====
# The ConceptMap structure has a 'group' list, each with 'element's, each with 'target's
for group in conceptmap.get("group", []):  # Loop through each group (if any)
    for element in group.get("element", []):  # Loop through each element in the group
        source_code = element.get("code", "")        # Get the source code (or blank if missing)
        source_display = element.get("display", "")  # Get the source display (or blank if missing)
        for target in element.get("target", []):     # Loop through each target mapping
            target_code = target.get("code", "")         # Get the target code (or blank)
            target_display = target.get("display", "")   # Get the target display (or blank)
            equivalence = target.get("equivalence", "")  # Get the equivalence (or blank)
            comment = target.get("comment", "")          # Get the comment (or blank)
            products = target.get("product", [])         # Get the list of products (or empty list)
            max_products = max(max_products, len(products))  # Track the largest number of products seen
            row = [
                source_code,
                source_display,
                target_code,
                target_display,
                equivalence,
                comment
            ]
            # For each product, add its property, value, and display to the row
            for product in products:
                row.append(product.get("property", ""))  # Product property (or blank)
                row.append(product.get("value", ""))     # Product value (or blank)
                row.append(product.get("display", ""))   # Product display (or blank)
            rows.append(row)  # Add the completed row to our list

# ==== Build the CSV header ====
# Start with the fixed columns
header = [
    "sourcecode",
    "sourcedisplay",
    "targetcode",
    "targetdisplay",
    "equivalence",
    "comment"
]
# Add columns for each possible product (property, value, display for each)
for i in range(1, max_products + 1):
    header.extend([
        f"productproperty{i}",
        f"productvalue{i}",
        f"productdisplay{i}"
    ])

# ==== Pad rows so all have the same number of columns ====
# Some rows may have fewer products than others; pad with blanks so all rows match the header
for row in rows:
    while len(row) < len(header):
        row.append("")

# ==== Write the data to a CSV file ====
with open(OUTPUT_FILE, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)      # Create a CSV writer object
    writer.writerow(header)     # Write the header row
    writer.writerows(rows)      # Write all the data rows

# ==== Done! ====
