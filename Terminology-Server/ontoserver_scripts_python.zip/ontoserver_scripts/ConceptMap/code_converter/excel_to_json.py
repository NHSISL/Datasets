import pandas as pd
import json
from collections import defaultdict

# --- CONFIGURATION ---

# Path to your Excel file
excel_path = "numericunit.xlsx"  # Update if your file is elsewhere

# Output JSON file path
output_json = "conceptmap.json"

# --- LOAD DATA ---

# Read the Excel file, ensuring all columns are read as strings to avoid type issues
df = pd.read_excel(excel_path, dtype=str)

# Strip whitespace from all column headers for consistency
df.columns = df.columns.str.strip()

# --- GROUP DATA BY SOURCE CODE ---

# Group rows by 'source code' so each SNOMED code is mapped once
grouped = defaultdict(list)
for _, row in df.iterrows():
    grouped[row['source code']].append(row)

# --- BUILD CONCEPTMAP STRUCTURE ---

concept_map = {
    "resourceType": "ConceptMap",
    "id": "example-conceptmap",
    "url": "http://example.org/fhir/ConceptMap/SnomedCT_to_OPCS",
    "version": "1.0",
    "name": "SnomedCT_to_OPCS",
    "title": "SnomedCT to OPCS ConceptMap",
    "status": "draft",
    "publisher": "Your Organisation",
    "group": [
        {
            "source": "http://snomed.info/sct",
            "target": "http://fhir.hl7.org.uk/CodeSystem/OPCS-4",
            "element": []
        }
    ]
}

# --- PROCESS EACH GROUP (SOURCE CODE) ---

for source_code, rows in grouped.items():
    # Use the first row as the main mapping for this source code
    main_row = rows[0]

    # --- BUILD TARGET OBJECT ---
    target_obj = {
        "code": main_row['target code'],
        "display": main_row['target display'],
        "equivalence": main_row['equivalence'],
        "comment": main_row['comment']
    }

    # --- BUILD PRODUCT LIST FROM PRODUCT COLUMNS ---
    product_entries = []
    # Dynamically detect how many product columns exist
    product_col_prefixes = [col.split()[0] for col in df.columns if col.startswith('product') and 'property' in col]
    max_products = len(set(product_col_prefixes))

    # Loop through possible product columns (product1, product2, ...)
    for i in range(1, max_products + 1):
        prop_col = f'product{i} property'
        val_col = f'product{i} value'
        disp_col = f'product{i} display'
        # Check if these columns exist and are not empty
        if (
            prop_col in main_row and val_col in main_row and disp_col in main_row and
            pd.notna(main_row[prop_col]) and main_row[prop_col].strip() and
            pd.notna(main_row[val_col]) and main_row[val_col].strip() and
            pd.notna(main_row[disp_col]) and main_row[disp_col].strip()
        ):
            product_entries.append({
                "property": main_row[prop_col],
                "value": main_row[val_col],
                "display": main_row[disp_col]
            })

    # Only add 'product' if there are entries
    if product_entries:
        target_obj["product"] = product_entries

    # --- BUILD ELEMENT OBJECT ---
    element = {
        "code": source_code,
        "display": main_row['source display'],
        "target": [target_obj]
    }

    # Add this element to the ConceptMap
    concept_map["group"][0]["element"].append(element)

# --- SAVE TO JSON FILE ---

with open(output_json, "w", encoding="utf-8") as f:
    json.dump(concept_map, f, indent=2, ensure_ascii=False)

print(f"FHIR ConceptMap JSON saved to '{output_json}'")