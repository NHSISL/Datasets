# ontoserver_scripts/put_conceptmap.py

import requests
import json
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

def put_concept_map(concept_map_id: str, input_file: str):
    """
    Updates a ConceptMap resource on Ontoserver using data from a local JSON file.
    """
    try:
        with open(input_file, "r", encoding="utf-8") as f:
            concept_map_data = json.load(f)
        print(f"Loaded ConceptMap data from {input_file}")
    except FileNotFoundError:
        print(f"Error: Input file '{input_file}' not found.")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not parse JSON from '{input_file}'. Check its format.")
        return None

    # Ensure the ID in the URL matches the ID in the resource
    if concept_map_data.get("id") != concept_map_id:
        print(f"Warning: ID in file ({concept_map_data.get('id')}) does not match ID in URL ({concept_map_id}).")
        print("The server will use the ID from the URL for the PUT operation.")
        concept_map_data["id"] = concept_map_id # Ensure consistency for PUT

    url = f"{ONTOSERVER_BASE_URL}/ConceptMap/{concept_map_id}"
    headers = get_auth_headers() # Get headers with the Bearer token

    print(f"Attempting to PUT ConceptMap: {concept_map_id} to {url}")

    try:
        # Use a very generous timeout for large resources
        response = requests.put(url, headers=headers, json=concept_map_data, timeout=900) # 15 minutes timeout
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        updated_concept_map_data = response.json()
        print(f"Successfully PUT ConceptMap: {updated_concept_map_data.get('id', 'N/A')}. Status: {response.status_code}")

        # You might want to save the response for verification
        # with open(f"updated_{concept_map_id}.json", "w") as f:
        #     json.dump(updated_concept_map_data, f, indent=2)
        # print(f"Response saved to updated_{concept_map_id}.json")

        return updated_concept_map_data

    except requests.exceptions.Timeout:
        print(f"Error: PUT request for ConceptMap {concept_map_id} timed out after 15 minutes.")
        print("This is common for very large resources. Check Ontoserver logs for status.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error putting ConceptMap {concept_map_id}: {e}")
        if response is not None:
            print(f"Response status: {response.status_code}")
            print(f"Response body: {response.text}")
        return None

if __name__ == "__main__":
    # --- IMPORTANT: Replace with your actual ConceptMap ID ---
    CONCEPT_MAP_TO_PUT = "8d2953a3-b70b-4727-8a6a-8b4d912535ad" # <--- CHANGE THIS LINE

    # --- IMPORTANT: Specify the path to your modified ConceptMap JSON file ---
    # This file should have been previously retrieved and then modified locally.
    INPUT_FILENAME = f"{CONCEPT_MAP_TO_PUT}.json" # Assuming it's in the same directory for now

    print(f"Trying to update ConceptMap with ID: {CONCEPT_MAP_TO_PUT} using file: {INPUT_FILENAME}")
    updated_data = put_concept_map(CONCEPT_MAP_TO_PUT, INPUT_FILENAME)

    if updated_data:
        print("ConceptMap update process completed.")
    else:
        print("Failed to update ConceptMap.")