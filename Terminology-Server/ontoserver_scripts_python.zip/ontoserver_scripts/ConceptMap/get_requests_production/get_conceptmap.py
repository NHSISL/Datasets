# ontoserver_scripts/get_conceptmap.py

import requests
import json
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

def get_concept_map(concept_map_id: str, output_file: str = None):
    """
    Fetches a ConceptMap resource from Ontoserver and optionally saves it to a file.
    """
    url = f"{ONTOSERVER_BASE_URL}/ConceptMap/{concept_map_id}"
    headers = get_auth_headers() # Get headers with the Bearer token

    print(f"Attempting to GET ConceptMap: {concept_map_id} from {url}")

    try:
        # Use a generous timeout for large resources, similar to CodeSystem
        response = requests.get(url, headers=headers, timeout=600) # 10 minutes timeout
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        concept_map_data = response.json()
        print(f"Successfully retrieved ConceptMap: {concept_map_data.get('id', 'N/A')}")

        if output_file:
            with open(output_file, "w") as f:
                json.dump(concept_map_data, f, indent=2)
            print(f"ConceptMap saved to {output_file}")
        else:
            # For very large resources, printing to console might be overwhelming
            # print(json.dumps(concept_map_data, indent=2))
            print("ConceptMap data retrieved (not printed to console due to potential size).")

        return concept_map_data

    except requests.exceptions.Timeout:
        print(f"Error: GET request for ConceptMap {concept_map_id} timed out after 10 minutes.")
        print("This often indicates the resource is very large or the server is slow to respond.")
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching ConceptMap {concept_map_id}: {e}")
        if response is not None:
            print(f"Response status: {response.status_code}")
            print(f"Response body: {response.text}")
        return None

if __name__ == "__main__":
    # --- IMPORTANT: Replace with your actual ConceptMap ID ---
    CONCEPT_MAP_TO_GET = "845a32e4-851e-40e0-869d-37dc7aee1d27" # <--- CHANGE THIS LINE

    # --- Optional: Specify an output file ---
    OUTPUT_FILENAME = f"{CONCEPT_MAP_TO_GET}.json"

    print(f"Trying to retrieve ConceptMap with ID: {CONCEPT_MAP_TO_GET}")
    retrieved_data = get_concept_map(CONCEPT_MAP_TO_GET, OUTPUT_FILENAME)

    if retrieved_data:
        print("ConceptMap retrieval process completed.")
    else:
        print("Failed to retrieve ConceptMap.")