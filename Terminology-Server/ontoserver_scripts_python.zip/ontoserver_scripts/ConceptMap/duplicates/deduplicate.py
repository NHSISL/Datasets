import json  # Import the JSON module to read and write JSON files

# --- File paths ---
# Set the input file name (your original ConceptMap JSON)
input_file = "numeric_conceptmap.json"
# Set the output file name (where the deduplicated ConceptMap will be saved)
output_file = "numeric_deduplicated.json"

# --- Load the ConceptMap JSON file ---
with open(input_file, "r", encoding="utf-8") as f:
    concept_map = json.load(f)  # Read the JSON file into a Python dictionary

# --- Deduplicate each group by source code ---
for group in concept_map.get("group", []):  # Loop through each 'group' in the ConceptMap
    seen_codes = set()          # Create a set to keep track of source codes we've already seen
    deduped_elements = []       # This will store only the first occurrence of each source code
    for element in group.get("element", []):  # Loop through each mapping element in the group
        code = element.get("code")            # Get the source code for this mapping
        if code not in seen_codes:            # If we haven't seen this code yet...
            deduped_elements.append(element)  # ...keep this mapping (add to deduped list)
            seen_codes.add(code)              # ...and mark this code as seen
        # If we've already seen this code, skip it (removes duplicates)
    group["element"] = deduped_elements       # Replace the group's elements with deduplicated list

# --- Save the deduplicated ConceptMap back to a new JSON file ---
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(concept_map, f, indent=2, ensure_ascii=False)  # Write the cleaned data to disk

print(f"Deduplication complete. Output written to {output_file}")
