"""
MODULE OVERVIEW:

This script removes duplicate mapping elements from a FHIR ConceptMap resource based on the
source code within each 'group'. It keeps only the first occurrence of each source code.

Steps:
1) Load the ConceptMap JSON from a file.
2) For each group, deduplicate elements by 'code'.
3) Save the cleaned ConceptMap to a new file.

NEW FEATURE:
4) Generates a CSV report detailing all removed duplicate elements (code, group index, etc.).
"""

import json # Standard library for reading and writing JSON files.
import csv  # Standard library for reading and writing CSV files.
from datetime import datetime # For generating a unique report name

# --- File paths ---
# Input: The ConceptMap JSON file you want to clean.
input_file = "da1ecb31-0d0c-4f93-b86e-73a806c09f5e.json"
# Output: The new file where the deduplicated ConceptMap will be saved.
output_file = "eda1ecb31-0d0c-4f93-b86e-73a806c09f5e_deduplicated.json"
# Report: The CSV file detailing the removed duplicates.
report_file = f"deduplication_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

# --- Initialization for Reporting ---
removed_elements_log = [] # List to store data for the CSV report
total_removed_count = 0  # Counter for the total number of removed elements

# --- Load the ConceptMap JSON file ---
try:
  with open(input_file, "r", encoding="utf-8") as f:
    concept_map = json.load(f) # Parse JSON into a Python dictionary.
except FileNotFoundError:
  print(f"❌ Error: Input file not found at {input_file}")
  exit()
except json.JSONDecodeError:
  print(f"❌ Error: Failed to parse JSON from {input_file}. Check file contents.")
  exit()

# --- Deduplicate each group by source code ---
# 'group' is a list of mapping groups in the ConceptMap.
for group_index, group in enumerate(concept_map.get("group", [])):
  seen_codes = set()    # Tracks source codes we've already processed.
  deduped_elements = []   # Stores only the first occurrence of each code.

  # 'element' is a list of mappings within this group.
  for element in group.get("element", []):
    code = element.get("code") # The source code for this mapping.

    # Handle elements with missing or empty codes by treating them as unique
    if code is None or code == "":
      deduped_elements.append(element)
      continue # Skip to the next element

    if code not in seen_codes:
      deduped_elements.append(element) # Keep this mapping.
      seen_codes.add(code)       # Mark this code as seen.
    else:
      # If code is already in seen_codes, log it and skip it (removes duplicates).
      removed_elements_log.append({
        "group_index": group_index,
        "removed_code": code,
        "display": element.get("display", "N/A"),
        "source_codesystem": group.get("source", "N/A")
      })
      total_removed_count += 1

  # Replace the group's elements with the deduplicated list.
  group["element"] = deduped_elements

# --- Save the deduplicated ConceptMap and Report ---

# 1. Save the deduplicated ConceptMap back to a new JSON file
with open(output_file, "w", encoding="utf-8") as f:
  json.dump(concept_map, f, indent=2, ensure_ascii=False)

# 2. Generate the CSV Report
if removed_elements_log:
  fieldnames = ["group_index", "removed_code", "display", "source_codesystem"]
  with open(report_file, 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(removed_elements_log)
  print(f"✅ Report generated: {total_removed_count} duplicate elements logged to {report_file}")
else:
  print("👍 No duplicate elements were found to report.")

print(f"✅ Deduplication complete. Output written to {output_file}")