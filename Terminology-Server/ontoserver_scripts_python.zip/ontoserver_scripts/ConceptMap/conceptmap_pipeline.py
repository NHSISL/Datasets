# -*- coding: utf-8 -*-
"""
ConceptMap end-to-end pipeline (strictly ignores non-matching CSVs)

Flow:
1) Run check_presence_cm/check_map_present.py
2) Run check_presence_cm/update_display_from_pareto.py
3) Copy the new .xlsx into excel_manipulation/
4) Run excel_manipulation/excel_manip.py
5) Run excel_manipulation/sort_all_tsv.py (optional)

Cleanup after success:
- From check_presence_cm:
    Pareto analysis.xlsx
    Codes by Use Count (OLIDS).xlsx
    concept_map_results_<date>.csv
    concept_map_results_<date>.xlsx
    concept_map_results_<date>_excel-safe.csv
    concept_map_results_<date>_excel-safe.xlsx
- From excel_manipulation:
    concept_map_results_<date>_excel-safe.xlsx
    processed_concept_map_results.xlsx
"""

from __future__ import annotations
import sys
import subprocess
from pathlib import Path
import shutil
from typing import Iterable, Optional, List
import datetime as dt

ROOT = Path(__file__).resolve().parent
CHECK_DIR = ROOT / "check_presence_cm"
EXCEL_MANIP_DIR = ROOT / "excel_manipulation"

CSV_PATTERN_SAFE = "concept_map_results_*_excel-safe.csv"
XLSX_PATTERN_SAFE = "concept_map_results_*_excel-safe.xlsx"
CSV_PATTERN = "concept_map_results_*.csv"
XLSX_PATTERN = "concept_map_results_*.xlsx"

RUN_SORT_TSVS = True  # Set False to skip running sort_all_tsv.py


def _run_python(script: Path) -> tuple[dt.datetime, dt.datetime]:
    start = dt.datetime.now()
    print(f"Running: {script}")
    subprocess.run([sys.executable, str(script)], cwd=str(script.parent), check=True)
    end = dt.datetime.now()
    print(f"Completed: {script}\n")
    return start, end


def _find_latest(pattern: str, dirs: Iterable[Path], *, min_mtime: Optional[float] = None) -> Optional[Path]:
    candidates: List[Path] = []
    for d in dirs:
        candidates.extend(d.glob(pattern))
    if min_mtime is not None:
        tol = 2.0
        candidates = [p for p in candidates if p.stat().st_mtime >= (min_mtime - tol)]
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def _cleanup_files():
    """Delete specified files after successful run."""
    to_delete = []

    # From check_presence_cm
    files_check = [
        CHECK_DIR / "Pareto analysis.xlsx",
        CHECK_DIR / "Codes by Use Count (OLIDS).xlsx",
    ]
    to_delete.extend([f for f in files_check if f.exists()])

    # Patterns for concept_map_results files in check_presence_cm
    for pattern in [CSV_PATTERN, XLSX_PATTERN]:
        to_delete.extend(CHECK_DIR.glob(pattern))

    # Patterns for excel-safe files in both folders
    for folder in [CHECK_DIR, EXCEL_MANIP_DIR]:
        to_delete.extend(folder.glob(CSV_PATTERN_SAFE))
        to_delete.extend(folder.glob(XLSX_PATTERN_SAFE))

    # From excel_manipulation: processed_concept_map_results.xlsx
    processed_file = EXCEL_MANIP_DIR / "processed_concept_map_results.xlsx"
    if processed_file.exists():
        to_delete.append(processed_file)

    if not to_delete:
        print("No files found for cleanup.")
        return

    print("\n--- Cleanup: Deleting temporary files ---")
    for f in to_delete:
        try:
            f.unlink()
            print(f"Deleted: {f}")
        except Exception as e:
            print(f"Failed to delete {f}: {e}")
    print("--- Cleanup completed ---")


def main():
    print("=== ConceptMap pipeline start ===")
    print(f"Working dir: {ROOT}")
    print(f"Timestamp  : {dt.datetime.now():%Y-%m-%d %H:%M:%S}")
    print("---------------------------------")

    CHECK_DIR.mkdir(parents=True, exist_ok=True)
    EXCEL_MANIP_DIR.mkdir(parents=True, exist_ok=True)

    check_map_present = CHECK_DIR / "check_map_present.py"
    update_display_script = CHECK_DIR / "update_display_from_pareto.py"
    excel_manip = EXCEL_MANIP_DIR / "excel_manip.py"
    sort_all_tsv = EXCEL_MANIP_DIR / "sort_all_tsv.py"

    for p in (check_map_present, update_display_script, excel_manip):
        if not p.exists():
            raise FileNotFoundError(f"Required script not found: {p}")

    if RUN_SORT_TSVS and not sort_all_tsv.exists():
        raise FileNotFoundError(f"Step 5 is enabled but script not found: {sort_all_tsv}")

    pareto_file = CHECK_DIR / "Pareto analysis.xlsx"
    if not pareto_file.exists():
        raise FileNotFoundError(f"Pareto file not found: {pareto_file}")

    # STEP 1
    step1_start, _ = _run_python(check_map_present)
    latest_csv = _find_latest(CSV_PATTERN_SAFE, [CHECK_DIR], min_mtime=step1_start.timestamp())
    if not latest_csv:
        raise FileNotFoundError("No NEW CSV found after step 1.")
    print(f"Detected latest CSV: {latest_csv}")

    # STEP 2
    step2_start, _ = _run_python(update_display_script)
    latest_xlsx = _find_latest(XLSX_PATTERN_SAFE, [CHECK_DIR], min_mtime=step2_start.timestamp())
    if not latest_xlsx:
        raise FileNotFoundError("No NEW XLSX found after step 2.")
    print(f"Detected latest XLSX: {latest_xlsx}")

    # STEP 3
    target_copy = EXCEL_MANIP_DIR / latest_xlsx.name
    shutil.copy2(latest_xlsx, target_copy)
    print(f"Copied to: {target_copy}")

    # STEP 4
    _run_python(excel_manip)

    # STEP 5
    if RUN_SORT_TSVS:
        print("\n--- Step 5: Running excel_manipulation/sort_all_tsv.py ---")
        _run_python(sort_all_tsv)
        print("--- Step 5 completed ---")

    print("=== Pipeline completed successfully ===")
    _cleanup_files()


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as cpe:
        print(f"\nERROR: A script failed with exit code {cpe.returncode}")
        sys.exit(cpe.returncode)
    except Exception as e:
        print(f"\nERROR: {e}")
        sys.exit(1)