import os
import json
import pandas as pd
import time
import requests

# Assuming 'auth' and 'config' modules exist in the same directory
from auth import get_auth_headers
from config import ONTOSERVER_BASE_URL

# --- CONFIGURATION ---
CONCEPT_MAP_ID = "e04bc206-b9b2-46d4-ad52-6fe8234a2490"  # Set your ConceptMap ID here
INPUT_FILENAME = "code_list.xlsx"                  # Set your input Excel filename here
OUTPUT_FILENAME = "translated_output.xlsx"               # Set your output Excel filename here

def get_or_cache_concept_map(concept_map_id):
    """
    Fetches a ConceptMap from Ontoserver or loads it from a local cache.
    """
    filename = f"{concept_map_id}.json"
    if os.path.exists(filename):
        print(f"Loading ConceptMap {concept_map_id} from {filename}")
        with open(filename, "r") as f:
            return json.load(f)
    else:
        url = f"{ONTOSERVER_BASE_URL}/ConceptMap/{concept_map_id}"
        headers = get_auth_headers()
        print(f"Fetching ConceptMap {concept_map_id} from Ontoserver...")
        response = requests.get(url, headers=headers, timeout=600)
        response.raise_for_status()
        concept_map_data = response.json()
        with open(filename, "w") as f:
            json.dump(concept_map_data, f, indent=2)
        print(f"ConceptMap {concept_map_id} saved to {filename}")
        return concept_map_data

def create_translation_lookup(concept_map_json):
    """
    Creates a fast lookup dictionary from the ConceptMap JSON.
    """
    lookup = {}
    if "group" not in concept_map_json:
        print("Warning: No 'group' found in ConceptMap. Cannot create lookup.")
        return lookup

    for group in concept_map_json["group"]:
        if "element" not in group:
            continue
        for element in group["element"]:
            source_code = element.get("code")
            if source_code and "target" in element and element["target"]:
                # Assuming one-to-one mapping for simplicity
                target = element["target"][0]
                target_code = target.get("code")
                target_display = target.get("display", "")
                lookup[source_code] = {"code": target_code, "display": target_display}
    return lookup

def main():
    # Step 1: Get or cache the ConceptMap JSON
    try:
        concept_map_json = get_or_cache_concept_map(CONCEPT_MAP_ID)
    except requests.exceptions.HTTPError as e:
        print(f"Error fetching ConceptMap: {e}")
        print("Please check the CONCEPT_MAP_ID and the Ontoserver URL in your config.")
        return

    # Step 2: Create a local lookup dictionary for fast translation
    print("Building local translation lookup table...")
    translation_lookup = create_translation_lookup(concept_map_json)
    if not translation_lookup:
        print("Error: Failed to create a valid translation lookup. Exiting.")
        return
    print(f"Lookup table built with {len(translation_lookup)} mappings.")

    # Step 3: Read input Excel
    try:
        df = pd.read_excel(INPUT_FILENAME, header=None, dtype=str)
    except FileNotFoundError:
        print(f"Error: The input file '{INPUT_FILENAME}' was not found.")
        return

    # Step 4: Add a second column if it doesn't exist
    if df.shape[1] < 2:
        df[1] = ""

    # Step 5: Prepare output DataFrame with consistent headers
    out_df = df.copy()
    out_df.columns = ["Source Code", "Source Display"]
    out_df["Target Code"] = ""
    out_df["Target Display"] = ""

    # Step 6: Process codes locally
    print(f"Processing {len(df)} codes...")
    for idx, row in out_df.iterrows():
        source_code = str(row["Source Code"]).strip()
        
        # Look up the translation in the local dictionary
        translation = translation_lookup.get(source_code)
        
        if translation:
            out_df.at[idx, "Target Code"] = translation["code"]
            out_df.at[idx, "Target Display"] = translation["display"]
        else:
            out_df.at[idx, "Target Code"] = "No map found"
            out_df.at[idx, "Target Display"] = ""
    
    # Step 7: Save final results
    out_df.to_excel(OUTPUT_FILENAME, index=False)
    print("All codes processed and saved.")

if __name__ == "__main__":
    main()