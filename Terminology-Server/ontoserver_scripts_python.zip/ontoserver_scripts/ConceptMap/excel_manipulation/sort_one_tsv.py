import csv
import os

# ===== CONFIGURATION =====
file_name = "ReferralService.tsv"      # Change this to your TSV file name
column_index = 4               # 1-based index of the column to sort by
output_file_name = "ReferralService_sorted.tsv"  # Name of the output file
folder_name = "TSV_Outputs"    # Folder where the TSV file is stored
# ==========================

# Build full paths
input_path = os.path.join(folder_name, file_name)
output_path = os.path.join(folder_name, output_file_name)

def sort_tsv_by_column(input_file, output_file, column_index):
    """
    Sorts a TSV file by a specified column while preserving the header.
    """
    col_idx = column_index - 1

    # Read the TSV file
    with open(input_file, 'r', newline='', encoding='utf-8') as infile:
        reader = list(csv.reader(infile, delimiter='\t'))

    header, rows = reader[0], reader[1:]

    # Sort rows by the specified column
    rows.sort(key=lambda x: x[col_idx])

    # Write the sorted data to the output file
    with open(output_file, 'w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile, delimiter='\t')
        writer.writerow(header)
        writer.writerows(rows)

# Run the sort
sort_tsv_by_column(input_path, output_path, column_index)
print(f"Sorted file saved as: {output_path}")