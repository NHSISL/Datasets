import pandas as pd
import os
import sys
from pathlib import Path

# ----------------------------------------------------------------------
# 0) Auto-discover the latest pipeline workbook in this folder
# ----------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
RESULTS_PATTERN = "concept_map_results_*_excel-safe.xlsx"

def find_latest_results_xlsx(folder: Path, pattern: str) -> Path:
    """
    Find the most recently modified Excel file matching the pipeline pattern in `folder`.
    Ignores any other spreadsheets. Raises FileNotFoundError if none found.
    """
    candidates = sorted(
        folder.glob(pattern),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    if not candidates:
        raise FileNotFoundError(
            f"No file found matching '{pattern}' in:\n  {folder}\n"
            "Expected the pipeline to have copied today's file here."
        )
    return candidates[0]


def process_concept_map_data():
    # ====================================================================
    # --- 1. CONFIGURATION: Change these values as needed ---
    # ====================================================================

    # Input: now auto-detected; no need to edit a date each run
    try:
        INPUT_XLSX_PATH = find_latest_results_xlsx(SCRIPT_DIR, RESULTS_PATTERN)
        print(f"[excel_manip] Using input workbook: {INPUT_XLSX_PATH.name}")
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please ensure the pipeline copied a file named like "
              "'concept_map_results_YYYY-MM-DD_excel-safe.xlsx' into this folder.")
        return

    # Output File/Directory Names
    OUTPUT_EXCEL_FILE = 'processed_concept_map_results.xlsx'
    TSV_OUTPUT_DIRECTORY = 'TSV_Outputs'

    # Column Names (Ensure these match the casing in your Excel file)
    MAPPING_COLUMN = 'mapping_found'
    MODE_COLUMN = 'Mode'
    CODE_COLUMN = 'Code'

    # ====================================================================
    # --- 2. Validation and Data Loading ---
    # ====================================================================

    input_path_str = str(INPUT_XLSX_PATH)
    print(f"Reading data from '{INPUT_XLSX_PATH.name}'...")
    try:
        # Read the first sheet (default); keep everything as text to avoid type issues
        df = pd.read_excel(input_path_str, dtype=str)
    except Exception as e:
        print(f"An error occurred while reading the Excel file: {e}")
        return

    # Convert mapping_found column to string and uppercase for robust TRUE/FALSE check
    if MAPPING_COLUMN not in df.columns:
        print(f"Error: Column '{MAPPING_COLUMN}' not found in input. Columns present: {list(df.columns)}")
        return
    df[MAPPING_COLUMN] = df[MAPPING_COLUMN].astype(str).str.upper()

    # --- 3. Separate TRUE and FALSE mappings ---
    df_true = df[df[MAPPING_COLUMN] == 'TRUE'].copy()
    df_false = df[df[MAPPING_COLUMN] == 'FALSE'].copy()

    print(f"Found {len(df_true)} TRUE mappings.")
    print(f"Found {len(df_false)} FALSE mappings to process by Mode.")

    # ====================================================================
    # --- 4. Create New Excel File and Sheets ---
    # ====================================================================

    print(f"Creating output Excel file: '{OUTPUT_EXCEL_FILE}'...")

    # Use ExcelWriter to handle multiple sheets
    with pd.ExcelWriter(OUTPUT_EXCEL_FILE, engine='openpyxl') as writer:

        # Write the TRUE sheet first
        df_true.to_excel(writer, sheet_name='True_Mappings', index=False)
        print("  - Sheet 'True_Mappings' created.")

        # --- 5. Split FALSE values by "Mode", write to sheets, and create TSVs ---

        # Create directory for TSV files
        os.makedirs(TSV_OUTPUT_DIRECTORY, exist_ok=True)
        print(f"  - TSV files will be saved in the '{TSV_OUTPUT_DIRECTORY}' folder.")

        if MODE_COLUMN not in df_false.columns:
            print(f"Warning: Column '{MODE_COLUMN}' not found among FALSE rows. "
                  f"Available columns: {list(df_false.columns)}")
            false_modes = []
        else:
            false_modes = df_false[MODE_COLUMN].unique()

        for mode in false_modes:
            # Create a safe name for the sheet and file (replace potential slashes)
            safe_mode_name = str(mode).replace('/', '_').replace('\\', '_').strip() or "BlankMode"

            # Filter the FALSE data for the current Mode
            df_mode = df_false[df_false[MODE_COLUMN] == mode].copy()

            # Write the Mode-specific sheet to the Excel file
            df_mode.to_excel(writer, sheet_name=safe_mode_name[:31], index=False)  # Excel sheet name max 31 chars
            print(f"  - Sheet '{safe_mode_name[:31]}' created.")

            # Clean 'Code' column for TSVs: Remove a leading single quote
            # (kept exactly as you had it; change to .str[:] if you later want to preserve it)
            if CODE_COLUMN not in df_mode.columns:
                print(f"Warning: Column '{CODE_COLUMN}' not found for mode '{mode}'. Skipping TSV for this mode.")
                continue

            df_tsv = df_mode.copy()
            df_tsv[CODE_COLUMN] = df_tsv[CODE_COLUMN].astype(str).str.lstrip("'")

            # Define TSV file path
            tsv_filename = os.path.join(TSV_OUTPUT_DIRECTORY, f'{safe_mode_name}.tsv')

            # Write to TSV (Tab Separated Values)
            df_tsv.to_csv(tsv_filename, sep='\t', index=False)
            print(f"  - TSV file saved: '{tsv_filename}'")

    print("\nProcessing complete!")
    print(f"New Excel file saved as: {OUTPUT_EXCEL_FILE}")
    print(f"TSV files saved in the: {TSV_OUTPUT_DIRECTORY} folder.")


if __name__ == "__main__":
    process_concept_map_data()