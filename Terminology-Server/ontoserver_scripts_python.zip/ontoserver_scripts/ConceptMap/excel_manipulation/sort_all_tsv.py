import csv
import os
import glob

# ===== CONFIGURATION =====
folder_name = "TSV_Outputs"     # Folder where the TSV files are stored
column_index = 4                 # 1-based index of the column to sort by for ALL files
output_suffix = "sorted"         # Suffix to append to output files, e.g. *_sorted.tsv
glob_pattern = "*.tsv"           # Pattern for matching input files

# Filter settings
display_column_name = "Display"  # Column name to check
filter_value_exact = "Unknown"   # Remove rows where Display == "Unknown"
case_insensitive_name = False    # Match the column name case-sensitively (default: False)
# ==========================

def find_column_index(header, target_name, case_insensitive=False):
    """
    Returns the 0-based index of the header that exactly matches target_name.
    If not found, returns None. Does not trim/normalize.
    """
    if case_insensitive:
        target = target_name.lower()
        for i, h in enumerate(header):
            if h.lower() == target:
                return i
    else:
        for i, h in enumerate(header):
            if h == target_name:
                return i
    return None

def sort_and_filter_tsv(
    input_file,
    output_file,
    sort_col_index_1based,
    display_col_name,
    filter_value,
    case_insensitive_name=False
):
    """
    - Removes rows where the Display column == filter_value (exact, no trimming/normalization).
    - Sorts remaining rows by the specified 1-based column index (lexicographically).
    - Preserves header and exact field values.
    - Rows missing the sort column are appended after the sorted rows in original order.
    """
    sort_idx = sort_col_index_1based - 1

    with open(input_file, 'r', newline='', encoding='utf-8') as infile:
        reader = list(csv.reader(infile, delimiter='\t'))

    if not reader:
        # Empty file: write nothing
        with open(output_file, 'w', newline='', encoding='utf-8') as outfile:
            pass
        return {
            "total_rows": 0,
            "kept_after_filter": 0,
            "removed_by_filter": 0,
            "sorted": 0,
            "missing_sort_col": 0,
            "had_display_col": False
        }

    header, rows = reader[0], reader[1:]
    total_rows = len(rows)

    # Locate Display column by name (exact match unless configured otherwise)
    display_idx = find_column_index(header, display_col_name, case_insensitive=case_insensitive_name)
    had_display_col = display_idx is not None
    # Filter rows: drop those with Display == "Unknown" (exact match; we don't strip whitespace)
    if had_display_col:
        kept_rows = []
        removed_rows = 0
        for r in rows:
            # If the row is too short to have Display, we keep it
            if len(r) > display_idx and r[display_idx] == filter_value:
                removed_rows += 1
            else:
                kept_rows.append(r)
    else:
        kept_rows = rows
        removed_rows = 0

    # Split kept rows by presence of sort column
    has_col = []
    missing_col = []
    for r in kept_rows:
        if len(r) > sort_idx:
            has_col.append(r)
        else:
            missing_col.append(r)

    # Sort (stable) only the rows that have the sort column
    has_col.sort(key=lambda x: x[sort_idx])

    # Recombine
    final_rows = has_col + missing_col

    with open(output_file, 'w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile, delimiter='\t', lineterminator='\n')
        writer.writerow(header)
        writer.writerows(final_rows)

    return {
        "total_rows": total_rows,
        "kept_after_filter": len(kept_rows),
        "removed_by_filter": removed_rows,
        "sorted": len(has_col),
        "missing_sort_col": len(missing_col),
        "had_display_col": had_display_col
    }

def sort_all_tsv_in_folder(folder_name, column_index, output_suffix="sorted", glob_pattern="*.tsv"):
    """
    Sorts and filters all TSV files in a folder.
    - Removes rows where Display == "Unknown" (exact).
    - Sorts by the specified 1-based column index.
    - Skips files that already appear to be sorted outputs.
    """
    folder = os.path.abspath(folder_name)
    os.makedirs(folder, exist_ok=True)

    pattern = os.path.join(folder, glob_pattern)
    files = sorted(glob.glob(pattern))

    suffix_marker = f"_{output_suffix}.tsv".lower()

    processed = 0
    skipped = 0
    results = []

    for input_path in files:
        base = os.path.basename(input_path)
        low = base.lower()

        if not os.path.isfile(input_path) or not low.endswith(".tsv"):
            continue

        if low.endswith(suffix_marker):
            skipped += 1
            print(f"Skipping already-sorted-looking file: {base}")
            continue

        name, ext = os.path.splitext(base)
        output_name = f"{name}_{output_suffix}{ext}"
        output_path = os.path.join(folder, output_name)

        try:
            stat = sort_and_filter_tsv(
                input_path,
                output_path,
                column_index,
                display_column_name,
                filter_value_exact,
                case_insensitive_name=case_insensitive_name
            )
            processed += 1
            results.append((base, output_name, stat))
            disp_col_msg = "found" if stat["had_display_col"] else "NOT found"
            print(
                f"Processed {base} -> {output_name} | "
                f"Display column: {disp_col_msg} | "
                f"removed: {stat['removed_by_filter']}, kept: {stat['kept_after_filter']}, total(before filter): {stat['total_rows']} | "
                f"sorted rows: {stat['sorted']}, missing-sort-col rows: {stat['missing_sort_col']}"
            )
        except Exception as e:
            print(f"ERROR processing {base}: {e}")

    print("\n=== Summary ===")
    print(f"Folder: {folder}")
    print(f"Sort column index (1-based): {column_index}")
    print(f"Processed files: {processed}")
    print(f"Skipped (already sorted): {skipped}")
    if results:
        print("\nOutputs:")
        for src, dst, stat in results:
            disp_col_msg = "found" if stat["had_display_col"] else "NOT found"
            print(
                f" - {src} -> {dst} | Display column: {disp_col_msg} | "
                f"removed={stat['removed_by_filter']}, kept={stat['kept_after_filter']}, total={stat['total_rows']} | "
                f"sorted={stat['sorted']}, missing-sort-col={stat['missing_sort_col']}"
            )

# Run the batch process
if __name__ == "__main__":
    sort_all_tsv_in_folder(folder_name, column_index, output_suffix=output_suffix, glob_pattern=glob_pattern)