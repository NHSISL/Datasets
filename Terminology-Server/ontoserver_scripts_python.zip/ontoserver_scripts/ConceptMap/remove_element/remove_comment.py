#!/usr/bin/env python3
import json
from typing import Dict, Any, List


# =========================
# CONFIGURE THESE (optional)
# =========================
INPUT_FILE = "conceptmap_to_validate.json"
OUTPUT_FILE = "conceptmap_to_validate_cleaned.json"

# The comment text to match for removal, e.g. "automapping - not validated"
COMMENT_TO_REMOVE = "automapping - not validated"

# Match mode:
#   - "exact": comment must equal COMMENT_TO_REMOVE
#   - "contains": COMMENT_TO_REMOVE must appear as a substring in comment
MATCH_MODE = "exact"         # "exact" | "contains"

# Case sensitivity:
CASE_SENSITIVE = False
# =========================


def _match(a: str, b: str, mode: str, case_sensitive: bool) -> bool:
    """
    Return True if comment a matches pattern b according to mode and case sensitivity.
    mode: "exact" or "contains"
    """
    if a is None:
        return False

    if not case_sensitive:
        a = a.lower()
        b = b.lower()

    if mode == "exact":
        return a == b
    elif mode == "contains":
        return b in a
    else:
        raise ValueError("MATCH_MODE must be 'exact' or 'contains'")


def remove_elements_by_target_comment(
    concept_map: Dict[str, Any],
    comment_pattern: str,
    match_mode: str = "exact",
    case_sensitive: bool = False
) -> Dict[str, Any]:
    """
    Return a new ConceptMap dict where elements are removed if ANY of their targets'
    'comment' matches the comment_pattern under the specified matching rules.

    - If an element has multiple targets and at least one target's comment matches,
      the entire element is removed.
    """
    groups: List[Dict[str, Any]] = concept_map.get("group", [])
    total_groups = len(groups)
    total_elements_before = 0
    total_elements_after = 0
    removed_elements = 0
    matched_examples = 0
    for group in groups:
        elements = group.get("element", []) or []
        total_elements_before += len(elements)

        kept_elements = []
        for el in elements:
            targets = el.get("target", []) or []
            # Determine if any target's comment matches the pattern
            any_match = False
            for t in targets:
                cmt = t.get("comment")
                if _match(cmt, comment_pattern, match_mode, case_sensitive):
                    any_match = True
                    matched_examples += 1
                    break
            if any_match:
                removed_elements += 1
            else:
                kept_elements.append(el)

        group["element"] = kept_elements
        total_elements_after += len(kept_elements)

    # Optional: remove groups that became empty (comment out if you prefer to keep empty groups)
    filtered_groups = []
    empty_groups_removed = 0
    for g in concept_map.get("group", []):
        if g.get("element"):
            filtered_groups.append(g)
        else:
            empty_groups_removed += 1
    concept_map["group"] = filtered_groups

    print("=== ConceptMap Cleaning Report ===")
    print(f"Groups (before): {total_groups}")
    print(f"Empty groups removed: {empty_groups_removed}")
    print(f"Elements (before): {total_elements_before}")
    print(f"Elements removed: {removed_elements}")
    print(f"Elements (after): {total_elements_after}")
    print(f"Targets matched (instances): {matched_examples}")
    print("----------------------------------")
    print(f"Match mode: {match_mode} | Case sensitive: {case_sensitive}")
    print(f"Pattern: {comment_pattern!r}")
    print("==================================")

    return concept_map


def main():
    # Load
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        concept_map = json.load(f)

    # Transform
    cleaned = remove_elements_by_target_comment(
        concept_map,
        COMMENT_TO_REMOVE,
        match_mode=MATCH_MODE,
        case_sensitive=CASE_SENSITIVE,
    )

    # Save
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(cleaned, f, indent=2, ensure_ascii=False)

    print(f"✅ Cleaned ConceptMap saved to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()