import json

# === CHANGE THESE TWO LINES ONLY ===
INPUT_FILE = "conceptmap.json"
OUTPUT_FILE = "conceptmap_cleaned.json"
# ===================================

def remove_unmatched_concepts(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as f:
        concept_map = json.load(f)

    for group in concept_map.get("group", []):
        filtered_elements = []
        for element in group.get("element", []):
            targets = element.get("target", [])
            if any(t.get("equivalence") != "unmatched" for t in targets):
                filtered_elements.append(element)
        group["element"] = filtered_elements

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(concept_map, f, indent=2, ensure_ascii=False)

    print(f"Cleaned ConceptMap saved to {output_file}")

# Run the function using the hard-coded file names
remove_unmatched_concepts(INPUT_FILE, OUTPUT_FILE)