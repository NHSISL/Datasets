#!/usr/bin/env python3
"""
Update ConceptMap target equivalence to:
- 'equivalent' when the source and target display strings contain the same words
  (ignoring order, case, punctuation, and accents), with additional synonym normalisation
  and optional handling for trailing 'NEC'/'NOS'/'UNSPECIFIED' in the source display.
- NEW: 'wider' when the only difference between source and target is the word 'other'
  (or 'other' AND 'unspecified'/'specified'), after applying the same normalisation 
  rules and stripping.
  
  *** MODIFIED: Now handles general plurals by removing a trailing 's' for most words. ***

Default behaviour:
- Upgrade from 'inexact' -> 'equivalent' (unless ONLY_FROM_INEXACT is set to False).
- NEC/NOS/UNSPECIFIED stripping applies only to source if ALLOW_SOURCE_TRAILING_NEC_NOS_UNSPECIFIED is True.

New options:
- ENABLE_SYNONYMS: apply token-level synonym normalisation (incl. multi-token expansion).
- ALLOW_SOURCE_TRAILING_NEC_NOS_UNSPECIFIED: strip trailing NEC/NOS/UNSPECIFIED only from the source display.

Usage:
1) No arguments:
    - Reads: 	'conceptmap_cleaned.json'
    - Writes: 'conceptmap_updated.json'

2) With arguments:
    python update_conceptmap_equivalence.py input.json output.json

Author: (you)
"""

from __future__ import annotations
import json
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path
from typing import List

# --- Configuration toggles ---
ONLY_FROM_INEXACT = True 			# set to False to promote from any non-'equivalent' value
ENABLE_SYNONYMS = True 			# set to False to disable synonym normalisation
# RENAMED FLAG to reflect new functionality
ALLOW_SOURCE_TRAILING_NEC_NOS_UNSPECIFIED = True 	# strip trailing NEC/NOS/UNSPECIFIED from source display before matching

# --- Synonym Canonicalisation Config ---
# 1) Single-token -> canonical single token
SYNONYM_TOKEN_MAP: dict[str, str] = {
    # Units / measure words
    "ug": "microgram",
    "mcg": "microgram",
    "micrograms": "microgram",
    "microgramme": "microgram",
    "microgrammes": "microgram",
    "milligram": "mg",
    "milligrams": "mg",
    "gramme": "gram",
    "grammes": "gram",
    "millilitre": "ml",
    "millilitres": "ml",
    "litre": "l",
    "litres": "l",
    "tablet": "tablet",
    "tabs": "tablet",
    "tab": "tablet",
    # Common clinical abbreviations / variants
    "dm": "diabetes",
    "t2dm": "type2diabetes",
    "insulindependent": "insulin",
    "noninsulin": "noninsulin",
    # Vitamin B12 / cobalamin family
    "cobalamin": "vitaminb12",
    "b-12": "b12",
    "vitb12": "vitaminb12",
}

# 2) Single-token -> multi-token expansion
SYNONYM_TOKEN_EXPANSION: dict[str, List[str]] = {
    "mi": ["myocardial", "infarction"],
    "vitaminb12": ["vitamin", "b12"],
    "type2diabetes": ["type", "2", "diabetes"],
}

# 3) Multi-token phrase normalisation (regex)
PHRASE_NORMALISATIONS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\bmyocardial\s*-\s*infarction\b", flags=re.I), "myocardial infarction"),
    (re.compile(r"\btype\s*ii\b", flags=re.I), "type 2"),
    (re.compile(r"\bnon[-\s]*insulin[-\s]*dependent\b", flags=re.I), "noninsulin dependent"),
    (re.compile(r"\binsulin[-\s]*dependent\b", flags=re.I), "insulin dependent"),
]


def strip_trailing_nec_nos_unspecified(text: str | None) -> str | None:
    """
    Removes a trailing 'NEC', 'NOS', or 'unspecified' (or a combination)
    from the end of the string, if present.
    """
    if not text:
        return text
    # Added 'unspecified' to the non-capturing group
    pattern = re.compile(
        r"""(?ix)
            [\s,;:-]* (?:\(\s*)? 	 	
            (?:nec|nos|unspecified) 	# <-- MODIFIED: Added 'unspecified'
            (?:\s*\))? 	 	
            \s*$ 	 	 	
        """
    )
    return re.sub(pattern, "", text)


def ascii_fold_with_micro(s: str) -> str:
    """Replace micro signs and fold to ASCII."""
    if s is None:
        return ""
    s = s.replace("µ", "u").replace("μ", "u")
    norm = unicodedata.normalize("NFKD", s)
    return norm.encode("ascii", "ignore").decode("ascii")


def roman_to_int_token(tok: str) -> str:
    """Convert roman numeral token to Arabic numeral if valid."""
    t = tok.lower()
    if not re.fullmatch(r"[ivxlcdm]+", t):
        return tok
    values = {'i': 1, 'v': 5, 'x': 10, 'l': 50, 'c': 100, 'd': 500, 'm': 1000}
    total = 0
    prev = 0
    for ch in reversed(t):
        val = values[ch]
        if val < prev:
            total -= val
        else:
            total += val
            prev = val
    if 1 <= total <= 3999:
        return str(total)
    return tok


def apply_phrase_normalisations(s: str) -> str:
    out = s
    for pat, repl in PHRASE_NORMALISATIONS:
        out = pat.sub(repl, out)
    return out


def canonicalize_tokens(tokens: list[str]) -> list[str]:
    """Apply token-level canonicalisation, synonym expansion, AND plural stripping."""
    out: list[str] = []
    for tok in tokens:
        tok = roman_to_int_token(tok)
        
        # 1. Synonym Expansion (takes priority)
        if ENABLE_SYNONYMS and tok in SYNONYM_TOKEN_EXPANSION:
            out.extend(SYNONYM_TOKEN_EXPANSION[tok])
            continue
            
        # 2. Token Mapping (e.g., ug -> microgram)
        if ENABLE_SYNONYMS and tok in SYNONYM_TOKEN_MAP:
            out.append(SYNONYM_TOKEN_MAP[tok])
            continue
            
        # 3. Specific Plural Handling (e.g., tablet/s)
        if ENABLE_SYNONYMS and tok.endswith("s"):
            base = tok[:-1]
            if base in ("tablet", "capsule", "sachet", "patch", "gram"):
                tok = base
        
        # 4. NEW: General Plural Handling
        # If the token is 4+ characters long (to avoid stemming short, non-plural words like 'is') 
        # and ends with 's', remove the 's' for general stemming/plural handling.
        # Ensure 's' is not part of a number (e.g., 2s)
        if tok.endswith('s') and len(tok) > 3 and not tok[-2].isdigit():
            tok = tok[:-1]
            
        out.append(tok)
    return out


def normalize_to_tokens(text: str, *, is_source: bool = False) -> Counter:
    """Normalise text and return a bag-of-words (Counter) of tokens."""
    if text is None:
        return Counter()
    # MODIFIED: Use the new stripping function and config flag
    if is_source and ALLOW_SOURCE_TRAILING_NEC_NOS_UNSPECIFIED:
        text = strip_trailing_nec_nos_unspecified(text) or ""
    text = apply_phrase_normalisations(text)
    norm = ascii_fold_with_micro(text).lower()
    raw_tokens = re.findall(r"[a-z0-9]+", norm)
    canon_tokens = canonicalize_tokens(raw_tokens)
    return Counter(t for t in canon_tokens if t)


def words_match_ignoring_order(a: str | None, b: str | None) -> bool:
    """True if source and target share exactly the same multiset of canonical tokens."""
    ta = normalize_to_tokens(a or "", is_source=True)
    tb = normalize_to_tokens(b or "", is_source=False)
    if not ta or not tb:
        return False
    return ta == tb


def is_other_only_difference(source: str | None, target: str | None) -> bool:
    """
    MODIFIED RULE:
    True if the only difference between source and target tokens is the word 'other' 
    and/or 'specified' AND/OR 'unspecified' (after normalisation and stripping on source).
    """
    ta = normalize_to_tokens(source or "", is_source=True)
    tb = normalize_to_tokens(target or "", is_source=False)
    if not ta or not tb:
        return False
        
    diff = ta - tb
    
    # If 'other' is not in the source difference, this rule cannot apply.
    if "other" not in diff:
        return False

    # Create a new Counter of the differences, excluding specific tokens.
    filtered_diff = diff.copy()
    
    # Remove 'other', 'specified', AND 'unspecified' from the difference counter
    filtered_diff.pop("other", None)
    filtered_diff.pop("specified", None)
    filtered_diff.pop("unspecified", None) # <-- MODIFIED: Added 'unspecified'

    # Check if the remaining difference is empty. 
    # This means the ONLY difference was 'other', 'specified', and/or 'unspecified'.
    return sum(filtered_diff.values()) == 0


def update_conceptmap_equivalences(conceptmap: dict, only_from_inexact: bool = True) -> dict:
    """
    Walk the ConceptMap structure and update 'equivalence':
    - 'wider' if only difference is 'other' or 'other specified' or 'other unspecified'
    - 'equivalent' if tokens match exactly (including plural match and stripping)
    """
    groups = conceptmap.get("group", [])
    changes = 0

    for grp in groups:
        elements = grp.get("element", []) or []
        for elem in elements:
            src_disp = elem.get("display")
            targets = elem.get("target", []) or []
            for tgt in targets:
                tgt_disp = tgt.get("display")
                current_eq = tgt.get("equivalence")

                # Check for 'wider' first (Other/Other specified/Other unspecified difference)
                if is_other_only_difference(src_disp, tgt_disp):
                    # Promote to 'wider' regardless of previous value (as per 'equivalent' logic)
                    if current_eq != "wider":
                        tgt["equivalence"] = "wider"
                        changes += 1

                # Check for 'equivalent' (Exact token match, including plural match and stripping)
                elif words_match_ignoring_order(src_disp, tgt_disp):
                    if only_from_inexact:
                        if current_eq == "inexact":
                            tgt["equivalence"] = "equivalent"
                            changes += 1
                    else:
                        if current_eq != "equivalent":
                            tgt["equivalence"] = "equivalent"
                            changes += 1

    conceptmap["_updates_made"] = changes
    return conceptmap


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(data: dict, path: Path) -> None:
    # Ensure "_updates_made" is removed before saving
    data_to_save = data.copy()
    data_to_save.pop("_updates_made", None) 
    with path.open("w", encoding="utf-8") as f:
        json.dump(data_to_save, f, ensure_ascii=False, indent=2)


def main():
    if len(sys.argv) == 1:
        in_path = Path("conceptmap_cleaned.json")
        out_path = Path("conceptmap_updated.json")
    elif len(sys.argv) == 2:
        in_path = Path(sys.argv[1])
        out_path = Path(sys.argv[1]).with_suffix(".updated.json")
    else:
        in_path = Path(sys.argv[1])
        out_path = Path(sys.argv[2])

    if not in_path.exists():
        sys.stderr.write(f"[ERROR] Input file not found: {in_path}\n")
        sys.exit(1)

    cm = load_json(in_path)
    # MODIFIED: Use the new configuration constant
    updated = update_conceptmap_equivalences(cm, only_from_inexact=ONLY_FROM_INEXACT)
    
    changes = updated.get("_updates_made", 0)
    # MODIFIED: Removed the redundant save call
    save_json(updated, out_path) 

    print(f"Updated file written to: {out_path}")
    print(f"Equivalence changes made: {changes}")


if __name__ == "__main__":
    main()