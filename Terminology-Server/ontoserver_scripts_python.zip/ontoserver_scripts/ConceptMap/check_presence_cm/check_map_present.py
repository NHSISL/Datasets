# -----------------------------------------------
# ConceptMap mapping checker (folder-based), batch-friendly + Excel-safe outputs
# - Streams big Excel files in chunks (openpyxl read_only)
# - Auto-detects header row (skips banner rows like Excel Online warnings)
# - Accepts aliases for 'Code' and 'system' columns (NAME included)
# - Normalizes system URIs incl. lower-casing host (LDS.nhs == lds.nhs)
# - Builds fast ConceptMap index (R4 + common R5/STU3 variants)
# - Writes two CSVs in streaming mode (standard + Excel-safe)
# - Optionally writes XLSX in streaming mode (can be disabled for very large files)
# - Passthrough of ALL original columns + explicit source_code_used/system
# -----------------------------------------------

import os
import csv
import json
import re
from datetime import date
from collections import defaultdict
from urllib.parse import urlsplit, urlunsplit

import pandas as pd
from openpyxl import load_workbook, Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment

# ========== CONFIG ==========
# Input Excel
SPREADSHEET_FILE = 'Codes by Use Count (OLIDS).xlsx'
SHEET_NAME = None  # None = first sheet; or put the exact sheet name

# JSON folder (ConceptMap files)
JSON_FOLDER = './json'
SCAN_RECURSIVELY = True

# Batching for large Excel
BATCH_SIZE = 50000   # rows per chunk
HEADER_SCAN_ROWS = 50  # how many initial rows to scan to find real header

# Matching behavior
STOP_AT_FIRST_MATCH = True
CASE_SENSITIVE_CODE = True
NORMALIZE_SYSTEMS = True

# Column aliases (header auto-detection will try these)
CODE_COLUMN_ALIASES = ['Code', 'code', 'CODE', 'Source Code', 'Code (source)', 'NAME', 'Id', 'ID']
SYSTEM_COLUMN_ALIASES = ['system', 'System', 'SYSTEM', 'Source System', 'source', 'fromSystem', 'Clinical System']

# Optional system synonyms after normalization (post-canonical)
SYSTEM_SYNONYMS = {
    # 'http://snomed.info/sct/': 'http://snomed.info/sct/',
    # 'http://dmd.nhs.uk/': 'http://dmd.nhs.uk/',
}

# Output filenames
today_str = date.today().isoformat()
OUTPUT_CSV = f'concept_map_results_{today_str}.csv'
OUTPUT_CSV_EXCEL_SAFE = f'concept_map_results_{today_str}_excel-safe.csv'
OUTPUT_XLSX = f'concept_map_results_{today_str}.xlsx'

# Excel-safe / text detection
IDENTIFIER_REGEX = re.compile(r'^\d{11,}$')  # 11+ digits treated as identifier-like
# Always write these as text in Excel-safe CSV / XLSX
TEXT_COLS_BASE = {'Code', 'system', 'mapped_codes', 'target_systems', 'source_code_used', 'source_system_used'}

# Multi-value separators
SEP_VALUES = '; '
SEP_CM = ' | '
PAIR_JOIN = ' ⟷ '
TRIPLE_JOIN = ' ⟷ '

# XLSX options (streaming)
WRITE_XLSX = True          # set False for extremely large files to save time/memory
WRAP_TEXT_COLS = {'mapped_display', 'targets_pairs', 'conceptmap_file', 'conceptmap_name', 'conceptmap_title'}


# ========== HELPERS ==========

def canon_system(u: str) -> str:
    """Normalize system URIs to reduce false negatives.
    - Force http scheme (normalize https->http for equality)
    - Lower-case host only (host is case-insensitive)
    - Strip trailing slash and re-add one (consistent ending)
    - Apply SYSTEM_SYNONYMS
    """
    if not u:
        return ''
    s = str(u).strip()
    # Normalize scheme https->http
    if s.startswith('https://'):
        s = 'http://' + s[len('https://'):]
    # Parse to lower-case netloc (host:port), keep path+query+frag intact
    try:
        parts = urlsplit(s)
        scheme = parts.scheme or 'http'
        netloc = parts.netloc.lower()  # host is case-insensitive
        path = parts.path or ''
        query = parts.query or ''
        frag = parts.fragment or ''
        s = urlunsplit((scheme, netloc, path, query, frag))
    except Exception:
        # Fallback if not a standard URL
        pass
    # Remove trailing slash then add one
    s = s.rstrip('/') + '/'
    # Collapse accidental triple slashes after scheme
    while '://' in s and '///' in s:
        s = s.replace('///', '//')
    # Apply synonyms
    s = SYSTEM_SYNONYMS.get(s, s)
    return s

def maybe_canon_system(u: str) -> str:
    return canon_system(u) if NORMALIZE_SYSTEMS else (str(u).strip() if u else '')

def norm_code(c: str) -> str:
    if c is None:
        return ''
    s = str(c).strip()
    return s if CASE_SENSITIVE_CODE else s.lower()

def safe_str(x):
    return '' if x is None else str(x)

def get_group_source_candidates(group: dict) -> list:
    """Return all plausible fields identifying group source scope (R4/R5 mixes)."""
    candidates = []
    if 'source' in group:
        candidates.append(group.get('source'))
    for k in ('sourceScope', 'sourceCanonical', 'sourceUri'):
        if k in group:
            candidates.append(group.get(k))
    return [x for x in candidates if x]

def to_pairs_str(targets):
    """Compact pairs: 'code ⟷ display ⟷ system' per target."""
    items = []
    for t in targets:
        code = safe_str(t.get('code', ''))
        disp = safe_str(t.get('display', ''))
        sys_ = safe_str(t.get('system', ''))
        if sys_:
            items.append(TRIPLE_JOIN.join([code, disp, sys_]))
        else:
            items.append(PAIR_JOIN.join([code, disp]))
    return SEP_VALUES.join(items)

def excel_safe_value(val: str, colname: str) -> str:
    """Prefix with apostrophe for Excel-safe CSV if text-like or identifier-like."""
    s = '' if val is None else str(val)
    if s == '':
        return s
    if (colname in TEXT_COLS_BASE) or IDENTIFIER_REGEX.match(s):
        return s if s.startswith("'") else "'" + s
    return s


# ========== CONCEPTMAP INDEXING ==========

def iter_json_files(root_folder: str, recursive: bool):
    if recursive:
        for dirpath, _, filenames in os.walk(root_folder):
            for fn in filenames:
                if fn.lower().endswith('.json'):
                    yield os.path.join(dirpath, fn)
    else:
        for fn in os.listdir(root_folder):
            if fn.lower().endswith('.json'):
                yield os.path.join(root_folder, fn)

def build_cm_index(json_folder: str, recursive: bool):
    index = defaultdict(list)
    meta_list = []
    count_cm = 0
    count_groups = 0
    count_elements = 0
    failures = []

    for file_path in iter_json_files(json_folder, recursive):
        file_name = os.path.basename(file_path)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            failures.append((file_name, str(e)))
            continue
        if data.get('resourceType') != 'ConceptMap':
            continue

        count_cm += 1
        cm_meta = {
            'file_name': file_name,
            'name': data.get('name', ''),
            'title': data.get('title', ''),
            'url': data.get('url', ''),
            'version': data.get('version', '')
        }
        meta_list.append(cm_meta)

        groups = data.get('group', [])
        if not isinstance(groups, list):
            continue

        for group in groups:
            count_groups += 1
            sources = get_group_source_candidates(group)
            if not sources:
                continue

            norm_sources = [maybe_canon_system(s) for s in sources]
            elements = group.get('element', []) or []
            for element in elements:
                code_raw = element.get('code')
                if code_raw is None:
                    continue
                count_elements += 1
                code_key = norm_code(code_raw)

                targets = []
                for t in element.get('target', []) or []:
                    targets.append({
                        'code': t.get('code', ''),
                        'display': t.get('display', ''),
                        'system': t.get('system', ''),
                        'equiv_or_rel': t.get('equivalence') or t.get('relationship') or ''
                    })

                if targets:
                    for s in norm_sources:
                        key = (s, code_key)
                        index[key].append({
                            'targets': targets,
                            'cm_file': cm_meta['file_name'],
                            'cm_name': cm_meta['name'],
                            'cm_title': cm_meta['title'],
                            'cm_url': cm_meta['url'],
                            'cm_version': cm_meta['version']
                        })

    print(f"Loaded {count_cm} ConceptMap files; indexed {count_groups} groups and {count_elements} elements.")
    if failures:
        for fn, err in failures[:5]:
            print(f"⚠️ Could not load {fn}: {err}")
        if len(failures) > 5:
            print(f"…and {len(failures)-5} more failures.")
    return index, meta_list


# ========== EXCEL STREAM READER ==========

def find_header(ws, scan_rows: int, code_aliases, system_aliases):
    """
    Scan the first N rows to find a header row that contains both:
      - at least one system-like column
      - at least one code-like column
    Returns (header_row_idx, header_values, code_col_name, system_col_name)
    """
    code_aliases_lc = [a.lower() for a in code_aliases]
    system_aliases_lc = [a.lower() for a in system_aliases]

    for i, row in enumerate(ws.iter_rows(min_row=1, max_row=scan_rows, values_only=True), start=1):
        if not row:
            continue
        header = [safe_str(c).strip() for c in row]
        if not any(header):
            continue

        # Skip banner-like rows (very long single cell; typical Excel Online warning)
        non_empty = [h for h in header if h]
        if len(non_empty) == 1 and len(non_empty[0]) > 60:
            continue

        header_lc = [h.lower() for h in header]
        has_system = any(h in header_lc for h in system_aliases_lc)
        has_code = any(h in header_lc for h in code_aliases_lc)
        if has_system and has_code:
            system_name = next(header[idx] for idx, h in enumerate(header_lc) if h in system_aliases_lc)
            code_name = next(header[idx] for idx, h in enumerate(header_lc) if h in code_aliases_lc)
            return i, header, code_name, system_name

    raise ValueError(
        "Could not locate a valid header row containing a 'system' and 'code' column "
        f"(aliases tried: system={system_aliases}, code={code_aliases}). "
        "Check your sheet or extend the alias lists."
    )

def stream_rows(ws, header_row_idx: int, header: list, batch_size: int):
    """
    Yield lists of dicts (each dict is a row) in batches of size 'batch_size'.
    """
    col_count = len(header)
    batch = []
    for row in ws.iter_rows(min_row=header_row_idx+1, values_only=True):
        vals = list(row)[:col_count] + [''] * max(0, col_count - (len(row) if row else 0))
        record = {header[i]: vals[i] for i in range(col_count)}
        if any(safe_str(v).strip() for v in vals):
            batch.append(record)
        if len(batch) >= batch_size:
            yield batch
            batch = []
    if batch:
        yield batch


# ========== PROCESSING & OUTPUTS ==========

def process_batch(records, code_col, system_col, index_lookup, writers, passthrough_cols):
    """
    records: list of dict rows from Excel
    code_col, system_col: resolved column names
    index_lookup: ConceptMap index
    writers: dict with 'std' and 'safe' csv writers and info for xlsx mirror
    passthrough_cols: original header column names to copy through unchanged
    """
    std_writer = writers['std']
    safe_writer = writers['safe']

    for rec in records:
        source_code_raw = rec.get(code_col)

        # Dynamic system URI based on Clinical System + Mode (if both exist)
        clinical_system = safe_str(rec.get(system_col)).strip()
        mode = safe_str(rec.get('Mode')).strip()
        if clinical_system and mode:
            source_system_raw = f"http://lds.nhs/{clinical_system}/{mode}/cs"
        else:
            source_system_raw = clinical_system

        # Coerce to string for matching
        source_code = safe_str(source_code_raw).strip()
        source_system = safe_str(source_system_raw).strip()

        # Build base output by passing through original columns first
        out = {col: safe_str(rec.get(col)) for col in passthrough_cols}

        # Add explicit columns we use for matching (so it’s clear even when aliases are used)
        out['source_code_used'] = source_code
        out['source_system_used'] = source_system

        # Results placeholders
        out.update({
            'mapping_found': False,
            'mapped_codes': '',
            'mapped_display': '',
            'target_systems': '',
            'target_equiv_or_rel': '',
            'targets_pairs': '',
            'conceptmap_file': '',
            'conceptmap_name': '',
            'conceptmap_title': ''
        })

        if not source_code or not source_system:
            std_writer.writerow(out)
            safe_writer.writerow({k: excel_safe_value(v, k) for k, v in out.items()})
            if 'xlsx_rows' in writers:
                writers['xlsx_rows'].append(out)
            continue

        key = (maybe_canon_system(source_system), norm_code(source_code))
        matches = index_lookup.get(key, [])

        if not matches:
            std_writer.writerow(out)
            safe_writer.writerow({k: excel_safe_value(v, k) for k, v in out.items()})
            if 'xlsx_rows' in writers:
                writers['xlsx_rows'].append(out)
            continue

        # Merge results
        out['mapping_found'] = True
        all_codes, all_displays, all_systems, all_equiv, all_pairs = [], [], [], [], []
        cm_files, cm_names, cm_titles = [], [], []

        def merge(m):
            tgs = m['targets']
            all_codes.extend([safe_str(t.get('code', '')) for t in tgs])
            all_displays.extend([safe_str(t.get('display', '')) for t in tgs])
            all_systems.extend([safe_str(t.get('system', '')) for t in tgs])
            all_equiv.extend([safe_str(t.get('equiv_or_rel', '')) for t in tgs])
            all_pairs.append(to_pairs_str(tgs))

        if STOP_AT_FIRST_MATCH:
            m = matches[0]
            merge(m)
            cm_files.append(m['cm_file']); cm_names.append(m['cm_name']); cm_titles.append(m['cm_title'])
        else:
            for m in matches:
                merge(m)
                cm_files.append(m['cm_file']); cm_names.append(m['cm_name']); cm_titles.append(m['cm_title'])

        out['mapped_codes'] = SEP_VALUES.join([x for x in all_codes if x])
        out['mapped_display'] = SEP_VALUES.join([x for x in all_displays if x])
        out['target_systems'] = SEP_VALUES.join([x for x in all_systems if x])
        out['target_equiv_or_rel'] = SEP_VALUES.join([x for x in all_equiv if x])
        out['targets_pairs'] = SEP_VALUES.join([x for x in all_pairs if x])
        out['conceptmap_file'] = SEP_CM.join(cm_files)
        out['conceptmap_name'] = SEP_CM.join(cm_names)
        out['conceptmap_title'] = SEP_CM.join(cm_titles)

        std_writer.writerow(out)
        safe_writer.writerow({k: excel_safe_value(v, k) for k, v in out.items()})
        if 'xlsx_rows' in writers:
            writers['xlsx_rows'].append(out)


def main():
    # 1) Build ConceptMap index
    cm_index, _ = build_cm_index(JSON_FOLDER, SCAN_RECURSIVELY)

    # 2) Open input and detect header
    wb_in = load_workbook(SPREADSHEET_FILE, read_only=True, data_only=True)
    ws_in = wb_in[wb_in.sheetnames[0]] if SHEET_NAME is None else wb_in[SHEET_NAME]

    header_row_idx, header_values, code_col_name, system_col_name = find_header(
        ws_in, HEADER_SCAN_ROWS, CODE_COLUMN_ALIASES, SYSTEM_COLUMN_ALIASES
    )
    print(f"Detected header row {header_row_idx}. Using columns: Code='{code_col_name}', system='{system_col_name}'.")

    # We'll pass through all original header columns as-is
    passthrough_cols = header_values

    # 3) Prepare outputs (CSV streaming) — now that we know headers
    # Field order: all original columns, then the matching/metadata columns
    result_cols = [
        'source_code_used', 'source_system_used',
        'mapping_found',
        'mapped_codes', 'mapped_display', 'target_systems', 'target_equiv_or_rel', 'targets_pairs',
        'conceptmap_file', 'conceptmap_name', 'conceptmap_title'
    ]
    fieldnames = passthrough_cols + result_cols

    std_f = open(OUTPUT_CSV, 'w', newline='', encoding='utf-8-sig')
    safe_f = open(OUTPUT_CSV_EXCEL_SAFE, 'w', newline='', encoding='utf-8-sig')
    std_writer = csv.DictWriter(std_f, fieldnames=fieldnames, extrasaction='ignore')
    safe_writer = csv.DictWriter(safe_f, fieldnames=fieldnames, extrasaction='ignore', quoting=csv.QUOTE_ALL)
    std_writer.writeheader()
    safe_writer.writeheader()

    writers = {'std': std_writer, 'safe': safe_writer}

    # XLSX streaming
    if WRITE_XLSX:
        wb = Workbook(write_only=True)
        ws = wb.create_sheet('Results')
        header_cells = [WriteOnlyCell(ws, value=name) for name in fieldnames]
        ws.append(header_cells)
        writers['xlsx_wb'] = wb
        writers['xlsx_ws'] = ws
        writers['xlsx_fieldnames'] = fieldnames
        writers['xlsx_rows'] = []

    # 4) Stream the Excel input in batches
    total_rows = 0
    matched_rows = 0

    for batch in stream_rows(ws_in, header_row_idx, header_values, BATCH_SIZE):
        before_count = matched_rows

        process_batch(batch, code_col_name, system_col_name, cm_index, writers, passthrough_cols)

        # Quick match recount for this batch
        for rec in batch:
            source_code = safe_str(rec.get(code_col_name)).strip()

            clinical_system = safe_str(rec.get(system_col_name)).strip()
            mode = safe_str(rec.get('Mode')).strip()
            if clinical_system and mode:
                source_system = f"http://lds.nhs/{clinical_system}/{mode}/cs"
            else:
                source_system = clinical_system

            if source_code and source_system:
                key = (maybe_canon_system(source_system), norm_code(source_code))
                if cm_index.get(key):
                    matched_rows += 1

        total_rows += len(batch)

        # Flush XLSX rows
        if WRITE_XLSX and writers.get('xlsx_rows'):
            rows_to_flush = writers['xlsx_rows']
            ws = writers['xlsx_ws']
            fieldnames_local = writers['xlsx_fieldnames']
            for out in rows_to_flush:
                row_cells = []
                for col in fieldnames_local:
                    val = out.get(col, '')
                    cell = WriteOnlyCell(ws, value=val)
                    # Text number format for identifier-like / base text cols
                    if col in TEXT_COLS_BASE or (isinstance(val, str) and IDENTIFIER_REGEX.match(val)):
                        cell.number_format = '@'
                    # Wrap selected text-heavy columns
                    if col in WRAP_TEXT_COLS:
                        cell.alignment = Alignment(wrap_text=True)
                    row_cells.append(cell)
                ws.append(row_cells)
            writers['xlsx_rows'].clear()

        print(f"Processed {total_rows:,} rows... (+{matched_rows - before_count} matches in this batch)")

    # 5) Close outputs
    std_f.close()
    safe_f.close()

    if WRITE_XLSX:
        # Remove default empty sheet if present
        wb_sheets = writers['xlsx_wb'].sheetnames
        if 'Sheet' in wb_sheets and len(wb_sheets) > 1:
            del writers['xlsx_wb']['Sheet']
        writers['xlsx_wb'].save(OUTPUT_XLSX)

    print("✅ Done!")
    print(f"Rows total:        {total_rows:,}")
    print(f"Rows matched:      {matched_rows:,}")
    print(f"Standard CSV:      {OUTPUT_CSV}")
    print(f"Excel-safe CSV:    {OUTPUT_CSV_EXCEL_SAFE}")
    if WRITE_XLSX:
        print(f"Excel workbook:    {OUTPUT_XLSX}")


if __name__ == '__main__':
    main()