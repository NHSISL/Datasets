import os
import csv
import json
from collections import defaultdict
from urllib.parse import urlsplit, urlunsplit

# --- Configuration (Adjust these variables as needed) ---

# Input CSV file name. It should have one column containing the codes to search.
INPUT_CSV_FILE = 'codes_to_search.csv'
INPUT_CODE_COLUMN = 'Code' # The header name of the column containing the codes in the CSV

JSON_FOLDER = './json'
SCAN_RECURSIVELY = True

OUTPUT_CSV = 'code_search_results.csv'

# --- Normalization Settings ---
NORMALIZE_SYSTEMS = True
CASE_SENSITIVE_CODE = True # Requirement: Codes are case sensitive

# System synonyms (expand this dictionary if you have known system URI aliases)
SYSTEM_SYNONYMS = {} 

# --- Utility Functions (Adapted from the original script) ---

def canon_system(u: str) -> str:
    """Normalize system URIs."""
    if not u: return ''
    s = str(u).strip()
    # Apply basic URL cleaning/normalization
    if s.startswith('https://'):
        s = 'http://' + s[len('https://'):]
    s = s.rstrip('/') + '/'
    return SYSTEM_SYNONYMS.get(s, s)

def maybe_canon_system(u: str) -> str:
    return canon_system(u) if NORMALIZE_SYSTEMS else (str(u).strip() if u else '')

def norm_code(c: str) -> str:
    # Code is kept as-is since CASE_SENSITIVE_CODE is True
    return str(c).strip() if c is not None else ''

def get_group_system_candidates(group: dict, role: str) -> list:
    """Return all plausible fields identifying a group's source or target system scope."""
    field_map = {
        'source': ['source', 'sourceScope', 'sourceCanonical', 'sourceUri'],
        'target': ['target', 'targetScope', 'targetCanonical', 'targetUri'],
    }
    candidates = []
    for k in field_map.get(role, []):
        if k in group:
            val = group.get(k)
            if isinstance(val, list):
                candidates.extend(val)
            elif isinstance(val, str):
                candidates.append(val)
    return [x for x in candidates if x]

def iter_json_files(root_folder: str, recursive: bool):
    """Helper to iterate over all JSON files."""
    if recursive:
        for dirpath, _, filenames in os.walk(root_folder):
            for fn in filenames:
                if fn.lower().endswith('.json'):
                    yield os.path.join(dirpath, fn)
    else:
        for fn in os.listdir(root_folder):
            if fn.lower().endswith('.json'):
                yield os.path.join(root_folder, fn)

# --- Core Indexing and Search Functions ---

def build_code_index(json_folder: str, recursive: bool):
    """
    Builds an index where the key is the code (case-sensitive) and the value is a 
    list of all places it was found, including system, role, and file path.
    """
    # Key: normalized_code -> Value: list of usage records
    index = defaultdict(list)
    count_cm = 0
    failures = []

    for file_path in iter_json_files(json_folder, recursive):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            failures.append((file_path, str(e)))
            continue

        if data.get('resourceType') != 'ConceptMap':
            continue

        count_cm += 1
        cm_name = data.get('name', os.path.basename(file_path))
        
        groups = data.get('group', [])
        for group in groups:
            source_systems_raw = get_group_system_candidates(group, 'source')
            target_systems_raw = get_group_system_candidates(group, 'target')
            
            norm_source_systems = [maybe_canon_system(s) for s in source_systems_raw]
            norm_target_systems = [maybe_canon_system(s) for s in target_systems_raw]

            elements = group.get('element', []) or []
            
            # 1. Index SOURCE Codes
            for element in elements:
                code_raw = element.get('code')
                if code_raw:
                    code_key = norm_code(code_raw)
                    # Index with all possible source systems for the group
                    systems_to_index = norm_source_systems if norm_source_systems else ['(System Not Specified in Group)']
                    
                    for sys_key in systems_to_index:
                        index[code_key].append({
                            'code': code_raw, # Store raw code (case-sensitive)
                            'system': sys_key, 
                            'role': 'source', 
                            'file': file_path, 
                            'cm_name': cm_name
                        })

            # 2. Index TARGET Codes
            for element in elements:
                for target in element.get('target', []) or []:
                    target_code_raw = target.get('code')
                    if target_code_raw:
                        target_code_key = norm_code(target_code_raw)
                        
                        target_sys_raw = target.get('system')
                        systems_to_index = []

                        if target_sys_raw:
                            # Use the system defined directly on the target
                            systems_to_index.append(maybe_canon_system(target_sys_raw))
                        else:
                            # Fall back to the system defined on the group
                            systems_to_index.extend(norm_target_systems)

                        systems_to_index = systems_to_index if systems_to_index else ['(System Not Specified in Group)']
                        
                        for sys_key in systems_to_index:
                             index[target_code_key].append({
                                'code': target_code_raw, # Store raw code (case-sensitive)
                                'system': sys_key, 
                                'role': 'target', 
                                'file': file_path, 
                                'cm_name': cm_name
                            })
                                
    print(f"Loaded {count_cm} ConceptMap files. Indexed {len(index):,} unique codes.")
    if failures:
        print(f"⚠️ Could not load {len(failures)} files (e.g., {failures[0][0]}).")
        
    return index

def read_codes_from_csv(file_path: str, code_column_name: str) -> set:
    """Reads codes from the specified CSV file, cleans headers, and returns a set of unique codes."""
    codes = set()
    try:
        # Use 'utf-8-sig' to automatically handle the BOM (Byte Order Mark) if present
        with open(file_path, 'r', newline='', encoding='utf-8-sig') as f:
            
            # --- Custom DictReader to clean headers ---
            
            # Read the header line manually
            header_line = f.readline()
            
            # Reset file pointer to the beginning to allow DictReader to start from the top
            f.seek(0) 
            
            # Clean headers: strip whitespace, replace non-printable characters
            raw_headers = csv.reader([header_line]).__next__()
            clean_headers = [h.strip().replace('\ufeff', '') for h in raw_headers]
            
            # Check if the expected column is in the cleaned headers
            try:
                code_col_index = clean_headers.index(code_column_name)
                # Use the raw header name for the DictReader's fieldnames to map correctly
                actual_code_col_name = raw_headers[code_col_index]
            except ValueError:
                raise ValueError(f"CSV error: Column '{code_column_name}' not found. Available columns (cleaned): {', '.join(clean_headers)}")

            # Create the DictReader with the actual, possibly messy, headers
            reader = csv.DictReader(f)

            for row in reader:
                code = row.get(actual_code_col_name)
                if code:
                    # Use norm_code for consistency with the index key
                    codes.add(norm_code(code)) 
        
        print(f"Read {len(codes)} unique codes from '{file_path}'.")
    except FileNotFoundError:
        print(f"❌ Error: Input CSV file '{file_path}' not found.")
    except Exception as e:
        print(f"❌ Error reading CSV: {e}")
    return codes

def search_and_write_results(index_lookup, search_codes):
    """Searches the index for the given codes and writes the results to CSV."""
    
    fieldnames = [
        'Search_Code', 'Found_Code', 'Code_System', 'Role', 
        'ConceptMap_Name', 'ConceptMap_File_Path'
    ]
    
    total_matches = 0

    with open(OUTPUT_CSV, 'w', newline='', encoding='utf-8-sig') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        
        for search_code_key in search_codes:
            # Matches are retrieved using the normalized/case-sensitive key
            matches = index_lookup.get(search_code_key, [])
            
            if not matches:
                writer.writerow({
                    'Search_Code': search_code_key, 
                    'Found_Code': 'NOT FOUND', 
                    'Code_System': '', 
                    'Role': '', 
                    'ConceptMap_Name': '', 
                    'ConceptMap_File_Path': ''
                })
            else:
                # Use a set to store unique match records to avoid duplicate rows
                unique_matches = set()
                for m in matches:
                    record_tuple = (
                        m['code'], m['system'], m['role'], 
                        m['cm_name'], m['file']
                    )
                    unique_matches.add(record_tuple)
                
                for code, system, role, cm_name, file_path in unique_matches:
                    writer.writerow({
                        'Search_Code': search_code_key,
                        'Found_Code': code,
                        'Code_System': system,
                        'Role': role.upper(),
                        'ConceptMap_Name': cm_name,
                        'ConceptMap_File_Path': file_path
                    })
                    total_matches += 1

    print(f"\n✅ Search complete! Results written to '{OUTPUT_CSV}'.")
    print(f"   Total unique search codes: {len(search_codes):,}")
    print(f"   Total matching code usages found: {total_matches:,}")

# --- Main Execution ---

def main_search_csv():
    # 1. Read Codes from CSV
    search_codes = read_codes_from_csv(INPUT_CSV_FILE, INPUT_CODE_COLUMN)
    if not search_codes:
        print("Aborting search as no codes were found in the input CSV.")
        return

    # 2. Build the ConceptMap Index
    if not os.path.isdir(JSON_FOLDER):
        print(f"❌ Error: JSON folder '{JSON_FOLDER}' not found.")
        return
    
    cm_index = build_code_index(JSON_FOLDER, SCAN_RECURSIVELY)

    # 3. Search and Write Results
    search_and_write_results(cm_index, search_codes)


if __name__ == '__main__':
    main_search_csv()