#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Find duplicate *source codes* in FHIR R4 ConceptMap JSON files.

What it does:
- Scans all *.json ConceptMaps in a subfolder next to this script.
- Treats codes as case-sensitive (configurable).
- Flags duplicates when the *same source code* appears more than once
  *within the same ConceptMap group* (group = same source/target system pair).
- Writes a CSV report of duplicate source codes with file/group positions.
- (Optional) Writes cleaned copies where duplicate elements (same source code)
  within a group are *merged* (targets combined and deduplicated).

No command-line arguments needed — edit the SETTINGS below.
"""

from pathlib import Path
import json
import csv
from collections import defaultdict

# --------------------- SETTINGS (edit here) ---------------------
SUBFOLDER_NAME = "json"   # Subfolder next to this script with ConceptMap JSON files
CASE_SENSITIVE = True            # Treat codes as case-sensitive (your preference)
WRITE_CLEANED_COPIES = False     # True -> write cleaned copies (per-group dedup/merge)
OUTPUT_DIR_NAME = "out"          # Reports here; cleaned copies in out/clean/
# When merging duplicate elements, dedup targets by (code [+ equivalence]):
INCLUDE_EQUIVALENCE_IN_TARGET_DEDUP = True
# ---------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
DATA_DIR = SCRIPT_DIR / SUBFOLDER_NAME
OUT_DIR = SCRIPT_DIR / OUTPUT_DIR_NAME
CLEAN_DIR = OUT_DIR / "clean"

def norm(s: str) -> str:
    """Normalize a string based on CASE_SENSITIVE setting."""
    if s is None:
        return ""
    return s if CASE_SENSITIVE else s.lower()

def ensure_dirs():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    if WRITE_CLEANED_COPIES:
        CLEAN_DIR.mkdir(parents=True, exist_ok=True)

def safe_list(x):
    """Return x if list-like, else empty list (tolerant to missing fields)."""
    return x if isinstance(x, list) else []

def iter_groups(cm_json):
    """
    Yield (g_idx, group) for each group in a ConceptMap JSON.
    Tolerant to missing or malformed 'group'.
    """
    groups = cm_json.get("group", []) or []
    for g_idx, group in enumerate(groups):
        yield g_idx, group

def iter_group_elements(group):
    """
    Yield (e_idx, elem) for each element in a group.
    Tolerant to missing or malformed 'element'.
    """
    elements = group.get("element", []) or []
    for e_idx, elem in enumerate(elements):
        yield e_idx, elem

def element_source_code(elem):
    """Get the element.code (source code). Return None if missing/empty."""
    code = elem.get("code")
    if code is None:
        return None
    code_str = str(code)
    return code_str if code_str.strip() != "" else None

def target_unique_key(tgt):
    """
    Build a uniqueness key for targets when merging.
    Uses (code [+ equivalence]) to avoid losing distinct equivalences.
    """
    code = tgt.get("code")
    eq = tgt.get("equivalence") if INCLUDE_EQUIVALENCE_IN_TARGET_DEDUP else ""
    return (norm(str(code) if code is not None else ""), norm(str(eq) if eq is not None else ""))

def merge_duplicate_elements_with_same_source_code(group):
    """
    Within a single group, merge duplicate elements that share the same source code.
    - Keeps the first element's 'display' (if present).
    - Combines all targets from duplicates, deduplicating by target_unique_key().
    - Returns True if any merge/dedup happened, else False.
    """
    elements = safe_list(group.get("element"))
    if not elements:
        return False

    changed = False
    buckets = {}  # key: normalized source_code -> accumulator

    # Accumulate by source code
    for elem in elements:
        src_code_raw = element_source_code(elem)
        if src_code_raw is None:
            # Drop elements without a code
            changed = True
            continue

        key = norm(src_code_raw)
        if key not in buckets:
            buckets[key] = {
                "code": src_code_raw,
                "display": elem.get("display"),
                "target_list": [],
                "target_seen": set(),
            }

        # Prefer the first non-empty display
        if not buckets[key].get("display") and elem.get("display"):
            buckets[key]["display"] = elem.get("display")

        # Aggregate + dedup targets
        for tgt in safe_list(elem.get("target")):
            dk = target_unique_key(tgt)
            if dk in buckets[key]["target_seen"]:
                continue
            buckets[key]["target_seen"].add(dk)
            buckets[key]["target_list"].append(tgt)

    # Rebuild elements in first-seen order of unique source codes
    new_elements = []
    seen_src_keys_in_order = set()
    for elem in elements:
        src_code_raw = element_source_code(elem)
        if src_code_raw is None:
            continue
        k = norm(src_code_raw)
        if k in seen_src_keys_in_order:
            # duplicate element — merged already
            changed = True
            continue
        seen_src_keys_in_order.add(k)
        b = buckets[k]
        merged_elem = {"code": b["code"]}
        if b.get("display"):
            merged_elem["display"] = b["display"]
        # Keep target if present, otherwise keep empty list (safer, preserves structure)
        merged_elem["target"] = b["target_list"] if b["target_list"] else []
        new_elements.append(merged_elem)

    group["element"] = new_elements
    return changed

def main():
    if not DATA_DIR.exists():
        print(f"❌ Subfolder not found: {DATA_DIR}")
        print("Create it next to this script and put your ConceptMap JSON files inside.")
        return

    ensure_dirs()

    files = sorted(DATA_DIR.glob("*.json"))
    if not files:
        print(f"ℹ️ No JSON files found in {DATA_DIR}")
        return

    duplicate_rows = []  # rows for CSV
    files_scanned = 0
    groups_scanned = 0
    elements_scanned = 0
    elements_without_code = 0

    for fpath in files:
        try:
            with fpath.open("r", encoding="utf-8") as fh:
                cm = json.load(fh)
        except Exception as ex:
            print(f"⚠️ Could not parse {fpath.name}: {ex}")
            continue

        files_scanned += 1

        for g_idx, group in iter_groups(cm):
            groups_scanned += 1
            src_sys = group.get("source", "")
            tgt_sys = group.get("target", "")

            # Count source-code occurrences within this group
            counts = defaultdict(list)  # (norm(src_code)) -> list of element indices
            for e_idx, elem in iter_group_elements(group):
                elements_scanned += 1
                src_code_raw = element_source_code(elem)
                if src_code_raw is None:
                    elements_without_code += 1
                    continue
                key = norm(src_code_raw)
                counts[key].append(e_idx)

            # Collect duplicates (occur >1)
            for norm_src_code, e_idxs in counts.items():
                if len(e_idxs) > 1:
                    duplicate_rows.append({
                        "file": fpath.name,
                        "group_index": g_idx,
                        "source_system": src_sys,
                        "target_system": tgt_sys,
                        "source_code": group.get("element", [])[e_idxs[0]].get("code", ""),
                        "occurrence_count": len(e_idxs),
                        "element_indexes": "; ".join([f"e{e}" for e in e_idxs]),
                    })

        # Optionally write cleaned copy (per-group: merge duplicate elements by source code)
        if WRITE_CLEANED_COPIES:
            changed_any = False
            for _g_idx, group in iter_groups(cm):
                changed_any = merge_duplicate_elements_with_same_source_code(group) or changed_any

            if changed_any:
                out_path = CLEAN_DIR / f"{fpath.stem}.cleaned.json"
                with out_path.open("w", encoding="utf-8") as fh:
                    json.dump(cm, fh, ensure_ascii=False, indent=2)

    # Write CSV report
    dup_csv = OUT_DIR / "duplicate_source_codes.csv"
    with dup_csv.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "file",
            "group_index",
            "source_system",
            "target_system",
            "source_code",
            "occurrence_count",
            "element_indexes_in_group"
        ])
        for row in sorted(
            duplicate_rows,
            key=lambda r: (-int(r["occurrence_count"]), r["file"], int(r["group_index"]))
        ):
            writer.writerow([
                row["file"],
                row["group_index"],
                row["source_system"],
                row["target_system"],
                row["source_code"],
                row["occurrence_count"],
                row["element_indexes"],
            ])

    # Write summary
    summary_txt = OUT_DIR / "summary.txt"
    with summary_txt.open("w", encoding="utf-8") as fh:
        fh.write(f"Files scanned: {files_scanned}\n")
        fh.write(f"Groups scanned: {groups_scanned}\n")
        fh.write(f"Elements scanned: {elements_scanned}\n")
        fh.write(f"Elements missing 'code': {elements_without_code}\n")
        fh.write(f"Groups with duplicate source codes: {len({(r['file'], r['group_index']) for r in duplicate_rows})}\n")
        fh.write(f"Total duplicate rows reported: {len(duplicate_rows)}\n")
        fh.write(f"Report: {dup_csv.name}\n")
        if WRITE_CLEANED_COPIES:
            fh.write("Cleaned copies: written for files where merges were needed (see out/clean/)\n")

    print(f"✅ Done. See report: {dup_csv}")
    print(f"ℹ️ Summary: {summary_txt}")
    if WRITE_CLEANED_COPIES:
        print("🧹 If duplicates existed, cleaned copies were written to: out/clean/")
        print("   (Duplicate elements with the same source code were merged; targets combined & deduplicated.)")

if __name__ == "__main__":
    main()