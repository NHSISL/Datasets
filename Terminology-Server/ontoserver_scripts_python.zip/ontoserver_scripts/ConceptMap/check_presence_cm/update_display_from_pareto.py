# -*- coding: utf-8 -*-
"""
Update 'Display' from Pareto analysis for rows where Display == 'Unknown'.

Location:
    ConceptMap/check_presence_cm/update_display_from_pareto.py

What it does:
- Finds the latest CSV named: concept_map_results_*_excel-safe.csv (in this folder).
- Reads CSV as all-text (no normalization; preserves leading apostrophes).
- Reads Pareto analysis.xlsx (sheet 'Export') as all-text.
- For rows where Display == 'Unknown', updates Display by exact match on Code:
    * Matching is exact, case-sensitive, and whitespace-significant.
    * Uses a temporary join key that removes exactly ONE leading apostrophe
      from the CSV Code (for matching only). Stored values remain untouched.
- Writes an .xlsx next to the CSV with the same base name.

No CLI arguments; edit constants below only if your headers/sheet name ever change.
"""

from pathlib import Path
import sys
from typing import Optional, List

import pandas as pd


# =========================
# Configuration (Edit here)
# =========================
HERE = Path(__file__).resolve().parent

# Input Pareto file and sheet
PARETO_FILENAME = "Pareto analysis.xlsx"
PARETO_SHEET = "Export"

# Name pattern of the generated CSV
CSV_PATTERN = "concept_map_results_*_excel-safe.csv"

# Column names used for matching and updating
CODE_COL = "Code"
DISPLAY_COL = "Display"


# -------------------------
# Helper functions
# -------------------------
def _find_latest(pattern: str, search_dir: Path) -> Optional[Path]:
    """Return the newest file matching pattern in search_dir (or None)."""
    candidates: List[Path] = list(search_dir.glob(pattern))
    if not candidates:
        return None
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def _strip_single_leading_apostrophe(value: str) -> str:
    """
    Remove exactly ONE leading apostrophe for matching only.
    Does not alter spacing or other characters.
    """
    if isinstance(value, str) and value.startswith("'"):
        return value[1:]
    return value


def main():
    # Locate latest CSV
    csv_path = _find_latest(CSV_PATTERN, HERE)
    if not csv_path:
        raise FileNotFoundError(
            f"No CSV found matching {CSV_PATTERN} in {HERE}. "
            f"Has cm_csv_search.py generated it here?"
        )

    # Check Pareto presence
    pareto_path = HERE / PARETO_FILENAME
    if not pareto_path.exists():
        raise FileNotFoundError(f"Pareto not found: {pareto_path}")

    # --- Load CSV (comma-separated, all text) ---
    df_csv = pd.read_csv(
        csv_path,
        dtype=str,             # every column as string
        keep_default_na=False, # keep empty strings as empty (not NaN)
        na_filter=False,       # don't detect NA-like strings
        encoding="utf-8-sig",  # handles BOM if present
    )

    # Validate columns
    for col in (CODE_COL, DISPLAY_COL):
        if col not in df_csv.columns:
            raise KeyError(
                f"CSV missing required column '{col}'. "
                f"Columns present: {list(df_csv.columns)}"
            )

    original_cols = list(df_csv.columns)  # preserve order exactly

    # --- Load Pareto Excel (sheet 'Export', all text) ---
    df_pareto = pd.read_excel(
        pareto_path,
        sheet_name=PARETO_SHEET,
        dtype=str,
    ).fillna("")

    for col in (CODE_COL, DISPLAY_COL):
        if col not in df_pareto.columns:
            raise KeyError(
                f"Pareto sheet missing required column '{col}'. "
                f"Columns present: {list(df_pareto.columns)}"
            )

    # --- Build exact-match keys (case & whitespace significant) ---
    # CSV key: remove exactly ONE leading apostrophe for matching only.
    df_csv["_join_key"] = df_csv[CODE_COL].map(_strip_single_leading_apostrophe)

    # Pareto key: use Code as-is
    df_pareto["_join_key"] = df_pareto[CODE_COL].astype(str)

    # Build lookup: join_key -> Display (first Pareto occurrence wins)
    pareto_lookup = (
        df_pareto.drop_duplicates(subset=["_join_key"], keep="first")
        .set_index("_join_key")[DISPLAY_COL]
    )

    # --- Update Display only where value is exactly 'Unknown' ---
    mask_unknown = df_csv[DISPLAY_COL] == "Unknown"
    proposed_updates = df_csv.loc[mask_unknown, "_join_key"].map(pareto_lookup)
    found_mask = proposed_updates.notna()

    # Apply updates where we have a match
    df_csv.loc[mask_unknown & found_mask, DISPLAY_COL] = proposed_updates[found_mask]

    # --- Clean up and write .xlsx next to the CSV ---
    df_csv.drop(columns=["_join_key"], inplace=True)
    df_out = df_csv[original_cols]

    output_xlsx = csv_path.with_suffix(".xlsx")
    with pd.ExcelWriter(output_xlsx, engine="openpyxl") as writer:
        df_out.to_excel(writer, index=False, sheet_name="Sheet1")

    # --- Summary in console ---
    total_unknown = int(mask_unknown.sum())
    updated_count = int((mask_unknown & found_mask.reindex(df_csv.index, fill_value=False)).sum())
    unmatched = total_unknown - updated_count

    print("Update complete.")
    print(f"Input CSV:      {csv_path}")
    print(f"Pareto:         {pareto_path} (sheet: {PARETO_SHEET})")
    print(f"Output Excel:   {output_xlsx}")
    print(f"'Unknown' rows: {total_unknown}")
    print(f"Updated rows:   {updated_count}")
    print(f"Still Unknown:  {unmatched}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)