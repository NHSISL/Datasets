#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Scan FHIR ConceptMap JSON files for source/target codes that look like scientific notation.

- Recurses through the 'json/' folder.
- Parses ConceptMap resources (including inside Bundles).
- Checks group.element[].code (source) and group.element[].target[].code (target).
- Preserves codes exactly as found (no normalization, no trimming).
- Also performs a raw-text safety scan to catch mistakenly unquoted scientific-notation numbers.

Outputs:
- Prints a readable summary to the console.
- Writes a CSV report: 'scientific_notation_codes_report.csv'

Configuration is embedded (no CLI args).
"""

from pathlib import Path
import json
import re
import csv
from typing import Any, Dict, List, Optional, Union, Tuple

# -----------------------
# Embedded configuration
# -----------------------
FOLDER = Path("json")  # root folder containing ConceptMap JSON files
RECURSIVE = True       # search subfolders too
MATCH_MODE = "full"    # "full" = entire code is sci-notation; "contains" = any substring looks like sci-notation
OUTPUT_CSV = Path("scientific_notation_codes_report.csv")
INCLUDE_NDJSON = True  # if a .json contains multiple JSON lines (NDJSON), try to parse each line

# Scientific-notation regex (e/E)
# Full-match:   ^[+-]?(?:\d+(?:\.\d*)?|\.\d+)[Ee][+-]?\d+$
# Contains: a version that finds sci-notation anywhere inside a string without false positives like words.
SCI_FULL = re.compile(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)[Ee][+-]?\d+$')
SCI_PART = re.compile(r'(?<!\w)[+-]?(?:\d+(?:\.\d*)?|\.\d+)[Ee][+-]?\d+(?!\w)')

# Raw-text pattern to catch *unquoted* code: values like:  "code": 1e5  or  "code": -2.3E-4
RAW_UNQUOTED_SCI = re.compile(
    r'"code"\s*:\s*(?P<val>[+-]?(?:\d+(?:\.\d*)?|\.\d+)[Ee][+-]?\d+)\b'
)


def is_sci_notation(code: str, mode: str = "full") -> bool:
    if not isinstance(code, str):
        return False
    # Do NOT strip or normalize: preserve exact content sensitivity
    if mode == "full":
        return SCI_FULL.fullmatch(code) is not None
    return SCI_PART.search(code) is not None


def load_json_objects(path: Path) -> List[Dict[str, Any]]:
    """
    Load one or many JSON objects from a file.
    - If the file is a single JSON object → return [obj]
    - If NDJSON (one JSON object per line) and INCLUDE_NDJSON=True → return a list of objs
    - Otherwise return empty list if parsing fails
    """
    text = path.read_text(encoding="utf-8", errors="replace")

    # Try single JSON first
    try:
        obj = json.loads(text)
        return [obj]
    except json.JSONDecodeError:
        pass

    objs: List[Dict[str, Any]] = []
    if INCLUDE_NDJSON:
        for i, line in enumerate(text.splitlines(), start=1):
            line_strip = line.strip()
            if not line_strip:
                continue
            try:
                obj = json.loads(line_strip)
                if isinstance(obj, dict):
                    objs.append(obj)
            except json.JSONDecodeError:
                # ignore bad lines
                continue
    return objs


def extract_conceptmaps(obj: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Return all ConceptMap resources from:
    - a ConceptMap resource itself, or
    - a Bundle containing ConceptMap entries
    """
    cms: List[Dict[str, Any]] = []
    rt = obj.get("resourceType")

    if rt == "ConceptMap":
        cms.append(obj)
        return cms

    if rt == "Bundle":
        for entry in obj.get("entry", []):
            res = entry.get("resource")
            if isinstance(res, dict) and res.get("resourceType") == "ConceptMap":
                cms.append(res)
    return cms


def record_finding(
    findings: List[Dict[str, Any]],
    *,
    file: Path,
    resource: Dict[str, Any],
    group: Dict[str, Any],
    side: str,  # 'source' or 'target'
    code_value: str,
    json_pointer: str,
    note: str
):
    cm_id = resource.get("id", "")
    cm_url = resource.get("url", "")
    findings.append({
        "file": str(file),
        "resource.id": cm_id,
        "resource.url": cm_url,
        "group.source": group.get("source", ""),
        "group.sourceVersion": group.get("sourceVersion", ""),
        "group.target": group.get("target", ""),
        "group.targetVersion": group.get("targetVersion", ""),
        "side": side,
        "code": code_value,
        "json_pointer": json_pointer,
        "note": note
    })


def scan_parsed_conceptmap(
    file: Path,
    resource: Dict[str, Any],
    findings: List[Dict[str, Any]],
    match_mode: str
):
    groups = resource.get("group", [])
    if not isinstance(groups, list):
        return

    for gi, grp in enumerate(groups):
        elements = grp.get("element", [])
        if not isinstance(elements, list):
            continue

        for ei, ele in enumerate(elements):
            # Source code
            src_code = ele.get("code", None)
            if isinstance(src_code, str) and is_sci_notation(src_code, match_mode):
                record_finding(
                    findings,
                    file=file,
                    resource=resource,
                    group=grp,
                    side="source",
                    code_value=src_code,
                    json_pointer=f"/group/{gi}/element/{ei}/code",
                    note="parsed string"
                )

            # Targets
            targets = ele.get("target", [])
            if not isinstance(targets, list):
                continue
            for ti, tgt in enumerate(targets):
                tgt_code = tgt.get("code", None)
                if isinstance(tgt_code, str) and is_sci_notation(tgt_code, match_mode):
                    record_finding(
                        findings,
                        file=file,
                        resource=resource,
                        group=grp,
                        side="target",
                        code_value=tgt_code,
                        json_pointer=f"/group/{gi}/element/{ei}/target/{ti}/code",
                        note="parsed string"
                    )


def raw_text_safety_scan(file: Path, findings: List[Dict[str, Any]], text_cache: Optional[str] = None):
    """
    Safety net: If a file contains *unquoted* scientific-notation numbers assigned to "code",
    they won't be discoverable via JSON parsing (they turn into floats and lose the 'e' form).
    This scan flags those occurrences, at the file level (no JSON pointer).
    """
    text = text_cache if text_cache is not None else file.read_text(encoding="utf-8", errors="replace")
    for m in RAW_UNQUOTED_SCI.finditer(text):
        raw_val = m.group("val")
        findings.append({
            "file": str(file),
            "resource.id": "",
            "resource.url": "",
            "group.source": "",
            "group.sourceVersion": "",
            "group.target": "",
            "group.targetVersion": "",
            "side": "unknown",
            "code": raw_val,
            "json_pointer": "",
            "note": "raw-text unquoted numeric sci-notation (not FHIR-compliant)"
        })


def write_csv(findings: List[Dict[str, Any]], out_path: Path):
    if not findings:
        # still create an empty file with headers for traceability
        headers = [
            "file","resource.id","resource.url","group.source","group.sourceVersion",
            "group.target","group.targetVersion","side","code","json_pointer","note"
        ]
        with out_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
        return

    headers = list(findings[0].keys())
    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for row in findings:
            writer.writerow(row)


def main():
    if not FOLDER.exists():
        print(f"[ERROR] Folder not found: {FOLDER.resolve()}")
        return

    pattern = "**/*.json" if RECURSIVE else "*.json"
    files = sorted(FOLDER.glob(pattern))

    findings: List[Dict[str, Any]] = []
    total_conceptmaps = 0

    for file in files:
        # Cache text once for both parsing and raw safety scan where needed
        text_cache = file.read_text(encoding="utf-8", errors="replace")

        objs = load_json_objects(file)
        if not objs:
            # Still perform raw text scan (will catch unquoted numeric sci-notation if present)
            raw_text_safety_scan(file, findings, text_cache)
            continue

        for obj in objs:
            cms = extract_conceptmaps(obj)
            if not cms:
                # Also do a raw safety scan in this file (it might not be a CM or might be malformed)
                continue
            for cm in cms:
                total_conceptmaps += 1
                scan_parsed_conceptmap(file, cm, findings, MATCH_MODE)

        # Always do a raw text safety scan for unquoted numeric code values
        raw_text_safety_scan(file, findings, text_cache)

    # Output summary
    print(f"\nScanned folder: {FOLDER.resolve()}")
    print(f"ConceptMap resources found: {total_conceptmaps}")
    print(f"Potential scientific-notation code matches: {len(findings)}")

    if findings:
        # pretty print first few
        print("\nExamples:")
        for row in findings[:10]:
            print(f"- {row['file']} | {row.get('resource.id','')} | {row['side']:>6} | code='{row['code']}' | {row['json_pointer']} | {row['note']}")

    write_csv(findings, OUTPUT_CSV)
    print(f"\nReport written to: {OUTPUT_CSV.resolve()}")


if __name__ == "__main__":
    main()