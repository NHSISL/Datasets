#!/usr/bin/env python3
"""
One-click pipeline for ConceptMap conversion/cleanup/equivalence.

Folder layout assumed (relative to this file's parent folder 'ontoserver_scripts'):
  ConceptMap/
    code_converter/
      tsv_to_json_cm.py
      Untitled_map.tsv           (input)
      conceptmap.json            (generated)
    remove_element/
      remove_unmatched.py        (reads conceptmap.json in same folder)
      conceptmap.json            (copied in)
      conceptmap_cleaned.json    (generated)
    equivalence/
      equivalent.py              (reads conceptmap_cleaned.json in same folder)
      conceptmap_cleaned.json    (copied in)
      conceptmap_updated.json    (final output)

Cleanup on success:
  - delete ConceptMap/code_converter/conceptmap.json
  - delete ConceptMap/remove_element/conceptmap.json
  - delete ConceptMap/remove_element/conceptmap_cleaned.json
  - delete ConceptMap/equivalence/conceptmap_cleaned.json
  Final artifact left:
  - ConceptMap/equivalence/conceptmap_updated.json
"""
from __future__ import annotations
import subprocess, sys, time, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CM = ROOT / "ConceptMap"
CODECONV = CM / "code_converter"
REMOVE = CM / "remove_element"
EQUIV = CM / "equivalence"

INPUT_TSV = CODECONV / "Untitled_map.tsv"
CODECONV_JSON = CODECONV / "conceptmap.json"

REMOVE_IN_JSON = REMOVE / "conceptmap.json"
REMOVE_OUT_JSON = REMOVE / "conceptmap_cleaned.json"

EQUIV_IN_JSON = EQUIV / "conceptmap_cleaned.json"
EQUIV_OUT_JSON = EQUIV / "conceptmap_updated.json"

def run(cmd:list[str], cwd:Path, name:str) -> None:
    t0 = time.time()
    print(f"\n--- [{name}] Running in {cwd}:\n$", " ".join(cmd), flush=True)
    proc = subprocess.run(cmd, cwd=str(cwd), text=True, capture_output=True)
    dt = time.time() - t0
    if proc.stdout:
        print(proc.stdout.strip())
    if proc.returncode != 0:
        if proc.stderr:
            print(proc.stderr.strip(), file=sys.stderr)
        raise SystemExit(f"[{name}] FAILED (exit {proc.returncode}) after {dt:.1f}s")
    print(f"[{name}] OK in {dt:.1f}s")

def require_file(p:Path, label:str)->None:
    if not p.exists():
        raise SystemExit(f"Missing {label}: {p}")

def copy(src:Path, dst:Path)->None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f"Copied: {src} -> {dst}")

def delete_quiet(p:Path)->None:
    try:
        if p.exists():
            p.unlink()
            print(f"Deleted: {p}")
    except Exception as e:
        print(f"Warning: could not delete {p}: {e}", file=sys.stderr)

def main():
    print("ConceptMap one-click pipeline starting…")
    # 0) Preconditions
    require_file(INPUT_TSV, "input TSV")

    # 1) Generate conceptmap.json in code_converter
    run([sys.executable, "tsv_to_json_cm.py"], CODECONV, "tsv_to_json")
    require_file(CODECONV_JSON, "code_converter/conceptmap.json")

    # 2) Copy to remove_element and run remove_unmatched.py
    copy(CODECONV_JSON, REMOVE_IN_JSON)
    run([sys.executable, "remove_unmatched.py"], REMOVE, "remove_unmatched")
    require_file(REMOVE_OUT_JSON, "remove_element/conceptmap_cleaned.json")

    # 3) Copy cleaned to equivalence and run equivalent.py
    copy(REMOVE_OUT_JSON, EQUIV_IN_JSON)
    run([sys.executable, "equivalent.py"], EQUIV, "equivalent")
    require_file(EQUIV_OUT_JSON, "equivalence/conceptmap_updated.json")

    # 4) Cleanup (only if all steps succeeded)
    print("\nAll steps completed successfully. Performing cleanup…")
    delete_quiet(CODECONV_JSON)       # code_converter/conceptmap.json
    delete_quiet(REMOVE_IN_JSON)      # remove_element/conceptmap.json
    delete_quiet(REMOVE_OUT_JSON)     # remove_element/conceptmap_cleaned.json
    delete_quiet(EQUIV_IN_JSON)       # equivalence/conceptmap_cleaned.json

    print("\n✅ Pipeline complete.")
    print(f"Final output: {EQUIV_OUT_JSON}")

if __name__ == "__main__":
    main()